/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import nodemailer from "nodemailer";
import Razorpay from "razorpay";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { Product, CartItem, SavedAddress, Order, UserProfile, Coupon, Banner, SupportMessage } from "./src/types";
import { createDelhiveryShipment, trackDelhiveryShipment } from "./src/lib/delhivery";
import { getInvoiceByOrderId, mapOrderToInvoice } from "./lib/invoice";

// Database filepath for JSON-backed server storage
const DB_FILE = path.join(process.cwd(), "server_db.json");

// Default product list to populate database
const DEFAULT_PRODUCTS: Product[] = [
  {
    id: "men-1",
    name: "Indigo Splatter Oversized Kurta",
    description: "Heavyweight drop-shoulder street-style kurta with modern asymmetrical hemline, hand-dyed indigo splatter, and signature side-seam utility cargo pocket design.",
    price: 1899,
    category: "men",
    image: "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=600",
    sizes: ["M", "L", "XL", "XXL"],
    tag: "New Arrival",
    originalPrice: 2499
  },
  {
    id: "men-2",
    name: "Heritage Utility Street Jacket",
    description: "Fusion handloomed canvas outerwear incorporating classic bandhgala collar structure with multiple cargo flaps, tech metal key-rings, and heavy double-breasted streetwear fit.",
    price: 3499,
    category: "men",
    image: "https://images.unsplash.com/photo-1621184455862-c163dfb30e0f?auto=format&fit=crop&q=80&w=600",
    sizes: ["S", "M", "L", "XL"],
    tag: "Best Seller",
    originalPrice: 4999
  },
  {
    id: "men-3",
    name: "Modernist Drape Shacket",
    description: "Comfort-fit linen cotton drape-shirt styled with a wrap-around ethnic side-cowl neck construction, organic horn buttons, and breathable drop-shoulder drape.",
    price: 1599,
    category: "men",
    image: "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=600",
    sizes: ["M", "L", "XL"],
    tag: "Trending",
    originalPrice: 1999
  },
  {
    id: "men-4",
    name: "Ziva Core Print Hoodie-Kurta",
    description: "Innovative high-comfort heavyweight French-terry hoodie with deep side-slits, extended tunic length, and custom block-print screen graphics in monochrome aesthetic.",
    price: 1499,
    category: "men",
    image: "https://images.unsplash.com/photo-1607823489283-1dee240f9eeb?auto=format&fit=crop&q=80&w=600",
    sizes: ["M", "L", "XL", "XXL"],
    tag: "Exclusive",
    originalPrice: 1899
  },
  {
    id: "women-1",
    name: "Organza Overlay Street Dress",
    description: "Exquisite multi-layered organza sheer dress with modern black-ink block floral motifs, high gathered bell sleeves, and comfortable streetwear side-tether layout.",
    price: 2699,
    category: "women",
    image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=600",
    sizes: ["XS", "S", "M", "L"],
    tag: "New Arrival",
    originalPrice: 3599
  },
  {
    id: "women-2",
    name: "Indigo Modern-Drape Saree Crop",
    description: "Pre-draped luxury handloom indigo cotton saree skirt with stylized side-release buckles paired with a high-neck streetwear utility crop top.",
    price: 3899,
    category: "women",
    image: "https://images.unsplash.com/photo-1610030470215-62181cf87a27?auto=format&fit=crop&q=80&w=600",
    sizes: ["S", "M", "L"],
    tag: "Exclusive",
    originalPrice: 4999
  },
  {
    id: "women-3",
    name: "Crimson Heritage Bomber Jacket",
    description: "Luxury heavy silk bomber jacket showcasing intricate traditional handembroidered details on contrast-panels, high-polish gold front zip, and modern active-rib details.",
    price: 4199,
    category: "women",
    image: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=600",
    sizes: ["S", "M", "L", "XL"],
    tag: "Best Seller",
    originalPrice: 5999
  },
  {
    id: "women-4",
    name: "Minimalist Drawstring Anarkali Tunic",
    description: "Elegant daily-wear fusion tunic with dual-adjustable drawstring street-girdle, raw-edge thread trim accents, and high leg side-vents for modern ease.",
    price: 1799,
    category: "women",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=600",
    sizes: ["XS", "S", "M", "L", "XL"],
    tag: "Trending",
    originalPrice: 2299
  }
];

const DEFAULT_COUPONS: Coupon[] = [
  { id: "c-1", code: "DADU", discountPercent: 20, minCartValue: 699, active: true, usageLimit: 1000, usageCount: 42 },
  { id: "c-2", code: "ZIVA30", discountPercent: 30, minCartValue: 2000, active: true, usageLimit: 100, usageCount: 12 },
  { id: "c-3", code: "FESTIVE15", discountPercent: 15, minCartValue: 0, active: false, usageLimit: 50, usageCount: 8 }
];

const DEFAULT_BANNERS: Banner[] = [
  { id: "b-1", image: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&q=80&w=1200", title: "ATELIER CAPSULE 01", subtitle: "Indo-Western Luxe Streetwear", ctaText: "Explore Now", active: true },
  { id: "b-2", image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&q=80&w=1200", title: "THE MONOCHROME COWL", subtitle: "Futuristic Fusion Silhouettes", ctaText: "Shop the Silhouette", active: true }
];

const DEFAULT_SUPPORT_MESSAGES: SupportMessage[] = [
  { id: "msg-123", name: "Rohan Khanna", email: "rohan@gmail.com", phone: "9876543210", subject: "Sizing Inquiry", message: "Hi, I am 6 feet tall, should I order L or XL for the Indigo Splatter Oversized Kurta? Thanks!", date: "2026-06-03T10:15:00.000Z", status: "new" },
  { id: "msg-124", name: "Ananya Iyer", email: "ananya@yahoo.com", phone: "9123456789", subject: "Delivery delays in Bangalore", message: "Hello! My order tracking shows it is packed. How long will it take to reach Bangalore? Thanks for lovely streetwear!", date: "2026-06-02T16:45:00.000Z", status: "replied", reply: "Hello Ananya, we have dispatched your Order via Delhivery priority cargo. It will reach Bangalore within 2 business days!" }
];

const DEFAULT_SETTINGS = {
  taxRate: 5,
  freeDeliveryThreshold: 699,
  shopOpen: true,
  statusMessage: "Unlock 20% OFF sitewide with coupon: DADU • Free Delivery above ₹699"
};

interface DBStructure {
  users: Record<string, UserProfile>;
  orders: Record<string, Order>;
  pending_orders?: Record<string, any>;
  products?: Product[];
  coupons?: Coupon[];
  banners?: Banner[];
  supportMessages?: SupportMessage[];
  siteSettings?: Record<string, any>;
}

// Ensure database file loaded safely or initialized
function loadDatabase(): DBStructure {
  let dbData: DBStructure = { users: {}, orders: {} };
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      dbData = JSON.parse(data);
    }
  } catch (error) {
    console.error("Failed to read database file, initializing fresh database", error);
  }

  let modified = false;
  if (!dbData.users) { dbData.users = {}; modified = true; }
  if (!dbData.orders) { dbData.orders = {}; modified = true; }
  if (!dbData.products) { dbData.products = DEFAULT_PRODUCTS; modified = true; }
  if (!dbData.coupons) { dbData.coupons = DEFAULT_COUPONS; modified = true; }
  if (!dbData.banners) { dbData.banners = DEFAULT_BANNERS; modified = true; }
  if (!dbData.supportMessages) { dbData.supportMessages = DEFAULT_SUPPORT_MESSAGES; modified = true; }
  if (!dbData.siteSettings) { dbData.siteSettings = DEFAULT_SETTINGS; modified = true; }

  if (modified) {
    saveDatabase(dbData);
  }
  return dbData;
}

function saveDatabase(db: DBStructure) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (error) {
    console.error("Failed to write to database file", error);
  }
}

// Pre-load DB
let db = loadDatabase();

function generateASCIIInvoice(invoice: any): string {
  const formattedDate = new Date(invoice.createdAt).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  let itemsStr = "";
  invoice.items.forEach((item: any, idx: number) => {
    const total = item.price * item.quantity;
    itemsStr += `${item.name.padEnd(35)} ${item.size.padEnd(6)} ${item.quantity.toString().padEnd(4)} ₹${item.price.toLocaleString('en-IN').padEnd(11)} ₹${total.toLocaleString('en-IN')}\n`;
    itemsStr += `  [HSN: 6205 | ART-STREET-${1000 + idx}]\n`;
  });

  return `========================================================================
                     ZIVA STREET APPARELS PVT. LTD.                     
             Luxury Indo-Streetwear Atelier - Signature Capsule         
========================================================================
ATELIER HUB:
Signature Block 4, Bandra Atelier Complex, Bandra West, Mumbai - 400050
GSTIN: 27AACZ0412R1Z8 | Support: contact@zivastreet.com
------------------------------------------------------------------------
                             TAX INVOICE                                
------------------------------------------------------------------------
INVOICE ID:  ${invoice.invoiceId.padEnd(28)} DATE: ${formattedDate}
ORDER ID:    ${invoice.orderId.padEnd(28)} PAYMENT STATUS: ${invoice.paymentStatus}
TRACKING ID: ${invoice.trackingId}
========================================================================
RECIPIENT (CONSIGNEE):
  Name:    ${invoice.customerName}
  Email:   ${invoice.email}
  Phone:   +91 ${invoice.phone}
  Address: ${invoice.shippingAddress}
========================================================================
ITEM DESCRIPTION / STYLE CODE       SIZE   QTY  UNIT PRICE  TOTAL
------------------------------------------------------------------------
${itemsStr}------------------------------------------------------------------------
SUBTOTAL:                                                   ₹${invoice.subtotal.toLocaleString('en-IN')}
COUPON DISCOUNT (${invoice.couponCode || 'NONE'}):                                   ${invoice.discount > 0 ? `-₹${invoice.discount.toLocaleString('en-IN')}` : '₹0'}
DELIVERY CHARGE (DELHIVERY CARGO):                          ${invoice.deliveryCharge === 0 ? 'FREE' : `₹${invoice.deliveryCharge.toLocaleString('en-IN')}`}
TAX (SGST & CGST @ 5%):                                     ₹${invoice.tax.toLocaleString('en-IN')}
========================================================================
GRAND TOTAL AMOUNT:                                         ₹${invoice.totalAmount.toLocaleString('en-IN')}
========================================================================
STATUS: PAID [STAMP: ATELIER DIGITALLY CERTIFIED]
This is a secure system-generated tax invoice.

Authorized by Ziva Street (c) 2026
------------------------------------------------------------------------
`;
}

function generateHTMLInvoice(invoice: any): string {
  const formattedDate = new Date(invoice.createdAt).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const itemsRows = invoice.items.map((item: any, idx: number) => `
    <tr>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">
        <div style="font-weight: bold; color: #111827; text-transform: uppercase;">${item.name}</div>
        <div style="font-size: 10px; color: #6b7280; font-family: monospace; margin-top: 2px;">HSN: 6205 | ART-STREET-${1000 + idx}</div>
      </td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: center; font-weight: bold;">${item.size}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: center; font-family: monospace;">${item.quantity}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right; font-family: monospace;">₹${item.price.toLocaleString('en-IN')}</td>
      <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right; font-family: monospace; font-weight: bold;">₹${(item.price * item.quantity).toLocaleString('en-IN')}</td>
    </tr>
  `).join('');

  const discountRow = invoice.discount > 0 ? `
        <div class="bill-row" style="color: #10b981; font-weight: bold;">
          <span>Coupon Discount (${invoice.couponCode || 'DADU'} - 20%):</span>
          <span>-₹${invoice.discount.toLocaleString('en-IN')}</span>
        </div>
  ` : '';

  const deliveryChargeText = invoice.deliveryCharge === 0 ? '<span style="color: #10b981; font-weight: bold;">FREE</span>' : `₹${invoice.deliveryCharge.toLocaleString('en-IN')}`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice - ${invoice.orderId}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background-color: #f3f4f6;
      color: #1f2937;
      margin: 0;
      padding: 40px 20px;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background: white;
      border: 1px solid #e5e7eb;
      padding: 40px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .header {
      border-bottom: 2px solid #111827;
      padding-bottom: 20px;
      margin-bottom: 30px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }
    .logo-box {
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .logo-black {
      background: #111827;
      color: white;
      padding: 4px 8px;
      font-weight: 900;
      letter-spacing: 0.1em;
      font-size: 14px;
    }
    .logo-border {
      border: 1px solid #111827;
      color: #111827;
      padding: 3px 6px;
      font-weight: 800;
      letter-spacing: 0.1em;
      font-size: 14px;
    }
    .invoice-title {
      font-size: 24px;
      font-weight: 900;
      text-transform: uppercase;
      margin: 0 0 10px 0;
      color: #111827;
      letter-spacing: -0.02em;
    }
    .meta-data {
      font-family: monospace;
      font-size: 12px;
      color: #4b5563;
      line-height: 1.5;
    }
    .meta-data strong {
      color: #111827;
    }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-bottom: 30px;
    }
    .address-section h3 {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: #9ca3af;
      margin: 0 0 8px 0;
    }
    .address-details {
      font-size: 12px;
      line-height: 1.6;
      font-weight: 500;
      color: #374151;
    }
    .address-details strong {
      color: #111827;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      margin-bottom: 30px;
    }
    th {
      background: #f9fafb;
      padding: 10px 12px;
      font-weight: 850;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #4b5563;
      border-bottom: 2px solid #e5e7eb;
    }
    .summary-grid {
      display: grid;
      grid-template-columns: 1.2fr 1fr;
      gap: 30px;
      align-items: start;
    }
    .policy {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      padding: 15px;
      font-size: 10px;
      color: #6b7280;
      line-height: 1.5;
    }
    .bill-row {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      margin-bottom: 8px;
      color: #4b5563;
    }
    .bill-row strong {
      color: #111827;
    }
    .bill-total {
      border-top: 1px solid #111827;
      padding-top: 12px;
      margin-top: 12px;
      display: flex;
      justify-content: space-between;
      font-size: 15px;
      font-weight: 900;
      color: #111827;
    }
    .footer {
      border-top: 1px solid #e5e7eb;
      margin-top: 40px;
      padding-top: 25px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .stamp {
      border: 3px dashed #10b981;
      color: #10b981;
      font-family: monospace;
      font-size: 14px;
      font-weight: 900;
      padding: 6px 15px;
      transform: rotate(-3deg);
      background: rgba(16, 185, 129, 0.05);
      border-radius: 4px;
      letter-spacing: 0.1em;
    }
    .signature {
      text-align: right;
      font-size: 11px;
      color: #6b7280;
    }
    .signature strong {
      color: #111827;
      display: block;
      margin-bottom: 4px;
    }
    .btn-print {
      display: block;
      width: fit-content;
      margin: 20px auto 0 auto;
      background: #111827;
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 11px;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      cursor: pointer;
    }
    @media print {
      body {
        background: white;
        padding: 0;
      }
      .container {
        border: none;
        box-shadow: none;
        padding: 0;
      }
      .btn-print {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div>
        <div class="logo-box">
          <span class="logo-black">ZIVA</span>
          <span class="logo-border">STREET</span>
        </div>
        <p style="margin: 8px 0 0 0; font-size: 10px; font-weight: bold; color: #6b7280; text-transform: uppercase; letter-spacing: 0.05em;">Luxury Indo-Streetwear Atelier</p>
      </div>
      <div style="text-align: right;">
        <h1 class="invoice-title">Tax Invoice</h1>
        <div class="meta-data">
          <div><strong>INVOICE ID:</strong> ${invoice.invoiceId}</div>
          <div><strong>DATE:</strong> ${formattedDate}</div>
          <div><strong>ORDER ID:</strong> ${invoice.orderId}</div>
        </div>
      </div>
    </div>

    <div class="grid">
      <div class="address-section">
        <h3>Sold By (Atelier Hub)</h3>
        <div class="address-details">
          <strong>ZIVA STREET APPARELS PVT. LTD.</strong><br>
          Signature Block 4, Bandra Atelier Complex<br>
          Bandra West, Mumbai, MH - 400050<br>
          <span style="font-size: 10px; font-family: monospace; color: #6b7280;">GSTIN: 27AACZ0412R1Z8</span>
        </div>
      </div>
      <div class="address-section">
        <h3>Recipient (Consignee)</h3>
        <div class="address-details">
          <strong>${invoice.customerName}</strong><br>
          Email: ${invoice.email} | Phone: +91 ${invoice.phone}<br>
          Address: ${invoice.shippingAddress}
        </div>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th style="text-align: left;">Product Description</th>
          <th>Size</th>
          <th>Qty</th>
          <th style="text-align: right;">Unit Price</th>
          <th style="text-align: right;">Total Amount</th>
        </tr>
      </thead>
      <tbody>
        ${itemsRows}
      </tbody>
    </table>

    <div class="summary-grid">
      <div class="policy">
        <strong style="display: block; margin-bottom: 5px; color: #374151; font-weight: bold; text-transform: uppercase;">Atelier Craft & Returns Policy</strong>
        Every garment is meticulously inspected, hand-measured, and customized with luxury weaves at our Mumbai workshop. Since these are couture capsules, we accept size exchanges within 14 days of receipt, provided standard tag seals are intact.<br><br>
        <strong>COURIER TRACKING:</strong> ${invoice.trackingId}
      </div>
      <div>
        <div class="bill-row">
          <span>Cart Merchandise Subtotal:</span>
          <strong>₹${invoice.subtotal.toLocaleString('en-IN')}</strong>
        </div>
        ${discountRow}
        <div class="bill-row">
          <span>Delhivery Cargo Logistics:</span>
          <strong>${deliveryChargeText}</strong>
        </div>
        <div class="bill-row">
          <span>Integrated SGST/CGST (5%):</span>
          <strong>₹${invoice.tax.toLocaleString('en-IN')}</strong>
        </div>
        <div class="bill-total">
          <span>Grand Total:</span>
          <span>₹${invoice.totalAmount.toLocaleString('en-IN')}</span>
        </div>
      </div>
    </div>

    <div class="footer">
      <div class="stamp">
        PAID<br>
        <span style="font-size: 8px;">Daud Atelier Verified</span>
      </div>
      <div class="signature">
        <strong>Authorized by Ziva Street</strong>
        System Generated Digital Tax Invoice
      </div>
    </div>
  </div>

  <button class="btn-print" onclick="window.print()">Print This Invoice</button>
</body>
</html>`;
}

async function sendInvoiceEmail(invoice: any, recipientEmail: string): Promise<boolean> {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_PASS;

  if (!user || !pass) {
    console.log("[NODEMAILER] Skipping automatic email dispatch because GMAIL_USER or GMAIL_PASS is not set in environment.");
    return false;
  }

  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user,
        pass,
      },
    });

    const htmlContent = generateHTMLInvoice(invoice);
    const txtContent = generateASCIIInvoice(invoice);

    const mailOptions = {
      from: `"Ziva Street Atelier" <${user}>`,
      to: recipientEmail,
      subject: `Order Confirmed! Ziva Street Invoice ${invoice.orderId}`,
      text: `Thank you for your order, ${invoice.customerName}! Here is your digital receipt:\n\n${txtContent}`,
      html: htmlContent,
      attachments: [
        {
          filename: `ZivaStreet_Invoice_${invoice.orderId}.html`,
          content: htmlContent,
        },
        {
          filename: `ZivaStreet_Invoice_${invoice.orderId}.txt`,
          content: txtContent,
        },
      ],
    };

    const info = await transporter.sendMail(mailOptions);
    console.log(`[NODEMAILER] Invoice email sent successfully to ${recipientEmail}: ${info.messageId}`);
    return true;
  } catch (error) {
    console.error(`[NODEMAILER] Failed to send invoice email to ${recipientEmail}:`, error);
    return false;
  }
}

export async function sendOrderEmail({
  to,
  customerName,
  orderId,
  totalAmount,
  trackingId,
}: {
  to: string;
  customerName: string;
  orderId: string;
  totalAmount: number;
  trackingId: string;
}) {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_PASS;

  if (!user || !pass) {
    console.log("[NODEMAILER] Skipping simplified order confirmation email because GMAIL_USER or GMAIL_PASS is not set in environment.");
    return;
  }

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user,
      pass,
    },
  });

  const mailOptions = {
    from: `"Ziva Street" <${user}>`,
    to,
    subject: `Order Confirmed - ${orderId}`,
    html: `
      <div style="font-family: Arial; padding: 20px;">
        <h2>🛍️ Ziva Street</h2>
        <p>Hi ${customerName},</p>
        <p>Your order has been successfully placed.</p>

        <h3>Order Details:</h3>
        <p><strong>Order ID:</strong> ${orderId}</p>
        <p><strong>Total Paid:</strong> ₹${totalAmount}</p>
        <p><strong>Tracking ID:</strong> ${trackingId}</p>

        <br/>
        <p>Thank you for shopping with us ❤️</p>
      </div>
    `,
  };

  await transporter.sendMail(mailOptions);
  console.log(`[NODEMAILER] Simple order email sent successfully to ${to}`);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({
    verify: (req: any, res, buf) => {
      req.rawBody = buf;
    }
  }));

  // Ensure the physical receipts directory inside workspace is populated on server start
  try {
    const receiptsDir = path.join(process.cwd(), "receipts");
    if (!fs.existsSync(receiptsDir)) {
      fs.mkdirSync(receiptsDir, { recursive: true });
    }
    const startupDb = loadDatabase();
    const orderList = Object.values(startupDb.orders || {});
    orderList.forEach((ord) => {
      try {
        const invoice = mapOrderToInvoice(ord);
        const txtContent = generateASCIIInvoice(invoice);
        const htmlContent = generateHTMLInvoice(invoice);
        fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${ord.id}.txt`), txtContent, "utf8");
        fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${ord.id}.html`), htmlContent, "utf8");
      } catch (err) {}
    });

    // Seed a beautiful sample tax invoice representation so they immediately have files to look at
    const sampleInvoice = getInvoiceByOrderId("ZS-ORD-741285");
    const txtContent = generateASCIIInvoice(sampleInvoice);
    const htmlContent = generateHTMLInvoice(sampleInvoice);
    fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_ZS-ORD-741285.txt`), txtContent, "utf8");
    fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_ZS-ORD-741285.html`), htmlContent, "utf8");
    console.log("Pre-populated physical streetwear invoices inside /receipts/ directory.");
  } catch (err) {
    console.error("Failed to run startup receipts generator:", err);
  }

  // API routes
  app.get("/api/products", (req, res) => {
    res.json(DEFAULT_PRODUCTS);
  });

  // OTP Request Route
  app.post("/api/auth/otp/send", (req, res) => {
    const { phone } = req.body;
    if (!phone) {
      res.status(400).json({ error: "Phone number is required." });
      return;
    }
    // Simulate OTP generation
    const otpCode = "123456";
    res.json({
      success: true,
      message: `OTP sent to ${phone} successfully.`,
      otpCode // Included in demo mode so user sees and can easily key it in!
    });
  });

  // Login Route
  app.post("/api/auth/login", (req, res) => {
    const { phone, otpCode, email, password, fullName } = req.body;
    db = loadDatabase();

    let userKey = "";
    let userEmail = email || "";
    let userPhone = phone || "";
    let name = fullName || "";

    if (phone) {
      if (otpCode !== "123456") {
        res.status(400).json({ error: "Invalid OTP code. Please use 123456 for demo." });
        return;
      }
      userKey = `phone-${phone}`;
      if (!name) {
        name = `User ${phone.slice(-4)}`;
      }
    } else if (email) {
      // Allow general login / registration for demo
      userKey = `email-${email.toLowerCase()}`;
      if (!name) {
        name = email.split("@")[0];
        name = name.charAt(0).toUpperCase() + name.slice(1);
      }
    } else {
      res.status(400).json({ error: "Phone or Email is required for authentication." });
      return;
    }

    // Retrieve or register user
    let user = db.users[userKey];
    if (!user) {
      user = {
        id: userKey,
        fullName: name,
        phone: userPhone,
        email: userEmail,
        addressBook: [],
        orders: [],
        cart: []
      };
      db.users[userKey] = user;
      saveDatabase(db);
    }

    res.json({
      success: true,
      user
    });
  });

  // Profile Update Route
  app.post("/api/auth/profile/update", (req, res) => {
    const { userId, fullName, phone, email, savedAddress } = req.body;
    if (!userId) {
      res.status(400).json({ error: "User ID is required." });
      return;
    }

    db = loadDatabase();
    const user = db.users[userId];
    if (!user) {
      res.status(404).json({ error: "User not found." });
      return;
    }

    if (fullName !== undefined) user.fullName = fullName;
    if (phone !== undefined) user.phone = phone;
    if (email !== undefined) user.email = email;
    if (savedAddress !== undefined) {
      // Add or replace address
      const addrIndex = user.addressBook.findIndex(
        (a) => a.streetAddress === savedAddress.streetAddress && a.city === savedAddress.city
      );
      if (addrIndex >= 0) {
        user.addressBook[addrIndex] = savedAddress;
      } else {
        user.addressBook.push(savedAddress);
      }
    }

    db.users[userId] = user;
    saveDatabase(db);

    res.json({
      success: true,
      user
    });
  });

  // Save Cart route
  app.post("/api/cart/save", (req, res) => {
    const { userId, cart } = req.body;
    if (!userId) {
      res.status(400).json({ error: "User ID is required." });
      return;
    }

    db = loadDatabase();
    if (db.users[userId]) {
      db.users[userId].cart = cart || [];
      saveDatabase(db);
    }

    res.json({ success: true });
  });

  // Razorpay Configuration Configuration Endpoint
  app.get("/api/razorpay-config", (req, res) => {
    const keyId = process.env.RAZORPAY_KEY_ID || process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "";
    const hasSecret = !!process.env.RAZORPAY_KEY_SECRET;
    res.json({
      enabled: !!keyId && hasSecret,
      keyId: keyId
    });
  });

  // Razorpay Order Creation Endpoint
  app.post("/api/razorpay/create-order", async (req, res) => {
    try {
      const { amount, currency, receipt, orderData: clientOrderData } = req.body;
      const keyId = process.env.RAZORPAY_KEY_ID || process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID;
      const keySecret = process.env.RAZORPAY_KEY_SECRET;

      if (!keyId || !keySecret) {
        res.status(500).json({ error: "Razorpay credentials are not configured on the Ziva Street server." });
        return;
      }

      if (!amount || isNaN(amount)) {
        res.status(400).json({ error: "A valid order 'amount' package is required." });
        return;
      }

      // Initialize Razorpay SDK client lazily on demand
      const rzpInstance = new Razorpay({
        key_id: keyId,
        key_secret: keySecret
      });

      // Invoke official SDK method to register order (amount from user client is in Rupees, multiply by 100 for Paise)
      const orderData = await rzpInstance.orders.create({
        amount: Math.round(Number(amount) * 100),
        currency: currency || "INR",
        receipt: receipt || `rcpt_${Date.now()}`
      });

      // Stash complete client metadata to recover in webhook or client verification
      if (clientOrderData) {
        db = loadDatabase();
        if (!db.pending_orders) {
          db.pending_orders = {};
        }
        db.pending_orders[orderData.id] = clientOrderData;
        saveDatabase(db);
      }

      res.json({
        success: true,
        order: orderData
      });
    } catch (err: any) {
      console.error("[RAZORPAY ORDER GENERATOR ERROR]:", err);
      res.status(500).json({ error: err.message || "Failed to establish Razorpay payment order session." });
    }
  });

  // Razorpay Payment Verification Endpoint
  app.post("/api/razorpay/verify-payment", async (req, res) => {
    try {
      const { razorpay_signature, razorpay_payment_id, razorpay_order_id, orderData } = req.body;

      if (!razorpay_signature || !razorpay_payment_id || !razorpay_order_id) {
        res.status(400).json({ success: false, error: "Missing required Razorpay payment signature parameters." });
        return;
      }

      const keySecret = process.env.RAZORPAY_KEY_SECRET;
      if (!keySecret) {
        res.status(500).json({ success: false, error: "Razorpay keys are not configured on the server." });
        return;
      }

      const text = `${razorpay_order_id}|${razorpay_payment_id}`;
      const generated_signature = crypto
        .createHmac("sha256", keySecret)
        .update(text)
        .digest("hex");

      if (generated_signature !== razorpay_signature) {
        res.status(400).json({ success: false, error: "Signature verification failed." });
        return;
      }

      // Checkout / save order
      db = loadDatabase();

      // Check if this order has ALREADY been processed (e.g. by webhook firing first)
      const existingOrder = Object.values(db.orders).find(
        (ord: any) => ord.razorpayOrderId === razorpay_order_id
      );

      if (existingOrder) {
        console.log(`[RAZORPAY VERIFY PAYMENT] Order ${existingOrder.id} already verified and created.`);
        res.json({
          success: true,
          orderId: existingOrder.id,
          trackingId: existingOrder.trackingId,
          order: existingOrder
        });
        return;
      }

      // Try to recover from pending_orders first, fallback to user payload
      const pendingOrder = db.pending_orders ? db.pending_orders[razorpay_order_id] : null;

      const orderNum = Math.floor(100000 + Math.random() * 900000);
      const trackingNum = Math.floor(10000000 + Math.random() * 90000000);
      const orderId = `ZS-ORD-${orderNum}`;
      const trackingId = `ZS-TRK-${trackingNum}`;

      const finalOrder: Order = {
        id: orderId,
        trackingId,
        date: new Date().toISOString(),
        items: pendingOrder?.cartItems || orderData?.cartItems || pendingOrder?.items || orderData?.items || [],
        subtotal: pendingOrder?.subtotal ?? orderData?.subtotal ?? 0,
        discount: pendingOrder?.discount ?? orderData?.discount ?? 0,
        shipping: pendingOrder?.shipping ?? orderData?.shipping ?? 0,
        total: pendingOrder?.total ?? orderData?.total ?? 0,
        address: pendingOrder?.shippingAddress || orderData?.shippingAddress || pendingOrder?.address || orderData?.address || {
          fullName: "Guest Customer",
          phone: "9999999999",
          streetAddress: "Ziva Street Atelier, Bandra Colaba",
          city: "Mumbai",
          state: "Maharashtra",
          pinCode: "400050"
        },
        status: "ordered",
        couponCode: pendingOrder?.couponCode || orderData?.couponCode,
        razorpayOrderId: razorpay_order_id,
        razorpayPaymentId: razorpay_payment_id
      };

      db.orders[trackingId] = finalOrder;
      db.orders[orderId] = finalOrder;

      const targetUserId = pendingOrder?.userId || orderData?.userId;
      if (targetUserId && db.users[targetUserId]) {
        db.users[targetUserId].orders.unshift(finalOrder);
        db.users[targetUserId].cart = [];
      }

      // Tidy up: delete stashed pending details
      if (db.pending_orders && db.pending_orders[razorpay_order_id]) {
        delete db.pending_orders[razorpay_order_id];
      }

      saveDatabase(db);

      // Save physical copies of invoice inside the workspace receipts directory
      try {
        const receiptsDir = path.join(process.cwd(), "receipts");
        if (!fs.existsSync(receiptsDir)) {
          fs.mkdirSync(receiptsDir, { recursive: true });
        }

        const invoice = mapOrderToInvoice(finalOrder);
        const txtContent = generateASCIIInvoice(invoice);
        const htmlContent = generateHTMLInvoice(invoice);

        fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.txt`), txtContent, "utf8");
        fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.html`), htmlContent, "utf8");

        // Dispatch real email invoice via Nodemailer if SMTP configured
        if (invoice.email) {
          sendInvoiceEmail(invoice, invoice.email).catch((err) => {
            console.error("Nodemailer automatic dispatch failed:", err);
          });
          sendOrderEmail({
            to: invoice.email,
            customerName: invoice.customerName,
            orderId: orderId,
            totalAmount: invoice.totalAmount,
            trackingId: trackingId
          }).catch((err) => {
            console.error("Nodemailer automatic sendOrderEmail dispatch failed:", err);
          });
        }
      } catch (saveErr) {
        console.error("Failed to write physical invoice copies:", saveErr);
      }

      res.json({
        success: true,
        orderId,
        trackingId,
        order: finalOrder
      });
    } catch (err: any) {
      console.error("[VERIFY PAYMENT ERROR]:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Razorpay Webhook Verification Endpoint
  app.post("/api/razorpay/webhook", async (req, res) => {
    try {
      const signature = req.headers["x-razorpay-signature"] as string || "";
      const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET || "rzp_webhook_secret_demo";

      if (!signature) {
        res.status(400).json({ success: false, error: "Missing x-razorpay-signature header." });
        return;
      }

      // Capture raw body
      const rawBody = (req as any).rawBody ? (req as any).rawBody.toString("utf8") : JSON.stringify(req.body);

      // Verify signature via standard crypto Hmac comparison
      const expectedSignature = crypto
        .createHmac("sha256", webhookSecret)
        .update(rawBody)
        .digest("hex");

      if (signature !== expectedSignature) {
        res.status(400).json({ success: false, error: "Invalid signature" });
        return;
      }

      const event = req.body;
      const eventName = event.event;

      // React to order.paid or payment.captured
      if (eventName === "order.paid" || eventName === "payment.captured") {
        const rzpOrderId = event.payload?.payment?.entity?.order_id || event.payload?.order?.entity?.id;
        const rzpPaymentId = event.payload?.payment?.entity?.id || `pay_${Date.now()}`;

        if (!rzpOrderId) {
          res.json({ success: true, message: "Webhook processed, but order_id not found in payload." });
          return;
        }

        db = loadDatabase();

        // 1. Is this order already processed in database?
        const existingOrder = Object.values(db.orders).find(
          (ord: any) => ord.razorpayOrderId === rzpOrderId
        );

        if (existingOrder) {
          console.log(`[RAZORPAY WEBHOOK] Order ${existingOrder.id} has already been verified and database entry was created.`);
          res.json({ success: true, message: "Order already finalized." });
          return;
        }

        // 2. Safely recover the complete order items configuration
        const pendingOrder = db.pending_orders ? db.pending_orders[rzpOrderId] : null;

        const orderNum = Math.floor(100000 + Math.random() * 900000);
        const trackingNum = Math.floor(10000000 + Math.random() * 90000000);
        const orderId = `ZS-ORD-${orderNum}`;
        const trackingId = `ZS-TRK-${trackingNum}`;

        const finalOrder: Order = {
          id: orderId,
          trackingId,
          date: new Date().toISOString(),
          items: pendingOrder?.cartItems || pendingOrder?.items || [],
          subtotal: pendingOrder?.subtotal || 0,
          discount: pendingOrder?.discount || 0,
          shipping: pendingOrder?.shipping || 0,
          total: pendingOrder?.total || 0,
          address: pendingOrder?.shippingAddress || pendingOrder?.address || {
            fullName: "Guest Customer",
            phone: "9999999999",
            streetAddress: "Ziva Street Atelier, Bandra Colaba",
            city: "Mumbai",
            state: "Maharashtra",
            pinCode: "400050"
          },
          status: "ordered",
          couponCode: pendingOrder?.couponCode,
          razorpayOrderId: rzpOrderId,
          razorpayPaymentId: rzpPaymentId
        };

        db.orders[trackingId] = finalOrder;
        db.orders[orderId] = finalOrder;

        if (pendingOrder?.userId && db.users[pendingOrder.userId]) {
          db.users[pendingOrder.userId].orders.unshift(finalOrder);
          db.users[pendingOrder.userId].cart = [];
        }

        // Tidy up
        if (db.pending_orders && db.pending_orders[rzpOrderId]) {
          delete db.pending_orders[rzpOrderId];
        }

        saveDatabase(db);

        // Save physical copies of invoice inside workspace receipts directory
        try {
          const receiptsDir = path.join(process.cwd(), "receipts");
          if (!fs.existsSync(receiptsDir)) {
            fs.mkdirSync(receiptsDir, { recursive: true });
          }

          const invoice = mapOrderToInvoice(finalOrder);
          const txtContent = generateASCIIInvoice(invoice);
          const htmlContent = generateHTMLInvoice(invoice);

          fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.txt`), txtContent, "utf8");
          fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.html`), htmlContent, "utf8");

          // Dispatch email notifications
          if (invoice.email) {
            sendInvoiceEmail(invoice, invoice.email).catch((err) => {
              console.error("Nodemailer webhook invoice email failed:", err);
            });
            sendOrderEmail({
              to: invoice.email,
              customerName: invoice.customerName,
              orderId: orderId,
              totalAmount: invoice.totalAmount,
              trackingId: trackingId
            }).catch((err) => {
              console.error("Nodemailer webhook sendOrderEmail failed:", err);
            });
          }
        } catch (saveErr) {
          console.error("Webhook invoice write error:", saveErr);
        }

        console.log(`[RAZORPAY WEBHOOK PROCESSING SUCCESS] Order registered: ${orderId}`);
      }

      res.json({ success: true });
    } catch (err: any) {
      console.error("[RAZORPAY WEBHOOK EXCEPTION]:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Place Order Route
  app.post("/api/checkout", (req, res) => {
    const { 
      userId, 
      cartItems, 
      shippingAddress, 
      couponCode, 
      subtotal, 
      discount, 
      shipping, 
      total,
      razorpay_signature,
      razorpay_payment_id,
      razorpay_order_id
    } = req.body;

    if (!cartItems || cartItems.length === 0) {
      res.status(400).json({ error: "Cannot checkout empty cart." });
      return;
    }

    // Razorpay signature verification
    if (razorpay_signature || razorpay_payment_id || razorpay_order_id) {
      if (!razorpay_signature || !razorpay_payment_id || !razorpay_order_id) {
        res.status(400).json({ error: "Incomplete Razorpay payment information." });
        return;
      }
      const keySecret = process.env.RAZORPAY_KEY_SECRET;
      if (!keySecret) {
        res.status(500).json({ error: "Razorpay signature verification failed because Razorpay secret keys are not configured on this server." });
        return;
      }
      const text = `${razorpay_order_id}|${razorpay_payment_id}`;
      const generated_signature = crypto
        .createHmac("sha256", keySecret)
        .update(text)
        .digest("hex");

      if (generated_signature !== razorpay_signature) {
        res.status(400).json({ error: "Razorpay payment verification failed: Unmatched HMAC SHA256 payment signature." });
        return;
      }
    }

    db = loadDatabase();

    // Create custom IDs
    const orderNum = Math.floor(100000 + Math.random() * 900000);
    const trackingNum = Math.floor(10000000 + Math.random() * 90000000);
    const orderId = `ZS-ORD-${orderNum}`;
    const trackingId = `ZS-TRK-${trackingNum}`;

    const newOrder: Order = {
      id: orderId,
      trackingId,
      date: new Date().toISOString(),
      items: cartItems,
      subtotal,
      discount,
      shipping,
      total,
      address: shippingAddress || {
        fullName: "Guest Customer",
        phone: "9999999999",
        streetAddress: "Ziva Street Atelier, Bandra Colaba",
        city: "Mumbai",
        state: "Maharashtra",
        pinCode: "400050"
      },
      status: "ordered",
      couponCode,
      razorpayOrderId: razorpay_order_id,
      razorpayPaymentId: razorpay_payment_id
    };

    // Save order globally
    db.orders[trackingId] = newOrder;
    db.orders[orderId] = newOrder; // Save under both keys for ease of checkout tracking lookups

    // If logged in, save in their history and clear active cart
    if (userId && db.users[userId]) {
      db.users[userId].orders.unshift(newOrder); // Add to top of array
      db.users[userId].cart = []; // Reset active cart upon successful purchase
    }

    saveDatabase(db);

    // Save physical copies of invoice inside the workspace receipts directory under both .txt and .html styles
    try {
      const receiptsDir = path.join(process.cwd(), "receipts");
      if (!fs.existsSync(receiptsDir)) {
        fs.mkdirSync(receiptsDir, { recursive: true });
      }

      const invoice = mapOrderToInvoice(newOrder);
      const txtContent = generateASCIIInvoice(invoice);
      const htmlContent = generateHTMLInvoice(invoice);

      fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.txt`), txtContent, "utf8");
      fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.html`), htmlContent, "utf8");
      console.log(`Saved physical receipt workspace files for Order ${orderId}`);

      // Dispatch real email invoice via Nodemailer if SMTP configured
      if (invoice.email) {
        sendInvoiceEmail(invoice, invoice.email).catch((err) => {
          console.error("Nodemailer automatic dispatch failed:", err);
        });
        sendOrderEmail({
          to: invoice.email,
          customerName: invoice.customerName,
          orderId: orderId,
          totalAmount: invoice.totalAmount,
          trackingId: trackingId
        }).catch((err) => {
          console.error("Nodemailer automatic sendOrderEmail dispatch failed:", err);
        });
      }
    } catch (saveErr) {
      console.error("Failed to write physical invoice copies to receipts directory:", saveErr);
    }

    res.json({
      success: true,
      orderId,
      trackingId,
      order: newOrder
    });
  });

  // Express API Route to generate/fetch invoice by orderId
  app.post("/api/invoice/generate", (req, res) => {
    const { orderId } = req.body;
    if (!orderId) {
      res.status(400).json({ error: "orderId is a required parameter." });
      return;
    }
    try {
      const invoice = getInvoiceByOrderId(orderId);

      // Persist physical copy inside workspace receipts directory for simple file-system access/download
      try {
        const receiptsDir = path.join(process.cwd(), "receipts");
        if (!fs.existsSync(receiptsDir)) {
          fs.mkdirSync(receiptsDir, { recursive: true });
        }
        const txtContent = generateASCIIInvoice(invoice);
        const htmlContent = generateHTMLInvoice(invoice);

        fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.txt`), txtContent, "utf8");
        fs.writeFileSync(path.join(receiptsDir, `ZivaStreet_Invoice_${orderId}.html`), htmlContent, "utf8");
        console.log(`Manually generated/persisted physical invoice copies inside workspace for order: ${orderId}`);
      } catch (saveErr) {
        console.error("Failed to write manual invoice copies to receipts directory:", saveErr);
      }

      res.json({
        success: true,
        invoice
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed generating invoice." });
    }
  });

  // Express API Route to email invoice to a specific address
  app.post("/api/invoice/email", (req, res) => {
    const { orderId, email } = req.body;
    if (!orderId || !email) {
      res.status(400).json({ error: "orderId and email are required parameters." });
      return;
    }
    try {
      db = loadDatabase();
      let order = db.orders[orderId];
      let invoice;
      if (order) {
        invoice = mapOrderToInvoice(order);
      } else {
        invoice = getInvoiceByOrderId(orderId);
      }

      // If email parameter is explicitly provided, attach to invoice
      if (email) {
        invoice.email = email;
      }

      sendInvoiceEmail(invoice, email)
        .then((sent) => {
          if (sent) {
            res.json({ success: true, message: `Invoice successfully emailed to ${email}!` });
          } else {
            res.status(500).json({ error: "Email delivery failed. Please check GMAIL_USER and GMAIL_PASS configurations in server secrets." });
          }
        })
        .catch((err) => {
          res.status(500).json({ error: err.message || "Email dispatch failed." });
        });
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed dispatching invoice email." });
    }
  });

  // Express API Route matching user-requested /api/send-email (or Next POST spec)
  app.post("/api/send-email", async (req, res) => {
    try {
      const { email, to, customerName, orderId, totalAmount, trackingId } = req.body;
      const recipient = email || to;

      if (!recipient) {
        res.status(400).json({ success: false, error: "Recipient email parameter 'email' or 'to' is required." });
        return;
      }

      await sendOrderEmail({
        to: recipient,
        customerName: customerName || "Customer",
        orderId: orderId || `ZS-ORD-${Math.floor(Math.random() * 900000)}`,
        totalAmount: Number(totalAmount) || 0,
        trackingId: trackingId || "N/A"
      });

      res.json({ success: true });
    } catch (error: any) {
      console.error("[NODEMAILER API] Error sending order email:", error);
      res.json({ success: false, error: error.message });
    }
  });

  // Express API Route for /api/email/send-order
  app.post("/api/email/send-order", async (req, res) => {
    try {
      const { email, to, customerName, orderId, totalAmount, trackingId } = req.body;
      const recipient = email || to;

      if (!recipient) {
        res.status(400).json({ success: false, error: "Recipient email parameter 'email' or 'to' is required." });
        return;
      }

      await sendOrderEmail({
        to: recipient,
        customerName: customerName || "Customer",
        orderId: orderId || `ZS-ORD-${Math.floor(Math.random() * 900000)}`,
        totalAmount: Number(totalAmount) || 0,
        trackingId: trackingId || "N/A"
      });

      res.json({ success: true });
    } catch (error: any) {
      console.error("[NODEMAILER API] Error sending order email:", error);
      res.json({ success: false, error: error.message });
    }
  });

  // WhatsApp Order Confirmation endpoint
  app.post("/api/whatsapp/send-confirmation", async (req, res) => {
    try {
      const { customerName, phone, orderId, trackingId, totalAmount, items = [] } = req.body;

      const token = process.env.WHATSAPP_TOKEN;
      const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
      const templateName = process.env.WHATSAPP_TEMPLATE_NAME || "order_confirmation";

      if (!token || !phoneNumberId) {
        console.log(`[WhatsApp API Simulated] Sending confirmation template "${templateName}" to phone: ${phone}`);
        console.log(`Para: Name=${customerName}, Order=${orderId}, Total=₹${totalAmount}, Tracking=${trackingId}`);
        res.json({ 
          ok: true, 
          simulated: true, 
          message: "Simulation mode active. Set WHATSAPP_TOKEN and WHATSAPP_PHONE_NUMBER_ID in environment secrets for live broadcasts." 
        });
        return;
      }

      const payload = {
        messaging_product: "whatsapp",
        to: phone,
        type: "template",
        template: {
          name: templateName,
          language: { code: "en_US" },
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: customerName },
                { type: "text", text: orderId },
                { type: "text", text: `₹${totalAmount.toFixed(2)}` },
                { type: "text", text: trackingId },
              ],
            },
          ],
        },
      };

      const metaRes = await fetch(
        `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await metaRes.json();

      if (!metaRes.ok) {
        res.status(400).json({ ok: false, error: data });
        return;
      }

      res.json({ ok: true, data });
    } catch (error: any) {
      res.status(500).json({ ok: false, error: error.message || "Failed to send WhatsApp message" });
    }
  });

  // Track Order Route
  app.post("/api/orders/track", (req, res) => {
    const { trackingId } = req.body;
    if (!trackingId) {
      res.status(400).json({ error: "Order/Tracking ID is required." });
      return;
    }

    db = loadDatabase();
    const cleanId = trackingId.trim();
    const order = db.orders[cleanId];

    if (!order) {
      res.status(404).json({ error: "No shipment or order found with that ID." });
      return;
    }

    // Dynamic Tracking status progression based on order date
    // ordered -> packed -> shipped -> out_for_delivery -> delivered
    const orderTime = new Date(order.date).getTime();
    const now = Date.now();
    const diffMins = Math.floor((now - orderTime) / (1000 * 60)); // real progress

    let status: 'ordered' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled' = 'ordered';
    if (diffMins >= 15) {
      status = 'delivered';
    } else if (diffMins >= 8) {
      status = 'out_for_delivery';
    } else if (diffMins >= 4) {
      status = 'shipped';
    } else if (diffMins >= 1) {
      status = 'packed';
    } else {
      status = order.status || 'ordered';
    }

    // Keep it up to date in DB as well
    if (order.status !== status) {
      order.status = status;
      db.orders[cleanId] = order;
      // Also update inside target user container if user is linked
      for (const uk in db.users) {
        const u = db.users[uk];
        const ordIndex = u.orders.findIndex((o) => o.id === order.id);
        if (ordIndex >= 0) {
          u.orders[ordIndex].status = status;
        }
      }
      saveDatabase(db);
    }

    res.json({
      success: true,
      order
    });
  });

  // Delhivery API: Create shipment order on Delhivery
  app.post("/api/shipping/create-order", async (req, res) => {
    try {
      const { orderId, amount, quantity, description, address } = req.body;
      if (!orderId || !address) {
        res.status(400).json({ error: "orderId and address are required fields." });
        return;
      }
      const result = await createDelhiveryShipment({
        orderId,
        amount: Number(amount || 0),
        quantity: Number(quantity || 1),
        description: description || "Signature Streetwear Garments",
        address
      });
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed to create Delhivery shipping order" });
    }
  });

  // Delhivery API: Track waybill route details on Delhivery
  app.post("/api/shipping/track", async (req, res) => {
    try {
      const { waybill, orderDate, orderId } = req.body;
      if (!waybill) {
        res.status(400).json({ error: "waybill is a required field." });
        return;
      }
      const result = await trackDelhiveryShipment(waybill, orderDate, orderId);
      res.json(result);
    } catch (e: any) {
      res.status(500).json({ error: e.message || "Failed tracking Delhivery waybill" });
    }
  });

  // Lazy Initialize Gemini API client
  const geminiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;
  if (geminiKey) {
    ai = new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }

  // AI Chatbot DADU Route
  app.post("/api/chat", async (req, res) => {
    const { message, history, context } = req.body;
    if (!message) {
      res.status(400).json({ error: "Message is required." });
      return;
    }

    const { userId, currentCart, orderHistory } = context || {};
    
    // Build context info for DADU
    const ordersSummary = orderHistory && orderHistory.length > 0
      ? orderHistory.map((o: any) => `Order ID: ${o.id}, Tracking ID: ${o.trackingId}, Total: ₹${o.total}, Status: ${o.status}, Date: ${new Date(o.date).toLocaleDateString()}`).join("\n")
      : "No order history found for this session.";

    const cartSummary = currentCart && currentCart.length > 0
      ? currentCart.map((i: any) => `${i.product.name} (Size: ${i.selectedSize}, Qty: ${i.quantity})`).join(", ")
      : "Active cart is empty.";

    const SYSTEM_PROMPT = `You are "DADU", the extremely warm, helpful, cute, and stylish older grandfatherly assistant for "Ziva Street" — a premium luxury Indo-streetwear clothing brand.
You talk in a friendly, gentle, slightly traditional yet very trendy streetwear-inspired grandfatherly tone with deep respect (using polite phrases, addressing them affectionately, and staying upbeat as a style connoisseur who loves streetwear drapes).
Keep your answers helpful, friendly, and relatively short.

RULES & WEB HELP KNOWLEDGE:
- BRAND NAME: "Ziva Street". Streetwear fusion merged with traditional luxury Indian textiles (heavy drapes, modern linen kurtas, Zardozi silk bomber jackets, utility cargo bandhgalas).
- ACTIVE COUPON: "DADU" provides 20% off total cart value! Remind users of this coupon if they ask about discounts or payments!
- FREE DELIVERY: We provide free shipping for all orders above ₹699. For other orders, standard shipping is ₹99.
- HOW TO ACCESS SECTIONS:
  - Return to Home, Shop Men or Women clothes directly on the main page.
  - Profile dropdown (clicking on User/Profile icon) has "Orders", "Track Order", "Address Book", and "Logout".
- LOGIN SYSTEM: Explain that new users can log in instantly with their phone number using OTP 123456 (simulated demo) or via email and password!
- TRACKING HELP: If they ask about order status, search for their Order/Tracking ID or help them understand they can use "Track Order" inside client interface, or paste their Tracking ID here!
- PAYMENT METHOD: We support a simulated instant demo payment mode. Simply tap "Payment Done" to generate a real-time invoice, order number, and tracking details.

CURRENT SESSION USER CONTEXT (USE IF HELPFUL):
- User profile linked: ${userId ? `Yes (${userId})` : "Guest / Not signed in yet"}
- User Active Cart: ${cartSummary}
- User Registered Order History:
${ordersSummary}

Instructions:
- Always reply in a welcoming DADU persona. Do not speak about raw system logs or internal code.
- Keep standard text replies highly readable in brief Markdown. Keep answers to 2-4 sentences max unless detailing steps.
- Make them feel pampered by DADU's customer hospitality! Use Indian clothing vocabulary with active respect.`;

    if (ai) {
      try {
        // Construct standard inputs for generateContent
        const formattedContents = [];
        
        // Map history to contents
        if (history && history.length > 0) {
          // Keep only last 10 messages for safety & performance
          const chatHistory = history.slice(-10);
          for (const msg of chatHistory) {
            formattedContents.push({
              role: msg.sender === "user" ? "user" : "model",
              parts: [{ text: msg.text }]
            });
          }
        }

        // Push current message
        formattedContents.push({
          role: "user",
          parts: [{ text: message }]
        });

        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: formattedContents,
          config: {
            systemInstruction: SYSTEM_PROMPT,
            temperature: 0.75,
            topP: 0.95
          }
        });

        res.json({
          success: true,
          reply: response.text || "Dadu was momentarily thinking. What else can I help you find today, beta?"
        });
        return;
      } catch (error) {
        console.error("Gemini API call failed:", error);
      }
    }

    // Simple rule-based smart fallback if GEMINI_API_KEY is not defined or fails
    const lower = message.toLowerCase();
    let reply = "Namaste beta! I am Dadu. ";
    
    if (lower.includes("track") || lower.includes("status") || lower.includes("where is my order")) {
      reply += "To track your gorgeous Ziva Street order, simply type the Tracking ID (like 'ZS-TRK-...') in the 'Track Order' option under your profile menu, or tell Dadu your Tracking ID. Dadu will search our courier registry instantly!";
    } else if (lower.includes("coupon") || lower.includes("discount") || lower.includes("promo") || lower.includes("offer") || lower.includes("dadu")) {
      reply += "Aha! Code **DADU** gives you flat **20% off** your entire purchase! Make sure to write 'DADU' in the coupon field in your cart before checking out, beta.";
    } else if (lower.includes("free") || lower.includes("shipping") || lower.includes("delivery")) {
      reply += "We offer complimentary express shipping across India on all purchases over ₹699! Otherwise, standard shipping is just ₹99.";
    } else if (lower.includes("pay") || lower.includes("checkout") || lower.includes("buy")) {
      reply += "Our checkout is very easy! Tap the cart icon, input your address, add code **DADU** for discounted rates, and click 'Payment Done'. It uses our simulated demo payment for immediate processing.";
    } else if (lower.includes("fabric") || lower.includes("material") || lower.includes("cloth") || lower.includes("size")) {
      reply += "Every apparel piece is handcrafted with handloomed cotton, rich linen, and premium organza, tailored as oversized streetwear. Use our integrated size selection option (XS-XXL) in the clothes display to match your fit.";
    } else {
      reply += "I'm always here to help you beta! You can ask Dadu about active coupons (hint: type **DADU**), tracking your custom parcel deliveries, updating your address, or navigating our street collections.";
    }

    res.json({
      success: true,
      reply
    });
  });

  // ==========================================
  //            ADMIN API ENDPOINTS
  // ==========================================

  // Admin Login
  app.post("/api/admin/login", (req, res) => {
    const { username, password } = req.body;
    if (username === "admin" && password === "admin") {
      res.json({
        success: true,
        user: { id: "admin-1", username: "admin", role: "admin", token: "mock-ziva-token" }
      });
    } else {
      res.status(401).json({ success: false, error: "Invalid admin credentials. Use admin / admin." });
    }
  });

  // Admin Dashboard Statistics
  app.get("/api/admin/dashboard-stats", (req, res) => {
    db = loadDatabase();
    const ordersList = Object.values(db.orders || {}).filter((ord, idx, self) =>
      self.findIndex(o => o.id === ord.id) === idx
    );

    const totalOrders = ordersList.length;
    const totalRevenue = ordersList.reduce((sum, o) => {
      return o.status !== 'cancelled' ? sum + o.total : sum;
    }, 0);

    const usersCount = Object.keys(db.users || {}).length;
    const uniqueOrderers = new Set(ordersList.map(o => o.address.fullName + o.address.phone));
    const totalCustomers = Math.max(usersCount, uniqueOrderers.size);

    const pendingOrders = ordersList.filter(o => o.status === 'ordered').length;
    const shippedOrders = ordersList.filter(o => o.status === 'shipped' || o.status === 'out_for_delivery').length;
    const deliveredOrders = ordersList.filter(o => o.status === 'delivered').length;
    const cancelledOrders = ordersList.filter(o => o.status === 'cancelled').length;

    const productsList = db.products || DEFAULT_PRODUCTS;
    const lowStockList = productsList.filter(p => {
      const pStock = (p as any).stock;
      return pStock !== undefined ? pStock < 5 : false;
    });

    const salesChart = [
      { name: "Jan", sales: 12000, orders: 8 },
      { name: "Feb", sales: 15500, orders: 11 },
      { name: "Mar", sales: 24000, orders: 15 },
      { name: "Apr", sales: 18000, orders: 12 },
      { name: "May", sales: 31000, orders: 19 },
      { name: "Jun", sales: totalRevenue > 0 ? totalRevenue : 45000, orders: totalOrders > 0 ? totalOrders : 25 }
    ];

    const couponsList = db.coupons || DEFAULT_COUPONS;
    const couponStats = couponsList.map(c => ({
      code: c.code,
      useCount: c.usageCount,
      discount: c.discountPercent
    }));

    const topProducts = productsList.slice(0, 3).map(p => ({
      ...p,
      salesCount: p.price > 3000 ? 14 : 28,
      revenueGenerated: (p.price > 3000 ? 14 : 28) * p.price
    }));

    res.json({
      success: true,
      stats: {
        totalOrders,
        totalRevenue,
        totalCustomers,
        pendingOrders,
        shippedOrders,
        deliveredOrders,
        cancelledOrders,
        lowStockCount: lowStockList.length,
        salesChart,
        couponStats,
        topProducts
      },
      recentOrders: ordersList.slice(0, 5),
      recentCustomers: Object.values(db.users || {}).slice(0, 5).map(u => ({
        id: u.id,
        fullName: u.fullName,
        phone: u.phone,
        email: u.email,
        totalSpent: u.orders ? u.orders.reduce((sum, o) => sum + o.total, 0) : 0,
        lastOrderDate: u.orders && u.orders.length > 0 ? u.orders[0].date : "N/A"
      }))
    });
  });

  // Admin Orders API
  app.get("/api/admin/orders", (req, res) => {
    db = loadDatabase();
    const ordersList = Object.values(db.orders || {}).filter((ord, idx, self) =>
      self.findIndex(o => o.id === ord.id) === idx
    );
    res.json({ success: true, orders: ordersList });
  });

  // Admin Order update (status, tracking ID, courier tracking, invoice resend, cancel)
  app.put("/api/admin/orders/:id", (req, res) => {
    const { id } = req.params;
    const { status, trackingId, address, total } = req.body;
    db = loadDatabase();

    const order = db.orders[id];
    if (!order) {
      res.status(404).json({ success: false, error: "Order not found." });
      return;
    }

    if (status) order.status = status;
    if (trackingId) {
      const oldTrackingId = order.trackingId;
      order.trackingId = trackingId;
      db.orders[trackingId] = order;
      if (oldTrackingId && oldTrackingId !== trackingId) {
        delete db.orders[oldTrackingId];
      }
    }
    if (address) order.address = address;
    if (total !== undefined) order.total = total;

    db.orders[id] = order;
    db.orders[order.trackingId] = order;

    Object.values(db.users).forEach(u => {
      const uOrderIdx = (u.orders || []).findIndex(o => o.id === id);
      if (uOrderIdx !== -1) {
        u.orders[uOrderIdx] = order;
      }
    });

    saveDatabase(db);
    res.json({ success: true, order });
  });

  // Admin Order Resends (Resend Invoice or Email alerts)
  app.post("/api/admin/orders/:id/resend-notifications", (req, res) => {
    const { id } = req.params;
    const { channel } = req.body;
    db = loadDatabase();
    const order = db.orders[id];
    if (!order) {
      res.status(404).json({ success: false, error: "Order not found." });
      return;
    }

    console.log(`[ADMIN FORCE RESEND] Dispatched order ${id} updates via: ${channel}`);
    res.json({ success: true, message: `Successfully re-sent order ${id} updates via ${channel.toUpperCase()}!` });
  });

  // Product CRUD
  app.post("/api/admin/products", (req, res) => {
    const { name, description, price, category, image, sizes, tag, originalPrice, stock, active } = req.body;
    if (!name || !price || !category) {
      res.status(400).json({ success: false, error: "Name, price and category are required." });
      return;
    }

    db = loadDatabase();
    const newProduct: Product = {
      id: `${category}-${Date.now()}`,
      name,
      description: description || "",
      price: Number(price),
      category,
      image: image || "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&q=80&w=600",
      sizes: sizes || ["S", "M", "L", "XL"],
      tag: tag || "",
      originalPrice: originalPrice ? Number(originalPrice) : undefined
    };
    (newProduct as any).stock = stock !== undefined ? Number(stock) : 15;
    (newProduct as any).active = active !== undefined ? Boolean(active) : true;

    if (!db.products) db.products = DEFAULT_PRODUCTS;
    db.products.push(newProduct);
    saveDatabase(db);

    res.json({ success: true, product: newProduct });
  });

  app.put("/api/admin/products/:id", (req, res) => {
    const { id } = req.params;
    const { name, description, price, category, image, sizes, tag, originalPrice, stock, active } = req.body;
    db = loadDatabase();

    const productsList = db.products || DEFAULT_PRODUCTS;
    const idx = productsList.findIndex(p => p.id === id);
    if (idx === -1) {
      res.status(404).json({ success: false, error: "Product not found." });
      return;
    }

    const updated = {
      ...productsList[idx],
      name: name || productsList[idx].name,
      description: description !== undefined ? description : productsList[idx].description,
      price: price !== undefined ? Number(price) : productsList[idx].price,
      category: category || productsList[idx].category,
      image: image || productsList[idx].image,
      sizes: sizes || productsList[idx].sizes,
      tag: tag !== undefined ? tag : productsList[idx].tag,
      originalPrice: originalPrice !== undefined ? (originalPrice ? Number(originalPrice) : undefined) : productsList[idx].originalPrice,
      stock: stock !== undefined ? Number(stock) : (productsList[idx] as any).stock ?? 15,
      active: active !== undefined ? Boolean(active) : (productsList[idx] as any).active ?? true
    };

    productsList[idx] = updated;
    db.products = productsList;
    saveDatabase(db);

    res.json({ success: true, product: updated });
  });

  app.delete("/api/admin/products/:id", (req, res) => {
    const { id } = req.params;
    db = loadDatabase();

    const productsList = db.products || DEFAULT_PRODUCTS;
    const filtered = productsList.filter(p => p.id !== id);
    if (productsList.length === filtered.length) {
      res.status(404).json({ success: false, error: "Product not found." });
      return;
    }

    db.products = filtered;
    saveDatabase(db);
    res.json({ success: true, message: "Product deleted successfully." });
  });

  // Coupons CRUD
  app.get("/api/admin/coupons", (req, res) => {
    db = loadDatabase();
    res.json({ success: true, coupons: db.coupons || DEFAULT_COUPONS });
  });

  app.post("/api/admin/coupons", (req, res) => {
    const { code, discountPercent, minCartValue, usageLimit, active } = req.body;
    if (!code || !discountPercent) {
      res.status(400).json({ success: false, error: "Code and discount percent are required." });
      return;
    }

    db = loadDatabase();
    if (!db.coupons) db.coupons = DEFAULT_COUPONS;

    const newCoupon: Coupon = {
      id: `c-${Date.now()}`,
      code: String(code).toUpperCase(),
      discountPercent: Number(discountPercent),
      minCartValue: minCartValue ? Number(minCartValue) : 0,
      usageLimit: usageLimit ? Number(usageLimit) : undefined,
      usageCount: 0,
      active: active !== undefined ? Boolean(active) : true
    };

    db.coupons.push(newCoupon);
    saveDatabase(db);
    res.json({ success: true, coupon: newCoupon });
  });

  app.put("/api/admin/coupons/:id", (req, res) => {
    const { id } = req.params;
    const { code, discountPercent, minCartValue, usageLimit, active, usageCount } = req.body;
    db = loadDatabase();

    if (!db.coupons) db.coupons = DEFAULT_COUPONS;
    const idx = db.coupons.findIndex(c => c.id === id);
    if (idx === -1) {
      res.status(404).json({ success: false, error: "Coupon not found" });
      return;
    }

    db.coupons[idx] = {
      ...db.coupons[idx],
      code: code ? String(code).toUpperCase() : db.coupons[idx].code,
      discountPercent: discountPercent !== undefined ? Number(discountPercent) : db.coupons[idx].discountPercent,
      minCartValue: minCartValue !== undefined ? Number(minCartValue) : db.coupons[idx].minCartValue,
      usageLimit: usageLimit !== undefined ? (usageLimit ? Number(usageLimit) : undefined) : db.coupons[idx].usageLimit,
      usageCount: usageCount !== undefined ? Number(usageCount) : db.coupons[idx].usageCount,
      active: active !== undefined ? Boolean(active) : db.coupons[idx].active
    };

    saveDatabase(db);
    res.json({ success: true, coupon: db.coupons[idx] });
  });

  app.delete("/api/admin/coupons/:id", (req, res) => {
    const { id } = req.params;
    db = loadDatabase();

    if (!db.coupons) db.coupons = DEFAULT_COUPONS;
    const filtered = db.coupons.filter(c => c.id !== id);
    db.coupons = filtered;
    saveDatabase(db);
    res.json({ success: true });
  });

  // Banners CRUD
  app.get("/api/admin/banners", (req, res) => {
    db = loadDatabase();
    res.json({ success: true, banners: db.banners || DEFAULT_BANNERS });
  });

  app.post("/api/admin/banners", (req, res) => {
    const { image, title, subtitle, ctaText, active } = req.body;
    db = loadDatabase();
    if (!db.banners) db.banners = DEFAULT_BANNERS;

    const newBanner: Banner = {
      id: `b-${Date.now()}`,
      image: image || "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&q=80&w=1200",
      title: title || "New Campaign",
      subtitle: subtitle || "",
      ctaText: ctaText || "Explore",
      active: active !== undefined ? Boolean(active) : true
    };

    db.banners.push(newBanner);
    saveDatabase(db);
    res.json({ success: true, banner: newBanner });
  });

  app.put("/api/admin/banners/:id", (req, res) => {
    const { id } = req.params;
    const { image, title, subtitle, ctaText, active } = req.body;
    db = loadDatabase();
    if (!db.banners) db.banners = DEFAULT_BANNERS;

    const idx = db.banners.findIndex(b => b.id === id);
    if (idx === -1) {
      res.status(404).json({ success: false, error: "Banner not found." });
      return;
    }

    db.banners[idx] = {
      ...db.banners[idx],
      image: image || db.banners[idx].image,
      title: title !== undefined ? title : db.banners[idx].title,
      subtitle: subtitle !== undefined ? subtitle : db.banners[idx].subtitle,
      ctaText: ctaText !== undefined ? ctaText : db.banners[idx].ctaText,
      active: active !== undefined ? Boolean(active) : db.banners[idx].active
    };

    saveDatabase(db);
    res.json({ success: true, banner: db.banners[idx] });
  });

  app.delete("/api/admin/banners/:id", (req, res) => {
    const { id } = req.params;
    db = loadDatabase();
    if (!db.banners) db.banners = DEFAULT_BANNERS;

    db.banners = db.banners.filter(b => b.id !== id);
    saveDatabase(db);
    res.json({ success: true });
  });

  // Support messages CRUD
  app.get("/api/admin/support-messages", (req, res) => {
    db = loadDatabase();
    res.json({ success: true, messages: db.supportMessages || DEFAULT_SUPPORT_MESSAGES });
  });

  app.post("/api/admin/support-messages/:id/reply", (req, res) => {
    const { id } = req.params;
    const { reply } = req.body;
    db = loadDatabase();
    if (!db.supportMessages) db.supportMessages = DEFAULT_SUPPORT_MESSAGES;

    const idx = db.supportMessages.findIndex(m => m.id === id);
    if (idx === -1) {
      res.status(404).json({ success: false, error: "Message not found." });
      return;
    }

    db.supportMessages[idx].status = "replied";
    db.supportMessages[idx].reply = reply || "";
    saveDatabase(db);

    res.json({ success: true, message: db.supportMessages[idx] });
  });

  // Settings CRM
  app.get("/api/admin/settings", (req, res) => {
    db = loadDatabase();
    res.json({ success: true, settings: db.siteSettings || DEFAULT_SETTINGS });
  });

  app.put("/api/admin/settings", (req, res) => {
    const { taxRate, freeDeliveryThreshold, shopOpen, statusMessage } = req.body;
    db = loadDatabase();

    db.siteSettings = {
      taxRate: taxRate !== undefined ? Number(taxRate) : (db.siteSettings?.taxRate ?? 5),
      freeDeliveryThreshold: freeDeliveryThreshold !== undefined ? Number(freeDeliveryThreshold) : (db.siteSettings?.freeDeliveryThreshold ?? 699),
      shopOpen: shopOpen !== undefined ? Boolean(shopOpen) : (db.siteSettings?.shopOpen !== false),
      statusMessage: statusMessage !== undefined ? statusMessage : (db.siteSettings?.statusMessage ?? "Unlock 20% OFF sitewide with coupon: DADU")
    };

    saveDatabase(db);
    res.json({ success: true, settings: db.siteSettings });
  });

  // Serve static assets in production, and delegate to Vite in dev
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Ziva Street fashion server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
