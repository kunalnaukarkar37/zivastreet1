/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { getInvoiceByOrderId } from '../../../lib/invoice';
import InvoiceTemplate from '../../../components/invoice/InvoiceTemplate';

interface Params {
  orderId: string;
}

export default function InvoicePage({ params }: { params: Params }) {
  // Retrieve invoice data either procedurally or dynamically
  const invoice = getInvoiceByOrderId(params.orderId);

  return (
    <div className="min-h-screen bg-stone-50 py-10 print:bg-white print:py-0">
      <InvoiceTemplate invoice={invoice} />
    </div>
  );
}
