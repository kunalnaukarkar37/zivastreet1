import { NextRequest, NextResponse } from 'next/server';
import { trackDelhiveryShipment } from '../../../../lib/delhivery';

export async function POST(request: NextRequest) {
  try {
    const { waybill, orderDate, orderId } = await request.json();

    if (!waybill) {
      return NextResponse.json(
        { error: 'waybill is a required field.' },
        { status: 400 }
      );
    }

    const response = await trackDelhiveryShipment(waybill, orderDate, orderId);

    return NextResponse.json(response);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Internal Server Error' },
      { status: 500 }
    );
  }
}
