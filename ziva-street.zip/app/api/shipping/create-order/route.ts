import { NextRequest, NextResponse } from 'next/server';
import { createDelhiveryShipment } from '../../../../lib/delhivery';

export async function POST(request: NextRequest) {
  try {
    const { orderId, amount, quantity, description, address } = await request.json();

    if (!orderId || !address) {
      return NextResponse.json(
        { error: 'orderId and address are required fields.' },
        { status: 400 }
      );
    }

    const response = await createDelhiveryShipment({
      orderId,
      amount: Number(amount || 0),
      quantity: Number(quantity || 1),
      description: description || 'Signature Streetwear Garments',
      address
    });

    return NextResponse.json(response);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Internal Server Error' },
      { status: 500 }
    );
  }
}
