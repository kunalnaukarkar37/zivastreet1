/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NextResponse } from "next/server";

type Item = {
  name: string;
  size?: string;
  quantity: number;
  price: number;
};

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      customerName,
      phone, // should be in international format, e.g. 91XXXXXXXXXX
      orderId,
      trackingId,
      totalAmount,
      items = [],
    }: {
      customerName: string;
      phone: string;
      orderId: string;
      trackingId: string;
      totalAmount: number;
      items: Item[];
    } = body;

    const token = process.env.WHATSAPP_TOKEN;
    const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
    const templateName = process.env.WHATSAPP_TEMPLATE_NAME || "order_confirmation";

    if (!token || !phoneNumberId) {
      return NextResponse.json(
        { ok: false, error: "Missing WhatsApp API env vars" },
        { status: 500 }
      );
    }

    // This must match the approved WhatsApp template variables exactly.
    const payload = {
      messaging_product: "whatsapp",
      to: phone,
      type: "template",
      template: {
        name: templateName,
        language: { code: "en_US" },
        components: [
          {
            type: "body",
            parameters: [
              { type: "text", text: customerName },
              { type: "text", text: orderId },
              { type: "text", text: `₹${totalAmount.toFixed(2)}` },
              { type: "text", text: trackingId },
            ],
          },
        ],
      },
    };

    const res = await fetch(
      `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }
    );

    const data = await res.json();

    if (!res.ok) {
      return NextResponse.json(
        { ok: false, error: data },
        { status: 400 }
      );
    }

    return NextResponse.json({ ok: true, data });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: "Failed to send WhatsApp message" },
      { status: 500 }
    );
  }
}
