/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NextResponse } from 'next/server';
import { getInvoiceByOrderId } from '../../../../lib/invoice';

export async function POST(request: Request) {
  try {
    const { orderId } = await request.json();

    if (!orderId) {
      return NextResponse.json(
        { error: 'orderId parameter is required inside request payload.' },
        { status: 400 }
      );
    }

    const invoice = getInvoiceByOrderId(orderId);

    return NextResponse.json({
      success: true,
      invoice
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || 'Server error generating checkout invoice' },
      { status: 500 }
    );
  }
}
