import React from 'react';
import { Invoice } from '../../lib/invoice';
import { Mail, Phone, MapPin, Globe } from 'lucide-react';

interface InvoiceHeaderProps {
  invoice: Invoice;
}

export default function InvoiceHeader({ invoice }: InvoiceHeaderProps) {
  const formattedDate = new Date(invoice.createdAt).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div id="invoice-header-component" className="border-b border-stone-200 pb-8 space-y-6">
      {/* Brand & Invoice title block */}
      <div className="flex flex-col md:flex-row justify-between items-start gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-black tracking-widest bg-stone-900 text-white px-2.5 py-1">ZIVA</span>
            <span className="text-sm font-extrabold tracking-widest text-stone-900 border border-stone-950 px-2 py-0.5">STREET</span>
          </div>
          <p className="text-[10px] text-stone-500 font-bold uppercase tracking-widest flex items-center gap-1">
            <Globe className="h-3 w-3" />
            Luxury Indo-Streetwear Atelier
          </p>
        </div>

        <div className="text-left md:text-right space-y-1">
          <h1 id="invoice-main-title" className="text-2xl font-black uppercase tracking-tight text-stone-900 font-display">
            Tax Invoice
          </h1>
          <div className="font-mono text-xs space-y-0.5 text-stone-600">
            <p><span className="font-bold text-stone-500">INVOICE:</span> <span className="font-extrabold text-stone-900">{invoice.invoiceId}</span></p>
            <p><span className="font-bold text-stone-500">DATE:</span> <span className="font-bold text-stone-800">{formattedDate}</span></p>
            <p><span className="font-bold text-stone-500">ORDER ID:</span> <span className="font-extrabold text-stone-900">{invoice.orderId}</span></p>
          </div>
        </div>
      </div>

      {/* Address grids */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-stone-100 text-xs">
        {/* Atelier info */}
        <div id="invoice-atelier-details" className="space-y-3">
          <h3 className="text-[10px] font-black uppercase tracking-wider text-stone-400">Sold By (Atelier Hub)</h3>
          <div className="space-y-1 font-medium text-stone-800">
            <p className="font-black text-stone-950 uppercase">ZIVA STREET APPARELS PVT. LTD.</p>
            <p>Signature Block 4, Bandra Atelier Complex</p>
            <p>Bandra West, Mumbai, MH - 400050</p>
            <p className="text-3xs text-stone-500 font-mono">GSTIN: 27AACZ0412R1Z8</p>
          </div>
        </div>

        {/* Customer Address Details */}
        <div id="invoice-customer-details" className="space-y-3">
          <h3 className="text-[10px] font-black uppercase tracking-wider text-stone-400">Recipient (Consignee)</h3>
          <div className="space-y-2 text-stone-800 font-medium">
            <div>
              <p className="font-black text-stone-950 uppercase">{invoice.customerName}</p>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-1 text-stone-600">
                <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {invoice.email}</span>
                <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> +91 {invoice.phone}</span>
              </div>
            </div>

            <div className="border-t border-stone-100 pt-2 flex gap-1 items-start text-stone-600 leading-normal">
              <MapPin className="h-3.5 w-3.5 shrink-0 mt-0.5 text-stone-400" />
              <div>
                <p className="text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-0.5">Shipping & Billing Address</p>
                <p>{invoice.shippingAddress}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
