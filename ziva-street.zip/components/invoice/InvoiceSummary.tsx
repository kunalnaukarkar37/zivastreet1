import React from 'react';
import { Invoice } from '../../lib/invoice';
import { ShieldCheck } from 'lucide-react';

interface InvoiceSummaryProps {
  invoice: Invoice;
}

export default function InvoiceSummary({ invoice }: InvoiceSummaryProps) {
  return (
    <div id="invoice-bill-summary" className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
      {/* Policy/Disclaimer block */}
      <div className="bg-stone-50 border border-stone-200 p-4 space-y-2 text-[10px] text-stone-500 leading-relaxed">
        <p className="font-extrabold text-stone-800 uppercase tracking-wider flex items-center gap-1">
          <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
          Atelier Craft & Returns Policy
        </p>
        <p>
          Every garment is meticulously inspected, hand-measured, and customized with luxury weaves at our Mumbai workshop. Since these are couture capsules, we accept size exchanges within 14 days of receipt, provided standard tag seals are intact.
        </p>
        <p className="border-t border-stone-100 pt-2 font-mono">
          For digital trace audit or quick dispatch queries, please quote: <br />
          <strong className="text-stone-900 font-extrabold uppercase">COURIER TRACKING: {invoice.trackingId}</strong>
        </p>
      </div>

      {/* Bill calculation breakdowns */}
      <div className="space-y-2.5 text-xs text-stone-700 font-medium">
        <div className="flex justify-between">
          <span className="text-stone-500 font-medium">Cart Merchandise Subtotal:</span>
          <span className="font-mono text-stone-950">₹{invoice.subtotal.toLocaleString('en-IN')}</span>
        </div>

        {invoice.discount > 0 && (
          <div className="flex justify-between text-emerald-700">
            <span className="font-bold">
              Coupon Discount {invoice.couponCode ? `(${invoice.couponCode})` : ''} - 20%:
            </span>
            <span className="font-mono font-bold">- ₹{invoice.discount.toLocaleString('en-IN')}</span>
          </div>
        )}

        <div className="flex justify-between">
          <span className="text-stone-500">Delhivery Cargo Logistics:</span>
          <span className="font-mono text-stone-950">
            {invoice.deliveryCharge === 0 ? (
              <span className="font-bold text-emerald-600">FREE</span>
            ) : (
              `₹${invoice.deliveryCharge.toLocaleString('en-IN')}`
            )}
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-stone-500">Integrated SGST/CGST (5% standard):</span>
          <span className="font-mono text-stone-950">₹{invoice.tax.toLocaleString('en-IN')}</span>
        </div>

        <div className="border-t border-stone-900 pt-3 flex justify-between items-baseline font-black font-display text-base text-stone-950">
          <span className="uppercase tracking-wider">Grand Total Amount:</span>
          <span className="font-mono text-lg text-stone-950 border-b-2 border-double border-stone-950 pb-0.5">
            ₹{invoice.totalAmount.toLocaleString('en-IN')}
          </span>
        </div>
      </div>
    </div>
  );
}
