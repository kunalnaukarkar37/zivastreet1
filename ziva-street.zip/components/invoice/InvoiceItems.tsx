import React from 'react';
import { Invoice } from '../../lib/invoice';

interface InvoiceItemsProps {
  invoice: Invoice;
}

export default function InvoiceItems({ invoice }: InvoiceItemsProps) {
  return (
    <div id="invoice-items-table" className="space-y-3">
      <p className="text-[10px] font-black uppercase tracking-widest text-stone-400">Order Items Details</p>
      <div className="overflow-x-auto border border-stone-200">
        <table className="w-full text-xs text-left text-stone-800 divide-y divide-stone-200 font-medium">
          <thead className="bg-stone-50 text-[10px] font-extrabold uppercase tracking-widest text-stone-500">
            <tr>
              <th scope="col" className="px-4 py-3">Product Description / Style Code</th>
              <th scope="col" className="px-4 py-3 text-center">Size</th>
              <th scope="col" className="px-4 py-3 text-center animate-pulse">Qty</th>
              <th scope="col" className="px-4 py-3 text-right">Unit Price</th>
              <th scope="col" className="px-4 py-3 text-right">Total Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-150 bg-white">
            {invoice.items.map((item, idx) => {
              const itemTotal = item.price * item.quantity;
              return (
                <tr key={`${item.name}-${idx}`} className="hover:bg-stone-50/50">
                  <td className="px-4 py-4 text-stone-900 font-bold">
                    <div className="space-y-0.5">
                      <p className="uppercase">{item.name}</p>
                      <span className="text-[9px] font-semibold text-stone-400 font-mono tracking-widest uppercase block">
                        HSN CODE: 6205 | ART-STREET-{1000 + idx}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-4 text-center font-bold tracking-wider text-stone-700">
                    {item.size}
                  </td>
                  <td className="px-4 py-4 text-center font-mono font-bold text-stone-800">
                    {item.quantity}
                  </td>
                  <td className="px-4 py-4 text-right font-mono text-stone-900">
                    ₹{item.price.toLocaleString('en-IN')}
                  </td>
                  <td className="px-4 py-4 text-right font-mono font-extrabold text-stone-950">
                    ₹{itemTotal.toLocaleString('en-IN')}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
