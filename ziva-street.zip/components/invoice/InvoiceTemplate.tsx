import React, { useState } from 'react';
import { Invoice } from '../../lib/invoice';
import InvoiceHeader from './InvoiceHeader';
import InvoiceItems from './InvoiceItems';
import InvoiceSummary from './InvoiceSummary';
import InvoiceSignature from './InvoiceSignature';
import { Printer, Download, ArrowLeft, Loader2, Sparkles, AlertCircle } from 'lucide-react';

interface InvoiceTemplateProps {
  invoice: Invoice;
  onBackToShop?: () => void;
}

export default function InvoiceTemplate({ invoice, onBackToShop }: InvoiceTemplateProps) {
  const [downloading, setDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState('');

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    setDownloading(true);
    setDownloadError('');

    const runHtml2Pdf = () => {
      const element = document.getElementById('premium-invoice-document');
      if (!element) {
        setDownloadError('Unable to locate the print invoice template node.');
        setDownloading(false);
        return;
      }

      const opt = {
        margin: [8, 8, 8, 8],
        filename: `ZivaStreet_Invoice_${invoice.orderId}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
          scale: 2, 
          useCORS: true,
          letterRendering: true,
          logging: false 
        },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };

      // Execute pdf compile
      (window as any).html2pdf()
        .from(element)
        .set(opt)
        .save()
        .then(() => {
          setDownloading(false);
        })
        .catch((err: any) => {
          console.error("PDF generation failure:", err);
          setDownloadError('Browser security blocks dynamic renderer. Using print layout fallback.');
          setDownloading(false);
        });
    };

    // Lazy load html2pdf.js dynamically from stable CDN if not already bound on window
    if ((window as any).html2pdf) {
      runHtml2Pdf();
    } else {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js';
      script.integrity = 'sha512-GsDlC3wwUMm1f4vwPrtMxSTyKTMV8g1E8mSTf5Tdfw0E1XWe11D60X6B/L0U5e3N4uM9/O2P1pWpx7GAtp3VDA==';
      script.crossOrigin = 'anonymous';
      script.onload = () => {
        runHtml2Pdf();
      };
      script.onerror = () => {
        setDownloading(false);
        setDownloadError('Logistics network blocks CDN assets. Please tap "Print Invoice" to save as PDF.');
      };
      document.body.appendChild(script);
    }
  };

  return (
    <div id="invoice-template-view" className="w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6 animate-fade-in print:bg-white print:p-0">
      
      {/* Global CSS for Print-Friendly layout (Hiding non-printable panels) */}
      <style>{`
        @media print {
          body {
            background-color: #ffffff !important;
            color: #000000 !important;
          }
          .no-print {
            display: none !important;
          }
          #premium-invoice-document {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            max-width: 100% !important;
            width: 100% !important;
          }
          #invoice-signatures-block {
            page-break-inside: avoid;
          }
        }
      `}</style>

      {/* Navigation & Action bar (Hidden when printing) */}
      <div className="no-print flex flex-col sm:flex-row gap-4 items-center justify-between bg-stone-900 text-stone-50 p-4 border border-stone-800 shadow-sm">
        <div className="flex items-center gap-3">
          {onBackToShop && (
            <button
              onClick={onBackToShop}
              className="p-2 border border-stone-700 hover:bg-stone-800 text-stone-300 hover:text-white transition-colors cursor-pointer rounded-none flex items-center justify-center"
              title="Return to Shop Portal"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          )}
          <div>
            <p className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1 leading-none">
              <Sparkles className="h-3 w-3" />
              INVOICE EMITTED
            </p>
            <p className="text-[10px] text-stone-400 uppercase tracking-widest mt-1">
              Live secure receipt details for order: <strong>{invoice.orderId}</strong>
            </p>
          </div>
        </div>

        {/* Action button panel */}
        <div className="flex items-center gap-2">
          {/* Download button */}
          <button
            onClick={handleDownloadPDF}
            disabled={downloading}
            className="px-4 py-2.5 bg-white text-stone-900 border border-stone-200 text-[10px] font-extrabold uppercase tracking-widest hover:bg-stone-100 transition-all cursor-pointer inline-flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {downloading ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                <span>SAVING PDF...</span>
              </>
            ) : (
              <>
                <Download className="h-3.5 w-3.5" />
                <span>DOWNLOAD PDF</span>
              </>
            )}
          </button>

          {/* Print button */}
          <button
            onClick={handlePrint}
            className="px-4 py-2.5 bg-stone-800 text-white border border-stone-700 text-[10px] font-extrabold uppercase tracking-widest hover:bg-stone-700 transition-colors cursor-pointer inline-flex items-center gap-1.5"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>PRINT INVOICE</span>
          </button>
        </div>
      </div>

      {/* Downloader errors, shown in client only when error triggers */}
      {downloadError && (
        <div className="no-print p-3.5 bg-rose-50 border border-rose-250 text-rose-700 text-2xs font-semibold uppercase tracking-wider flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-rose-600 shrink-0" />
          <span>{downloadError}</span>
        </div>
      )}

      {/* The Actual TAX Invoice Document Template Frame */}
      <div 
        id="premium-invoice-document" 
        className="w-full bg-white border border-stone-250 p-8 sm:p-12 space-y-8 shadow-sm text-stone-900 font-sans"
      >
        {/* Modular sections */}
        <InvoiceHeader invoice={invoice} />
        
        <InvoiceItems invoice={invoice} />
        
        <InvoiceSummary invoice={invoice} />
        
        <InvoiceSignature date={invoice.createdAt} />
      </div>

      {/* Return to shop helper panel */}
      {onBackToShop && (
        <div className="no-print flex justify-center py-4">
          <button
            onClick={onBackToShop}
            className="text-stone-500 hover:text-black font-semibold text-2xs uppercase tracking-widest hover:underline cursor-pointer inline-flex items-center gap-2"
          >
            ← RETURN BACK TO SHOP PORTAL
          </button>
        </div>
      )}

    </div>
  );
}
