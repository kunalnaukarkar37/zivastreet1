import React from 'react';
import { Calendar } from 'lucide-react';

interface InvoiceSignatureProps {
  date: string;
}

export default function InvoiceSignature({ date }: InvoiceSignatureProps) {
  const yearStr = new Date(date).getFullYear();

  return (
    <div id="invoice-signatures-block" className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-stone-200">
      {/* Visual Slanted "PAID" stamp */}
      <div className="flex items-center justify-start md:justify-center relative">
        <div className="border-4 border-emerald-600 border-dashed text-emerald-600 px-6 py-2 text-center uppercase tracking-widest font-black text-xs font-mono select-none rounded-sm rotate-[-4deg] shadow-xs flex flex-col justify-center items-center gap-0.5 leading-none bg-emerald-50/50">
          <span className="text-xl font-bold font-display tracking-widest">PAID</span>
          <span className="text-[8px] tracking-[0.2em] font-semibold flex items-center gap-0.5">
            <Calendar className="h-2 w-2" />
            ZIVA ATELIER {yearStr}
          </span>
        </div>
      </div>

      {/* Signature & Authorization section */}
      <div className="flex flex-col items-start md:items-end justify-between min-h-32 text-xs space-y-4">
        <div className="text-left md:text-right space-y-1">
          <p className="text-[10px] font-black uppercase text-stone-400 tracking-widest">Certified Authenticity</p>
          <p className="font-extrabold text-stone-900 leading-tight">Ziva Street Couture Ltd.</p>
          <p className="text-3xs text-stone-500 max-w-xs font-medium">This is a system-generated secure digital tax invoice. Does not require physical signatures.</p>
        </div>

        <div className="w-56 text-center space-y-1 pt-6 border-t border-stone-300">
          <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest block font-mono">
            Atelier Digitally Signed
          </span>
          <p className="text-stone-950 font-black text-2xs uppercase tracking-wider font-sans select-all font-mono leading-none">
            Authorized by Ziva Street
          </p>
        </div>
      </div>
    </div>
  );
}
