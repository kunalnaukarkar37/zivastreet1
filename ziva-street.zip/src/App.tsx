/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShoppingBag, Heart, ShieldCheck, Mail, Phone, Instagram, Twitter, Facebook, Eye, ArrowRight, CheckCircle2, Ticket, Sparkles, X, Plus, Info } from 'lucide-react';
import { Product, CartItem, SavedAddress, Order, UserProfile } from './types';
import Navbar from './components/Navbar';
import HeroBanner from './components/HeroBanner';
import ProductCard from './components/ProductCard';
import CartOverlay from './components/CartOverlay';
import ProfileModal from './components/ProfileModal';
import DaduChatbot from './components/DaduChatbot';
import AdminPanel from './components/admin/AdminPanel';
import InvoiceTemplate from '../components/invoice/InvoiceTemplate';
import { getInvoiceByOrderId } from '../lib/invoice';

export default function App() {
  // Store collections catalogs
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCategory, setActiveCategory] = useState<'all' | 'men' | 'women'>('all');
  
  // Cart items
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState<boolean>(false);

  // User Profile Auth
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loginOpen, setLoginOpen] = useState<boolean>(false);
  const [loginPhone, setLoginPhone] = useState<string>('');
  const [loginOtp, setLoginOtp] = useState<string>('');
  const [loginEmail, setLoginEmail] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [loginName, setLoginName] = useState<string>('');
  
  // Auth view toggler: 'phone' | 'email'
  const [authMethod, setAuthMethod] = useState<'phone' | 'email'>('phone');
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpMessage, setOtpMessage] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');
  const [authLoading, setAuthLoading] = useState<boolean>(false);

  // User Profile overlay tabs
  const [profileOpen, setProfileOpen] = useState<boolean>(false);
  const [profileInitTab, setProfileInitTab] = useState<'orders' | 'track' | 'address' | 'account'>('account');

  // Customer Wishlist collection
  const [wishlist, setWishlist] = useState<string[]>([]);

  // Toast / Status notify bar
  const [toastMessage, setToastMessage] = useState<string>('');
  const [toastType, setToastType] = useState<'success' | 'info' | 'error'>('success');
  const [toastOpen, setToastOpen] = useState<boolean>(false);

  // Checkout Receipt success screen details
  const [activeReceipt, setActiveReceipt] = useState<{ orderId: string; trackingId: string; totalPaid: number } | null>(null);

  // Navigation Routing States
  const [currentView, setCurrentView] = useState<'shop' | 'invoice'>('shop');
  const [invoiceOrderId, setInvoiceOrderId] = useState<string | null>(null);

  // Helper trigger micro toast notifications
  const triggerToast = (msg: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setToastOpen(true);
    setTimeout(() => {
      setToastOpen(false);
    }, 4500);
  };

  // Fetch initial product dataset on load + recover user from session persistence
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await fetch('/api/products');
        const data = await res.json();
        if (res.ok) {
          setProducts(data);
        }
      } catch (err) {
        console.error("Unable to load product collections", err);
      }
    };

    fetchProducts();

    // Fetch user from local cache sync
    const cachedUser = localStorage.getItem('ziva_user');
    if (cachedUser) {
      try {
        setUser(JSON.parse(cachedUser));
      } catch (e) {
        localStorage.removeItem('ziva_user');
      }
    }

    // Recover favorites wishlist
    const cachedWish = localStorage.getItem('ziva_wishlist');
    if (cachedWish) {
      try {
        setWishlist(JSON.parse(cachedWish));
      } catch (e) {}
    }

    if (window.location.pathname.startsWith('/admin')) {
      setCurrentView('admin');
    }

    const handlePopState = () => {
      if (window.location.pathname.startsWith('/admin')) {
        setCurrentView('admin');
      } else {
        setCurrentView('shop');
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Sync cart variables on user changes / recovers
  useEffect(() => {
    if (user) {
      if (user.cart && user.cart.length > 0 && cartItems.length === 0) {
        setCartItems(user.cart);
      }
    }
  }, [user]);

  // Keep cart synced with server DB when modified
  const updateServerCart = async (newCart: CartItem[]) => {
    if (user) {
      try {
        await fetch('/api/cart/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: user.id,
            cart: newCart
          })
        });
      } catch (e) {
        console.error("Failed to commit cart to DB", e);
      }
    }
  };

  const handleUpdateQty = (productId: string, size: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveItem(productId, size);
      return;
    }
    const nextCart = cartItems.map((item) => {
      if (item.product.id === productId && item.selectedSize === size) {
        return { ...item, quantity: qty };
      }
      return item;
    });
    setCartItems(nextCart);
    updateServerCart(nextCart);
  };

  const handleRemoveItem = (productId: string, size: string) => {
    const nextCart = cartItems.filter(
      (item) => !(item.product.id === productId && item.selectedSize === size)
    );
    setCartItems(nextCart);
    updateServerCart(nextCart);
    triggerToast("Item removed from Shopping Bag", "info");
  };

  const handleAddToCart = (product: Product, size: string) => {
    const existingIndex = cartItems.findIndex(
      (item) => item.product.id === product.id && item.selectedSize === size
    );

    let nextCart: CartItem[] = [];
    if (existingIndex >= 0) {
      nextCart = cartItems.map((item, idx) => {
        if (idx === existingIndex) {
          return { ...item, quantity: item.quantity + 1 };
        }
        return item;
      });
    } else {
      nextCart = [...cartItems, { product, selectedSize: size, quantity: 1 }];
    }

    setCartItems(nextCart);
    updateServerCart(nextCart);
    triggerToast(`Added ${product.name} (Size: ${size}) to Shopping Bag`, "success");
  };

  const handleToggleWishlist = (productId: string) => {
    let nextWishlist: string[] = [];
    if (wishlist.includes(productId)) {
      nextWishlist = wishlist.filter((id) => id !== productId);
      triggerToast("Item removed from your Wishlist", "info");
    } else {
      nextWishlist = [...wishlist, productId];
      const p = products.find((itm) => itm.id === productId);
      triggerToast(`Added ${p?.name || 'Item'} to Wishlist`, "success");
    }
    setWishlist(nextWishlist);
    localStorage.setItem('ziva_wishlist', JSON.stringify(nextWishlist));
  };

  // Auth Operations
  const handleRequestOtp = async () => {
    if (!loginPhone) {
      setAuthError('Please input a valid telephone number.');
      return;
    }

    setAuthLoading(true);
    setAuthError('');

    try {
      const res = await fetch('/api/auth/otp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: loginPhone })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setOtpSent(true);
        setOtpMessage(`Simulated OTP sent directly! Please key-in "123456" below, beta.`);
        setLoginOtp('123456'); // pre-fill for supreme UX ease
        triggerToast("Simulated SMS Code Sent", "info");
      } else {
        setAuthError(data.error || 'Failed to trigger verification code.');
      }
    } catch (err) {
      setAuthError('Connection errors, check back-end server status.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);

    const payload = authMethod === 'phone'
      ? { phone: loginPhone, otpCode: loginOtp, fullName: loginName }
      : { email: loginEmail, password: loginPassword, fullName: loginName };

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setUser(data.user);
        localStorage.setItem('ziva_user', JSON.stringify(data.user));
        setLoginOpen(false);
        setOtpSent(false);
        setOtpMessage('');
        setLoginOtp('');
        setLoginPhone('');
        setLoginEmail('');
        setLoginName('');
        triggerToast(`Welcome back, ${data.user.fullName}!`, "success");
      } else {
        setAuthError(data.error || 'Verification credentials rejected.');
      }
    } catch (err) {
      setAuthError('Authentication pipeline is currently processing.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setCartItems([]);
    localStorage.removeItem('ziva_user');
    setProfileOpen(false);
    triggerToast("Signed out successfully. Dadu is waiting to assist you again!", "info");
  };

  const finalizeOrder = async (
    shippingAddress: SavedAddress,
    couponUsed: string,
    stats: { subtotal: number; discount: number; shipping: number; total: number },
    whatsappConsent: boolean,
    razorpayData?: {
      razorpay_signature: string;
      razorpay_payment_id: string;
      razorpay_order_id: string;
    }
  ) => {
    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: user?.id || null,
        cartItems,
        shippingAddress,
        couponCode: couponUsed,
        subtotal: stats.subtotal,
        discount: stats.discount,
        shipping: stats.shipping,
        total: stats.total,
        ...razorpayData
      })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      // Log locally if user logged in
      if (user) {
        const updatedUser = { ...user };
        updatedUser.orders.unshift(data.order);
        updatedUser.cart = [];
        setUser(updatedUser);
        localStorage.setItem('ziva_user', JSON.stringify(updatedUser));
      }

      // Trigger WhatsApp order confirmation broadcast when consented
      if (whatsappConsent) {
        try {
          const cleanPhone = shippingAddress.phone.replace(/\D/g, "");
          const formattedPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;

          await fetch("/api/whatsapp/send-confirmation", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              customerName: shippingAddress.fullName,
              phone: formattedPhone,
              orderId: data.orderId,
              trackingId: data.trackingId,
              totalAmount: stats.total,
              items: cartItems.map(item => ({
                name: item.product.name,
                size: item.selectedSize || "Standard",
                quantity: item.quantity,
                price: item.product.price
              }))
            })
          });
          console.log("WhatsApp order confirmation update dispatched.");
        } catch (whatsappErr) {
          console.error("Failed to route WhatsApp alert:", whatsappErr);
        }
      }

      // Trigger Receipt and Transition directly to Premium Invoice View
      setInvoiceOrderId(data.orderId);
      setCurrentView('invoice');

      // Clear client cart
      setCartItems([]);
      setCartOpen(false);
      triggerToast("Order placed successfully beta! Generating Tax Invoice... 🧾", "success");
    } else {
      triggerToast(data.error || "Failed to finalize checkout invoice.", "error");
    }
  };

  const handleCheckoutSubmit = async (
    shippingAddress: SavedAddress,
    couponUsed: string,
    stats: { subtotal: number; discount: number; shipping: number; total: number },
    whatsappConsent: boolean
  ) => {
    try {
      // 1. Fetch Razorpay integration settings from server
      const configRes = await fetch("/api/razorpay-config");
      const configData = await configRes.json();

      if (configData.enabled) {
        triggerToast("Connecting to secure Razorpay checkout gateway...", "info");
        
        // Dynamically load the Razorpay checkout script
        const isScriptLoaded = await new Promise<boolean>((resolve) => {
          if ((window as any).Razorpay) {
            resolve(true);
            return;
          }
          const script = document.createElement("script");
          script.src = "https://checkout.razorpay.com/v1/checkout.js";
          script.async = true;
          script.onload = () => resolve(true);
          script.onerror = () => resolve(false);
          document.body.appendChild(script);
        });

        if (!isScriptLoaded) {
          triggerToast("Failed to load secure payment script. Dynamic checkout disabled.", "error");
          return;
        }

        // Create Razorpay Order
        const orderRes = await fetch("/api/razorpay/create-order", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amount: stats.total, // amount in rupees
            currency: "INR",
            orderData: {
              userId: user?.id || null,
              cartItems,
              shippingAddress,
              couponCode: couponUsed,
              subtotal: stats.subtotal,
              discount: stats.discount,
              shipping: stats.shipping,
              total: stats.total
            }
          })
        });

        if (!orderRes.ok) {
          const errData = await orderRes.json();
          triggerToast(errData.error || "Failed to initialize Razorpay checkout session.", "error");
          return;
        }

        const rzOrder = await orderRes.json();

        // Configure and open Razorpay payment modal
        const options = {
          key: configData.keyId,
          amount: rzOrder.order.amount,
          currency: rzOrder.order.currency,
          name: "Ziva Street Atelier",
          description: `Bespoke Streetwear - Order ${rzOrder.order.id}`,
          order_id: rzOrder.order.id,
          handler: async function (response: any) {
            try {
              triggerToast("Payment received. Verifying transaction with Atelier server... 🧾", "info");
              const verifyRes = await fetch("/api/razorpay/verify-payment", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  razorpay_signature: response.razorpay_signature,
                  razorpay_payment_id: response.razorpay_payment_id,
                  razorpay_order_id: response.razorpay_order_id,
                  orderData: {
                    userId: user?.id || null,
                    cartItems,
                    shippingAddress,
                    couponCode: couponUsed,
                    subtotal: stats.subtotal,
                    discount: stats.discount,
                    shipping: stats.shipping,
                    total: stats.total
                  }
                })
              });

              const verifyData = await verifyRes.json();
              if (verifyRes.ok && verifyData.success) {
                // Log locally if user logged in
                if (user && verifyData.order) {
                  const updatedUser = { ...user };
                  updatedUser.orders.unshift(verifyData.order);
                  updatedUser.cart = [];
                  setUser(updatedUser);
                  localStorage.setItem('ziva_user', JSON.stringify(updatedUser));
                }

                // Trigger WhatsApp order confirmation broadcast when consented
                if (whatsappConsent) {
                  try {
                    const cleanPhone = shippingAddress.phone.replace(/\D/g, "");
                    const formattedPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;

                    await fetch("/api/whatsapp/send-confirmation", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        customerName: shippingAddress.fullName,
                        phone: formattedPhone,
                        orderId: verifyData.orderId,
                        trackingId: verifyData.trackingId || `ZS-TRK-${Math.floor(10000000 + Math.random() * 90000000)}`,
                        totalAmount: stats.total,
                        items: cartItems.map(item => ({
                          name: item.product.name,
                          size: item.selectedSize || "Standard",
                          quantity: item.quantity,
                          price: item.product.price
                        }))
                      })
                    });
                    console.log("WhatsApp order confirmation update dispatched.");
                  } catch (whatsappErr) {
                    console.error("Failed to route WhatsApp alert:", whatsappErr);
                  }
                }

                // Trigger Receipt and Transition directly to Premium Invoice View
                setInvoiceOrderId(verifyData.orderId);
                setCurrentView('invoice');

                // Clear client cart
                setCartItems([]);
                setCartOpen(false);
                triggerToast("Order placed successfully beta! Generating Tax Invoice... 🧾", "success");
              } else {
                triggerToast(verifyData.error || "Payment verification failed. Please contact support.", "error");
              }
            } catch (err: any) {
              triggerToast(err.message || "Failed to finalize order purchase.", "error");
            }
          },
          prefill: {
            name: shippingAddress.fullName,
            email: shippingAddress.email || user?.email || "customer@zivastreet.com",
            contact: shippingAddress.phone
          },
          theme: {
            color: "#1C1917" // stone-900 matching minimalist brand aesthetic
          },
          modal: {
            ondismiss: function() {
              triggerToast("Razorpay checkout payment modal dismissed by user.", "info");
            }
          }
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.open();
      } else {
        // Fall back to standard simulator payment
        await finalizeOrder(shippingAddress, couponUsed, stats, whatsappConsent);
      }
    } catch (err) {
      triggerToast("Failed to connect to checkout payment nodes.", "error");
    }
  };

  const handleScrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Filter Catalog relative to active filters
  const filteredProducts = products.filter((p) => {
    if (activeCategory === 'all') return true;
    return p.category === activeCategory;
  });

  if (currentView === 'admin') {
    return (
      <AdminPanel 
        onBackToStore={() => {
          window.history.pushState({}, '', '/');
          setCurrentView('shop');
        }} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col justify-between selection:bg-stone-900 selection:text-stone-100">
      
      {/* Top Banner Tip notice */}
      <div className="bg-stone-950 text-white py-2 px-4 shadow-sm text-center text-[10px] sm:text-2xs uppercase tracking-widest font-semibold flex items-center justify-center gap-1.5 shrink-0 z-50">
        <Sparkles className="h-3 w-3 text-amber-400 shrink-0" />
        Unlock 20% OFF sitewide with coupon: <strong className="text-amber-400 font-extrabold tracking-widest px-1">DADU</strong> • Free Delivery above ₹699
      </div>

      {/* Navbar Module */}
      <Navbar
        user={user}
        cartCount={cartItems.reduce((acc, i) => acc + i.quantity, 0)}
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
        onCartToggle={() => setCartOpen(!cartOpen)}
        onProfileToggle={(tab) => {
          setProfileInitTab((tab as any) || 'account');
          setProfileOpen(true);
        }}
        onLogout={handleLogout}
        onLoginClick={() => setLoginOpen(true)}
      />

      {/* Main Container contents */}
      <main className="flex-grow">
        
        {currentView === 'invoice' && invoiceOrderId ? (
          <InvoiceTemplate 
            invoice={getInvoiceByOrderId(invoiceOrderId)} 
            onBackToShop={() => {
              setCurrentView('shop');
              setInvoiceOrderId(null);
            }} 
          />
        ) : (
          <>
            {/* Dynamic Hero Banner */}
            {activeCategory === 'all' && (
              <HeroBanner onExploreClick={() => handleScrollToSection('shop-scroller')} />
            )}

            {/* Category specific dynamic headers */}
            {activeCategory !== 'all' && (
              <div className="bg-stone-900 text-white py-12 px-4 text-center border-b border-stone-800">
                <h1 className="text-3xl sm:text-4xl font-extrabold uppercase tracking-widest font-display text-white">
                  {activeCategory === 'men' ? "MEN'S APPARELS" : "WOMEN'S APPARELS"}
                </h1>
                <p className="text-stone-300 text-xs tracking-wider uppercase mt-1.5 max-w-md mx-auto">
                  Luxury streetwear fusion styled with traditional weavings, drop shoulders, and asymmetric pockets.
                </p>
              </div>
            )}

            {/* Categories Promotion Banner Blocks */}
            {activeCategory === 'all' && (
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
                <div id="promotional-grids" className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-4">
                  
                  {/* Men apparel teaser banner */}
                  <div 
                    onClick={() => setActiveCategory('men')}
                    className="group relative h-96 border border-stone-200 bg-stone-900 overflow-hidden shadow-sm cursor-pointer rounded-none"
                  >
                    <div className="absolute inset-0 opacity-60">
                      <img 
                        src="https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?auto=format&fit=crop&q=80&w=800" 
                        alt="Men Collection teaser" 
                        className="w-full h-full object-cover group-hover:scale-104 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent" />
                    </div>
                    <div className="absolute inset-0 flex flex-col justify-end p-6 space-y-2">
                      <span className="text-[10px] tracking-widest font-bold text-amber-400 uppercase">AURA EXPLORE</span>
                      <h3 className="text-xl sm:text-2xl font-extrabold uppercase tracking-wider text-white font-display">MEN'S STREETWEAR</h3>
                      <p className="text-stone-300 text-xs leading-relaxed max-w-sm">Draped asymmetrical linen kurtas, organic slately side cowls, and canvas cargo bandhgalas beta.</p>
                      <span className="text-xs text-white uppercase font-bold tracking-widest inline-flex items-center gap-1.5 group-hover:translate-x-1.5 transition-transform pt-1">
                        Explore Cuts <ArrowRight className="h-4 w-4" />
                      </span>
                    </div>
                  </div>

                  {/* Women apparel teaser banner */}
                  <div 
                    onClick={() => setActiveCategory('women')}
                    className="group relative h-96 border border-stone-200 bg-stone-900 overflow-hidden shadow-sm cursor-pointer rounded-none"
                  >
                    <div className="absolute inset-0 opacity-60">
                      <img 
                        src="https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=800" 
                        alt="Women Collection teaser" 
                        className="w-full h-full object-cover group-hover:scale-104 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent" />
                    </div>
                    <div className="absolute inset-0 flex flex-col justify-end p-6 space-y-2">
                      <span className="text-[10px] tracking-widest font-bold text-amber-400 uppercase">COUTURE EXPLORE</span>
                      <h3 className="text-xl sm:text-2xl font-extrabold uppercase tracking-wider text-white font-display">WOMEN'S STREETWEAR</h3>
                      <p className="text-stone-300 text-xs leading-relaxed max-w-sm">Organza layered flower blocks, Zardozi modern silk bombers, and drawstring-fitted traditional tunics.</p>
                      <span className="text-xs text-white uppercase font-bold tracking-widest inline-flex items-center gap-1.5 group-hover:translate-x-1.5 transition-transform pt-1">
                        Explore Couture <ArrowRight className="h-4 w-4" />
                      </span>
                    </div>
                  </div>

                </div>
              </section>
            )}

            {/* ACTIVE COUTURE SECTION / PRODUCT GRID */}
            <section id="shop-scroller" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
              <div className="flex flex-col md:flex-row md:items-baseline justify-between border-b pb-5 gap-4">
                <div>
                  <h2 className="text-2xl font-extrabold uppercase tracking-wide text-stone-950 font-display">
                    {activeCategory === 'all' && "THE ENTIRE CAPSULE COLLECTION"}
                    {activeCategory === 'men' && "INDO-STREET MENSWEAR"}
                    {activeCategory === 'women' && "INDO-STREET WOMENSWEAR"}
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">Viewing all handcrafted styles in INR currency. Pick a piece, select sizes and add to bag.</p>
                </div>

                {/* Quick in-page category pills filter */}
                <div className="flex gap-2.5">
                  {(['all', 'men', 'women'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-4 py-2 font-bold text-[10px] tracking-widest uppercase rounded-none border cursor-pointer transition-colors ${
                        activeCategory === cat
                          ? 'bg-stone-950 text-white border-stone-950 font-extrabold'
                          : 'bg-white text-stone-600 border-stone-200 hover:bg-stone-100/50 hover:text-black'
                      }`}
                    >
                      {cat === 'all' ? 'All Pieces' : `${cat}'s Couture`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Product Cards Layout Grid */}
              {filteredProducts.length === 0 ? (
                <div className="py-24 text-center">
                  <span className="p-3.5 bg-stone-100 rounded-full inline-block text-stone-400 mb-2">🔍</span>
                  <p className="text-xs text-stone-500 uppercase font-bold tracking-widest">No garments matching active filters found, beta.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 font-medium">
                  {filteredProducts.map((p) => (
                    <ProductCard
                      key={p.id}
                      product={p}
                      onAddToCart={handleAddToCart}
                      isWishlisted={wishlist.includes(p.id)}
                      onToggleWishlist={handleToggleWishlist}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Dynamic prompt coupon advertising block */}
            <section className="bg-stone-950 text-white py-12 px-6 text-center shrink-0">
              <div className="max-w-2xl mx-auto space-y-4">
                <h3 className="text-lg font-bold uppercase tracking-wider text-amber-400 font-display inline-flex items-center gap-1">
                  <Ticket className="h-4.5 w-4.5" />
                  Special Caretaker Coupon Inside
                </h3>
                <p className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight text-white leading-tight font-display">
                  Flat <span className="text-amber-100 underline decoration-amber-400 decoration-3">20% off</span> Your Entire Cart Drip
                </p>
                <p className="text-stone-300 text-xs sm:text-xs">
                  Every customer gets flat 20% off with coupon code <strong className="text-white font-mono bg-stone-850 px-2 py-1 select-all border border-stone-800">DADU</strong> before payment processing. No limits on minimum items. Free Delivery above ₹699!
                </p>
                <div>
                  <button
                    onClick={() => {
                      setCartOpen(true);
                    }}
                    className="px-6 py-2.5 bg-white text-stone-950 text-[10px] font-bold uppercase tracking-widest hover:bg-stone-150 cursor-pointer active:scale-95 transition-transform"
                  >
                    Buy Now With Coupon Code
                  </button>
                </div>
              </div>
            </section>
          </>
        )}

      </main>

      {/* FOOTER DIRECTORY CHANNELS */}
      <footer className="bg-white border-t border-stone-200 py-16 px-4 md:px-8 shrink-0">
        <div id="footer-container" className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 text-xs">
          
          {/* About Column */}
          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-widest text-stone-950 font-display">ZIVA STREET®</h3>
            <p className="text-stone-500 leading-relaxed max-w-sm font-normal">
              A fashion couture experiment crafting contemporary streetwear garments utilizing rich handloomed Indian textiles, organic drapes, heavy canvas jackets, and traditional blocks. Based out of Mumbai, India.
            </p>
            <div className="flex space-x-3.5">
              <a href="#" className="p-2 border border-stone-200 hover:border-black rounded-none text-stone-600 hover:text-black transition-colors" title="Instagram Link">
                <Instagram className="h-4.5 w-4.5" />
              </a>
              <a href="#" className="p-2 border border-stone-200 hover:border-black rounded-none text-stone-600 hover:text-black transition-colors" title="Twitter Link">
                <Twitter className="h-4.5 w-4.5" />
              </a>
              <a href="#" className="p-2 border border-stone-200 hover:border-black rounded-none text-stone-600 hover:text-black transition-colors" title="Facebook Link">
                <Facebook className="h-4.5 w-4.5" />
              </a>
            </div>
          </div>

          {/* Help & Support Column */}
          <div className="space-y-4 text-left">
            <h4 className="text-xs font-bold uppercase tracking-widest text-stone-900">Help & Support</h4>
            <ul className="space-y-2.5 text-stone-500">
              <li><button onClick={() => { setProfileInitTab('track'); setProfileOpen(true); }} className="hover:text-black tracking-wide cursor-pointer transition-colors">How to Track Order</button></li>
              <li><button onClick={() => { setLoginOpen(true); }} className="hover:text-black tracking-wide cursor-pointer transition-colors font-semibold text-stone-700">Account Authorization</button></li>
              <li><button onClick={() => { window.history.pushState({}, '', '/admin'); setCurrentView('admin'); }} id="footer-admin-access-btn" className="hover:text-amber-600 tracking-wide cursor-pointer transition-colors font-semibold text-amber-550 mr-2">Systems Portal Access</button></li>
              <li><a href="#" className="hover:text-black tracking-wide transition-colors">Returns & Refunds policies</a></li>
              <li><a href="#" className="hover:text-black tracking-wide transition-colors">Exchanges & Sizing charts</a></li>
            </ul>
          </div>

          {/* Contact Details Column */}
          <div className="space-y-4 text-left">
            <h4 className="text-xs font-bold uppercase tracking-widest text-stone-900">Contact coordinates</h4>
            <p className="text-stone-500 leading-relaxed font-normal">
              Do not hesitate to reach our Bandra Atelier desk. Our team and Dadu are available round the clock, beta.
            </p>
            <div className="space-y-2 text-stone-700">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-stone-400 shrink-0" />
                <a href="mailto:atelier@zivastreet.in" className="hover:underline font-semibold text-stone-900">atelier@zivastreet.in</a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-stone-400 shrink-0" />
                <a href="tel:+912284562200" className="hover:underline font-semibold text-stone-900">+91 22 8456 2200</a>
              </div>
            </div>
          </div>

          {/* Security details column */}
          <div className="space-y-4 text-left">
            <h4 className="text-xs font-bold uppercase tracking-widest text-stone-900">Trusted checkout</h4>
            <div className="bg-stone-50 p-4 border border-stone-150 space-y-2.5 rounded-none">
              <div className="flex items-center gap-1.5 text-stone-850 font-bold uppercase text-[10px] tracking-wider">
                <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
                SAFE DEMO CONCIERGE
              </div>
              <p className="text-stone-500 text-3xs leading-relaxed font-normal">
                Complies with trial e-commerce parameters. SMS alert plugins and standard transaction payment gateways can be incorporated later since data structures are organized.
              </p>
            </div>
          </div>

        </div>

        {/* Bottom copyright trim */}
        <div className="max-w-7xl mx-auto border-t border-stone-200 mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between text-[10px] sm:text-2xs text-stone-400 gap-4">
          <p>© 2026 ZIVA STREET clothing brand. Crafted with extreme luxury streetwear care.</p>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-black transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-black transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-black transition-colors">Cookie settings</a>
          </div>
        </div>
      </footer>


      {/* AUTHENTICATION REGISTER LOGIN MODAL (SIMULATED PHONE OTP SYSTEM) */}
      {loginOpen && (
        <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* backdrop */}
          <div onClick={() => setLoginOpen(false)} className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs cursor-pointer animate-fade-in" />
          
          <div className="relative w-full max-w-sm bg-white rounded-none shadow-2xl border border-stone-200 overflow-hidden z-10">
            <button
              onClick={() => setLoginOpen(false)}
              className="absolute top-4 right-4 text-stone-400 hover:text-black p-1 rounded-none cursor-pointer transition-colors"
            >
              <X className="h-5 w-5" />
            </button>

            <form onSubmit={handleAuthSubmit} className="p-6 sm:p-8 space-y-5 text-left">
              <div className="text-center space-y-1">
                <span className="text-[9px] font-bold tracking-widest text-amber-600 uppercase">MEMBER INLET</span>
                <h3 className="text-lg font-extrabold uppercase tracking-wider text-stone-900 font-display">Ziva Member</h3>
                <p className="text-stone-500 text-2xs">Sign in instantly to retrieve your saved profile, orders, addresses & active buggy cart beta!</p>
              </div>

              {/* Selector toggles between phone/email signup */}
              <div className="flex border rounded-none overflow-hidden">
                <button
                  type="button"
                  onClick={() => { setAuthMethod('phone'); setAuthError(''); setOtpSent(false); }}
                  className={`flex-1 py-1.5 text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                    authMethod === 'phone' ? 'bg-stone-900 text-white' : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  Phone + OTP
                </button>
                <button
                  type="button"
                  onClick={() => { setAuthMethod('email'); setAuthError(''); }}
                  className={`flex-1 py-1.5 text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                    authMethod === 'email' ? 'bg-stone-900 text-white' : 'bg-stone-50 text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  Email + Password
                </button>
              </div>

              <div className="space-y-3.5 pt-1">
                
                {/* Full name (optional for return login, auto filled otherwise) */}
                <div>
                  <label className="text-[9px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Your Full Name (First-Time User Registration)</label>
                  <input
                    type="text"
                    value={loginName}
                    onChange={(e) => setLoginName(e.target.value)}
                    placeholder="e.g. Kunal Naukarkar"
                    className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-950 bg-stone-50"
                  />
                </div>

                {authMethod === 'phone' ? (
                  <>
                    <div>
                      <label className="text-[9px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Mobile Telephone No.</label>
                      <div className="flex shadow-2xs rounded-none">
                        <span className="px-3 bg-stone-100 border border-r-0 border-stone-250 text-stone-500 flex items-center text-xs font-semibold">+91</span>
                        <input
                          type="tel"
                          required
                          value={loginPhone}
                          onChange={(e) => setLoginPhone(e.target.value)}
                          placeholder="9988776655"
                          className="flex-grow text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-950 bg-stone-50 font-semibold rounded-none"
                        />
                      </div>
                    </div>

                    {!otpSent ? (
                      <button
                        type="button"
                        onClick={handleRequestOtp}
                        disabled={authLoading}
                        className="w-full py-3 bg-stone-900 text-white hover:bg-stone-950 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer inline-flex items-center justify-center"
                      >
                        {authLoading ? 'Verifying...' : 'Request OTP Verification Code'}
                      </button>
                    ) : (
                      <>
                        <div>
                          <label className="text-[9px] uppercase font-bold tracking-widest text-stone-500 block mb-1">OTP Verification Code</label>
                          <input
                            type="text"
                            required
                            value={loginOtp}
                            onChange={(e) => setLoginOtp(e.target.value)}
                            placeholder="Type 123456"
                            className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-950 bg-stone-50 font-mono tracking-widest text-center"
                          />
                        </div>
                        {otpMessage && (
                          <p className="text-[10px] text-emerald-700 bg-emerald-50 border p-2 text-center rounded-none">{otpMessage}</p>
                        )}
                        <button
                          type="submit"
                          disabled={authLoading}
                          className="w-full py-3 bg-stone-900 text-white hover:bg-stone-950 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer"
                        >
                          {authLoading ? 'Authenticating...' : 'Sign In / Secure Register'}
                        </button>
                      </>
                    )}
                  </>
                ) : (
                  <>
                    <div>
                      <label className="text-[9px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Email Address</label>
                      <input
                        type="email"
                        required
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        placeholder="atelier@zivastreet.in"
                        className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-950 bg-stone-50 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Password</label>
                      <input
                        type="password"
                        required
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-950 bg-stone-50"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={authLoading}
                      className="w-full py-3 bg-stone-900 text-white hover:bg-stone-950 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer"
                    >
                      {authLoading ? 'Signing in...' : 'Sign In / Secure Register'}
                    </button>
                  </>
                )}

                {authError && (
                  <p className="text-rose-500 font-extrabold text-[10px] tracking-wide text-center">{authError}</p>
                )}

                {/* Helpful Tip disclaimer footer */}
                <div className="bg-stone-50 p-2 text-3xs text-stone-500 border border-stone-200 rounded-none leading-relaxed text-center">
                  💡 <b>Demo Mode:</b> Feel free to use mock phone coordinates (e.g. 9988776655). Triggering SMS simulator code generates immediate access key (OTP: <b>123456</b>), allowing immediate persistent db bindings for addresses & previous orders.
                </div>
              </div>
            </form>
          </div>
        </div>
      )}


      {/* ORDER PLACEMENT INVOICE RECEIPT SCREEN (MODAL ON SUCCESSFUL CHECKOUT) */}
      {activeReceipt && (
        <div id="receipt-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setActiveReceipt(null)} className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs cursor-pointer animate-fade-in" />
          
          <div className="relative w-full max-w-sm bg-white rounded-none shadow-2xl border border-stone-200 overflow-hidden z-10 p-6 sm:p-8 text-center space-y-5 flex flex-col justify-between">
            <div className="h-14 w-14 bg-emerald-100 rounded-none flex items-center justify-center text-emerald-600 mx-auto border border-emerald-200/40 shrink-0">
              <CheckCircle2 className="h-8 w-8" />
            </div>

            <div className="space-y-1">
              <span className="text-[9px] font-bold tracking-widest text-emerald-600 uppercase">PAYMENT RECEIVED</span>
              <h3 className="text-xl font-extrabold uppercase tracking-wide text-stone-900 font-display">Order Confirmed!</h3>
              <p className="text-xs text-stone-500 leading-relaxed">Thank you for your purchase beta! Your Street Couture package has been registered with our atelier and Delhivery air dispatch registry.</p>
            </div>

            <div className="bg-stone-50 border border-stone-200 p-4 space-y-2 rounded-none text-left text-xs font-semibold">
              <div className="flex justify-between border-b pb-1.5 last:border-0 last:pb-0 font-mono text-3xs text-stone-500">
                <span>ORDER NUMBER:</span>
                <span className="font-extrabold text-stone-900">{activeReceipt.orderId}</span>
              </div>
              <div className="flex justify-between border-b pb-1.5 last:border-0 last:pb-0 font-mono text-3xs text-stone-500">
                <span>COURIER TRACKING:</span>
                <span className="font-extrabold text-stone-900">{activeReceipt.trackingId}</span>
              </div>
              <div className="flex justify-between border-b pb-1.5 last:border-0 last:pb-0 text-stone-500">
                <span>FINAL TOTAL PAID:</span>
                <span className="font-extrabold text-stone-950 font-display font-display-sans">₹{activeReceipt.totalPaid.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="bg-amber-50 p-2 text-3xs text-amber-800 border border-[#0f0e0e] rounded-none leading-relaxed text-left">
              💡 <b>Delhivery Logistics Live tracking:</b> Paste tracking ID <strong className="select-all font-mono text-stone-900">{activeReceipt.trackingId}</strong> in our <b>Track Order</b> tab on your profile dashboard to inspect active stages (order placed, packed, shipped, out for delivery, delivered).
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setProfileInitTab('track');
                  setProfileOpen(true);
                  setActiveReceipt(null);
                }}
                className="flex-1 py-3 bg-stone-900 hover:bg-stone-950 text-white font-bold text-2xs uppercase tracking-widest transition-colors cursor-pointer text-center"
              >
                Track Live Status
              </button>
              <button
                onClick={() => setActiveReceipt(null)}
                className="flex-1 py-3 border border-stone-200 hover:bg-stone-50 text-stone-700 font-bold text-2xs uppercase tracking-widest transition-colors cursor-pointer text-center"
              >
                Keep Shopping
              </button>
            </div>
          </div>
        </div>
      )}


      {/* CHATBOT ASSISTANT DADU */}
      <DaduChatbot 
        user={user} 
        cartItems={cartItems}
        onOpenProfile={(tab) => {
          setProfileInitTab((tab as any) || 'account');
          setProfileOpen(true);
        }}
        onOpenCart={() => setCartOpen(true)}
      />

      {/* SHOPPING CART DRAWER OVERLAY */}
      <CartOverlay
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        userAddress={user && user.addressBook.length > 0 ? user.addressBook[0] : null}
        onCheckout={handleCheckoutSubmit}
      />

      {/* USER PROFILE DASHBOARD MODAL */}
      {user && profileOpen && (
        <ProfileModal
          isOpen={profileOpen}
          onClose={() => setProfileOpen(false)}
          user={user}
          onUpdateProfile={(updated) => {
            setUser(updated);
            localStorage.setItem('ziva_user', JSON.stringify(updated));
          }}
          initialTab={profileInitTab}
          onLogout={handleLogout}
          onViewInvoice={(id) => {
            setInvoiceOrderId(id);
            setCurrentView('invoice');
          }}
        />
      )}


      {/* MICRO MICRO TOAST NOTIFICATIONS SLIDE IN BAR */}
      <div 
        className={`fixed bottom-4 left-4 z-50 bg-stone-950 text-stone-50 px-4 py-3.5 shadow-2x border border-stone-800 text-xs rounded-none transition-all duration-300 transform flex items-center gap-2 max-w-sm ${
          toastOpen ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-12 opacity-0 scale-95 pointer-events-none'
        }`}
      >
        <span className="h-1.5 w-1.5 bg-amber-400 rounded-full animate-ping" />
        <p className="font-semibold">{toastMessage}</p>
        <button onClick={() => setToastOpen(false)} className="ml-auto text-stone-400 hover:text-white p-1 cursor-pointer">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

    </div>
  );
}
