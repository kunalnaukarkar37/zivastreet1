/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'men' | 'women';
  image: string;
  sizes: string[];
  tag?: string;
  originalPrice?: number;
  active?: boolean;
  stock?: number;
}

export interface CartItem {
  product: Product;
  selectedSize: string;
  quantity: number;
}

export interface SavedAddress {
  fullName: string;
  phone: string;
  email?: string;
  streetAddress: string;
  city: string;
  state: string;
  pinCode: string;
}

export interface Order {
  id: string;
  trackingId: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  address: SavedAddress;
  status: 'ordered' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled';
  couponCode?: string;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
}

export interface UserProfile {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  addressBook: SavedAddress[];
  orders: Order[];
  cart: CartItem[];
}

export interface AdminUser {
  id: string;
  username: string;
  role: 'admin' | 'staff';
  token?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent: number;
  minCartValue: number;
  usageLimit?: number;
  usageCount: number;
  active: boolean;
}

export interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  ctaText: string;
  active: boolean;
}

export interface SupportMessage {
  id: string;
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
  date: string;
  status: 'new' | 'read' | 'replied';
  reply?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'dadu';
  text: string;
  timestamp: string;
}
