import React, { useState, useEffect } from 'react';
import { MapPin, Truck, AlertCircle, CheckCircle2, ChevronRight, Activity } from 'lucide-react';

interface CheckoutShippingProps {
  fullName: string;
  setFullName: (val: string) => void;
  phone: string;
  setPhone: (val: string) => void;
  email: string;
  setEmail: (val: string) => void;
  streetAddress: string;
  setStreetAddress: (val: string) => void;
  city: string;
  setCity: (val: string) => void;
  state: string;
  setState: (val: string) => void;
  pinCode: string;
  setPinCode: (val: string) => void;
  shippingOption: 'surface' | 'express';
  setShippingOption: (val: 'surface' | 'express') => void;
  subtotal: number;
}

// A dictionary of known serviceable Indian pin codes for realistic lookup
const pincodeDatabase: Record<string, { city: string; state: string }> = {
  "400050": { city: "Mumbai", state: "Maharashtra" },
  "400001": { city: "Mumbai", state: "Maharashtra" },
  "110001": { city: "New Delhi", state: "Delhi" },
  "110011": { city: "New Delhi", state: "Delhi" },
  "560001": { city: "Bengaluru", state: "Karnataka" },
  "560038": { city: "Bengaluru", state: "Karnataka" },
  "600001": { city: "Chennai", state: "Tamil Nadu" },
  "700001": { city: "Kolkata", state: "West Bengal" },
  "500001": { city: "Hyderabad", state: "Telangana" },
  "380001": { city: "Ahmedabad", state: "Gujarat" },
  "411001": { city: "Pune", state: "Maharashtra" },
  "302001": { city: "Jaipur", state: "Rajasthan" },
  "110096": { city: "Mayur Vihar", state: "Delhi" },
  "400092": { city: "Borivali", state: "Maharashtra" },
};

export default function CheckoutShipping({
  fullName, setFullName,
  phone, setPhone,
  email, setEmail,
  streetAddress, setStreetAddress,
  city, setCity,
  state, setState,
  pinCode, setPinCode,
  shippingOption, setShippingOption,
  subtotal
}: CheckoutShippingProps) {
  const [checkingPin, setCheckingPin] = useState(false);
  const [pinStatus, setPinStatus] = useState<'idle' | 'valid' | 'invalid'>('idle');
  const [statusMsg, setStatusMsg] = useState('');

  // Handle auto-searching pin codes when length reaches 6 digits
  useEffect(() => {
    const cleanPin = pinCode.trim();
    if (cleanPin.length === 6 && /^\d+$/.test(cleanPin)) {
      handlePincodeLookup(cleanPin);
    } else if (cleanPin.length > 0 && cleanPin.length < 6) {
      setPinStatus('idle');
      setStatusMsg('');
    }
  }, [pinCode]);

  const handlePincodeLookup = (pin: string) => {
    setCheckingPin(true);
    setPinStatus('idle');
    setStatusMsg('');

    setTimeout(() => {
      const match = pincodeDatabase[pin];
      if (match) {
        setCity(match.city);
        setState(match.state);
        setPinStatus('valid');
        setStatusMsg('Serviceable! Delhivery Direct Express Active.');
      } else {
        // Fallback for demo: accept pins but warn that they use standard routes
        const numeric = /^\d+$/.test(pin);
        if (numeric) {
          setPinStatus('valid');
          setStatusMsg('Serviceable via partner routes.');
          // Guessing city/state if empty
          if (!city) setCity("Standard Zone");
          if (!state) setState("India");
        } else {
          setPinStatus('invalid');
          setStatusMsg('Invalid Indian Pin Code format.');
        }
      }
      setCheckingPin(false);
    }, 600);
  };

  const isFreeThresholdIncurred = subtotal > 699;
  const standardShippingPrice = isFreeThresholdIncurred ? 0 : 99;
  const expressShippingPrice = 149; // Flat upgrade for Delhivery Air

  return (
    <div id="delhivery-checkout-shipping" className="space-y-4 text-left animate-fade-in">
      {/* Sub Heading */}
      <div className="border-b border-stone-100 pb-2 flex items-center justify-between">
        <h4 className="text-[10px] font-black uppercase tracking-widest text-[#1A1A1A]">
          Shipping Details
        </h4>
        <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest flex items-center gap-1">
          <Activity className="h-3 w-3 text-[#1A1A1A] animate-pulse" />
          Logistics Link
        </span>
      </div>

      <div className="space-y-3.5">
        {/* Name Input */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">
            Recipient's Full Name
          </label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-medium rounded-none"
            placeholder="e.g. Kunal Naukarkar"
            required
          />
        </div>

        {/* Mobile Contact */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">
            Mobile Contact Telephone No.
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-medium rounded-none"
            placeholder="e.g. 9876543210 (10 digits)"
            maxLength={10}
            required
          />
        </div>

        {/* Email Address for Delivery */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">
            Email Address (for Invoice & Receipt Delivery)
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-medium rounded-none"
            placeholder="e.g. kunalnaukarkar37@gmail.com"
            required
          />
        </div>

        {/* Pin Code checker */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">
            Indian Pincode / ZIP Code
          </label>
          <div className="relative">
            <input
              type="text"
              value={pinCode}
              onChange={(e) => setPinCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              className="w-full text-xs p-2.5 pr-10 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-mono font-bold tracking-wider rounded-none"
              placeholder="e.g. 400050 or 110001"
              maxLength={6}
              required
            />
            <div className="absolute right-3 top-3 flex items-center justify-center">
              {checkingPin ? (
                <div className="h-4 w-4 border-2 border-stone-300 border-t-stone-900 rounded-full animate-spin" />
              ) : pinStatus === 'valid' ? (
                <CheckCircle2 className="h-4.5 w-4.5 text-emerald-600" />
              ) : pinStatus === 'invalid' ? (
                <AlertCircle className="h-4.5 w-4.5 text-rose-500" />
              ) : (
                <MapPin className="h-4 w-4 text-stone-400" />
              )}
            </div>
          </div>

          {/* Pin validation hint feedback */}
          {statusMsg && (
            <p className={`text-[9px] font-bold uppercase tracking-wider mt-1.5 flex items-center gap-1 ${
              pinStatus === 'valid' ? 'text-emerald-700' : 'text-rose-600'
            }`}>
              {pinStatus === 'valid' ? '✓' : '⚠'} {statusMsg}
            </p>
          )}
        </div>

        {/* Address street */}
        <div>
          <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">
            Street Address / House No. / Landmark
          </label>
          <input
            type="text"
            value={streetAddress}
            onChange={(e) => setStreetAddress(e.target.value)}
            className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-medium rounded-none"
            placeholder="Apartment 303, Ziva Street Atelier, Bandra Flat"
            required
          />
        </div>

        {/* City and State */}
        <div className="grid grid-cols-2 gap-3.5">
          <div>
            <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">City</label>
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-semibold rounded-none"
              placeholder="Mumbai"
              required
            />
          </div>
          <div>
            <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-1">State</label>
            <input
              type="text"
              value={state}
              onChange={(e) => setState(e.target.value)}
              className="w-full text-xs p-2.5 border border-stone-250 focus:outline-none focus:ring-1 focus:ring-stone-900 bg-stone-50 text-stone-900 font-semibold rounded-none"
              placeholder="Maharashtra"
              required
            />
          </div>
        </div>

        {/* Delivery Options list container */}
        <div className="pt-2">
          <label className="text-[10px] uppercase font-bold tracking-widest text-stone-600 block mb-2">
            Select Delhivery Shipping Tier
          </label>
          <div className="space-y-2">
            
            {/* Options 1: surface saver */}
            <label className={`block border p-3 cursor-pointer flex justify-between items-center transition-all rounded-none ${
              shippingOption === 'surface' 
                ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-950' 
                : 'border-stone-200 bg-white hover:bg-stone-50/50'
            }`}>
              <div className="flex items-start gap-2.5">
                <input
                  type="radio"
                  name="shippingTier"
                  checked={shippingOption === 'surface'}
                  onChange={() => setShippingOption('surface')}
                  className="mt-1 accent-stone-950"
                />
                <div>
                  <p className="text-xs font-bold text-stone-950 flex items-center gap-1">
                    Delhivery Surface Saver
                    {isFreeThresholdIncurred && (
                      <span className="text-[8px] bg-emerald-600 text-white font-extrabold px-1.5 py-0.5 ml-1">
                        FREE
                      </span>
                    )}
                  </p>
                  <p className="text-[9px] text-stone-500 font-medium">Standard Road Freight (3-5 Business Days)</p>
                </div>
              </div>
              <span className="font-mono text-2xs font-extrabold text-stone-950">
                {standardShippingPrice === 0 ? "FREE" : `₹${standardShippingPrice}`}
              </span>
            </label>

            {/* Options 2: air express */}
            <label className={`block border p-3 cursor-pointer flex justify-between items-center transition-all rounded-none ${
              shippingOption === 'express' 
                ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-950' 
                : 'border-stone-200 bg-white hover:bg-stone-50/50'
            }`}>
              <div className="flex items-start gap-2.5">
                <input
                  type="radio"
                  name="shippingTier"
                  checked={shippingOption === 'express'}
                  onChange={() => setShippingOption('express')}
                  className="mt-1 accent-stone-950"
                />
                <div>
                  <p className="text-xs font-bold text-stone-950 flex items-center gap-1">
                    Delhivery Premium Air Express
                    <span className="text-[8px] bg-indigo-600 text-white font-extrabold px-1.5 py-0.5 ml-1">
                      FAST
                    </span>
                  </p>
                  <p className="text-[9px] text-stone-500 font-medium">Guaranteed Priority Air Transit (1-2 Business days)</p>
                </div>
              </div>
              <span className="font-mono text-2xs font-extrabold text-stone-950">
                ₹{expressShippingPrice}
              </span>
            </label>

          </div>
        </div>
      </div>
    </div>
  );
}
