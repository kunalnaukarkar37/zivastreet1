/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShoppingBag, User, Menu, X, LogOut, Package, MapPin, Search } from 'lucide-react';
import { UserProfile } from '../types';

interface NavbarProps {
  user: UserProfile | null;
  cartCount: number;
  activeCategory: 'all' | 'men' | 'women';
  setActiveCategory: (cat: 'all' | 'men' | 'women') => void;
  onCartToggle: () => void;
  onProfileToggle: (tab?: string) => void;
  onLogout: () => void;
  onLoginClick: () => void;
}

export default function Navbar({
  user,
  cartCount,
  activeCategory,
  setActiveCategory,
  onCartToggle,
  onProfileToggle,
  onLogout,
  onLoginClick
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-100">
      <div id="nav-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Mobile Menu Icon */}
          <div className="flex items-center md:hidden">
            <button
              id="mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-stone-700 hover:text-black focus:outline-none p-1"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex space-x-8 text-xs font-semibold uppercase tracking-widest text-stone-600">
            <button
              id="nav-all-btn"
              onClick={() => setActiveCategory('all')}
              className={`transition-colors duration-200 cursor-pointer ${
                activeCategory === 'all' ? 'text-black border-b border-black pb-1' : 'hover:text-black pb-1'
              }`}
            >
              Collection
            </button>
            <button
              id="nav-men-btn"
              onClick={() => setActiveCategory('men')}
              className={`transition-colors duration-200 cursor-pointer ${
                activeCategory === 'men' ? 'text-black border-b border-black pb-1' : 'hover:text-black pb-1'
              }`}
            >
              Men
            </button>
            <button
              id="nav-women-btn"
              onClick={() => setActiveCategory('women')}
              className={`transition-colors duration-200 cursor-pointer ${
                activeCategory === 'women' ? 'text-black border-b border-black pb-1' : 'hover:text-black pb-1'
              }`}
            >
              Women
            </button>
          </nav>

          {/* Brand Logo */}
          <div className="flex-1 md:flex-initial flex justify-center md:justify-start">
            <button
              id="brand-logo"
              onClick={() => setActiveCategory('all')}
              className="text-2xl sm:text-3xl font-extrabold uppercase tracking-widest font-display text-stone-950 flex items-center gap-1 cursor-pointer"
            >
              ZIVA STREET
            </button>
          </div>

          {/* Search, Account, Cart Options */}
          <div className="flex items-center space-x-6">
            
            {/* Account Icon */}
            <div className="relative">
              {user ? (
                <div>
                  <button
                    id="user-profile-btn"
                    onClick={() => setDropdownOpen(!dropdownOpen)}
                    type="button"
                    className="flex items-center text-stone-700 hover:text-black focus:outline-none cursor-pointer"
                  >
                    <User className="h-5.5 w-5.5" />
                    <span className="hidden sm:inline-block ml-1.5 text-xs tracking-wider max-w-[100px] truncate font-medium">
                      {user.fullName.split(' ')[0]}
                    </span>
                  </button>
                  
                  {dropdownOpen && (
                    <div className="origin-top-right absolute right-0 mt-3.5 w-52 rounded-none shadow-xl bg-white border border-stone-200 ring-1 ring-black/5 divide-y divide-stone-100 z-50 animate-fade-in">
                      <div className="px-4 py-3">
                        <p className="text-xs text-stone-500 font-medium">Signed in as</p>
                        <p className="text-sm font-semibold text-stone-900 truncate">{user.fullName}</p>
                      </div>
                      <div className="py-1">
                        <button
                          id="drop-orders"
                          onClick={() => {
                            setDropdownOpen(false);
                            onProfileToggle('orders');
                          }}
                          className="flex w-full items-center px-4 py-2 text-xs font-medium text-stone-700 hover:bg-stone-50 hover:text-stone-900 cursor-pointer"
                        >
                          <Package className="mr-3 h-4 w-4 text-stone-400" />
                          My Orders
                        </button>
                        <button
                          id="drop-track"
                          onClick={() => {
                            setDropdownOpen(false);
                            onProfileToggle('track');
                          }}
                          className="flex w-full items-center px-4 py-2 text-xs font-medium text-stone-700 hover:bg-stone-50 hover:text-stone-900 cursor-pointer"
                        >
                          <Search className="mr-3 h-4 w-4 text-stone-400" />
                          Track Order
                        </button>
                        <button
                          id="drop-address"
                          onClick={() => {
                            setDropdownOpen(false);
                            onProfileToggle('address');
                          }}
                          className="flex w-full items-center px-4 py-2 text-xs font-medium text-stone-700 hover:bg-stone-50 hover:text-stone-900 cursor-pointer"
                        >
                          <MapPin className="mr-3 h-4 w-4 text-stone-400" />
                          Address Book
                        </button>
                      </div>
                      <div className="py-1">
                        <button
                          id="drop-logout"
                          onClick={() => {
                            setDropdownOpen(false);
                            onLogout();
                          }}
                          className="flex w-full items-center px-4 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 hover:text-rose-700 cursor-pointer"
                        >
                          <LogOut className="mr-3 h-4 w-4 text-rose-400" />
                          Logout
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  id="nav-login-btn"
                  onClick={onLoginClick}
                  className="flex items-center text-stone-700 hover:text-black gap-1 cursor-pointer font-medium text-xs tracking-wider uppercase px-2 py-1 rounded-none"
                >
                  <User className="h-5.5 w-5.5" />
                  <span className="hidden sm:inline-block">Sign In</span>
                </button>
              )}
            </div>

            {/* Cart Icon */}
            <button
              id="nav-cart-btn"
              onClick={onCartToggle}
              className="relative text-stone-700 hover:text-black focus:outline-none p-1 cursor-pointer transition-transform active:scale-95"
            >
              <ShoppingBag className="h-5.5 w-5.5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-black text-white text-[9px] font-bold h-4.5 w-4.5 rounded-full flex items-center justify-center border border-white animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div id="mobile-menu" className="md:hidden bg-white border-t border-stone-100 px-4 py-4 space-y-3 shadow-lg">
          <button
            id="mobile-nav-all"
            onClick={() => {
              setActiveCategory('all');
              setMobileMenuOpen(false);
            }}
            className={`block w-full text-left px-3 py-2 rounded-none text-sm font-medium tracking-wider uppercase ${
              activeCategory === 'all' ? 'bg-stone-900 text-white' : 'text-stone-700 hover:bg-stone-50'
            }`}
          >
            Collection
          </button>
          <button
            id="mobile-nav-men"
            onClick={() => {
              setActiveCategory('men');
              setMobileMenuOpen(false);
            }}
            className={`block w-full text-left px-3 py-2 rounded-none text-sm font-medium tracking-wider uppercase ${
              activeCategory === 'men' ? 'bg-stone-900 text-white' : 'text-stone-700 hover:bg-stone-50'
            }`}
          >
            Men
          </button>
          <button
            id="mobile-nav-women"
            onClick={() => {
              setActiveCategory('women');
              setMobileMenuOpen(false);
            }}
            className={`block w-full text-left px-3 py-2 rounded-none text-sm font-medium tracking-wider uppercase ${
              activeCategory === 'women' ? 'bg-stone-900 text-white' : 'text-stone-700 hover:bg-stone-50'
            }`}
          >
            Women
          </button>
        </div>
      )}
    </header>
  );
}
