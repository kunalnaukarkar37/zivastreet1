/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Heart, ShoppingCart, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  key?: string;
  product: Product;
  onAddToCart: (product: Product, size: string) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export default function ProductCard({
  product,
  onAddToCart,
  isWishlisted,
  onToggleWishlist
}: ProductCardProps) {
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0]);
  const [added, setAdded] = useState<boolean>(false);

  const handleAdd = () => {
    onAddToCart(product, selectedSize);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
    }, 1500);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      className="group relative flex flex-col bg-white border border-black/5 overflow-hidden transition-all duration-300 rounded-none hover:border-black/25 hover:shadow-xl"
    >
      {/* Product Image and Tag Container */}
      <div className="relative aspect-[3/4] w-full bg-stone-100 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-104"
          referrerPolicy="no-referrer"
        />

        {/* Backdrop vignette overlay */}
        <div className="absolute inset-0 bg-stone-900/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Brand/Status Tag Badge */}
        {product.tag && (
          <span className="absolute top-3 left-3 bg-stone-950 text-white text-[9px] font-bold uppercase tracking-[0.2em] px-2.5 py-1 z-10 rounded-none">
            {product.tag}
          </span>
        )}

        {/* Favorite Wishlist Icon Button */}
        <button
          id={`wishlist-btn-${product.id}`}
          onClick={() => onToggleWishlist(product.id)}
          className={`absolute top-3 right-3 p-2 rounded-full shadow-sm backdrop-blur transition-all duration-300 hover:scale-110 cursor-pointer z-10 ${
            isWishlisted
              ? 'bg-red-500 text-white'
              : 'bg-white/85 hover:bg-white text-stone-700 hover:text-red-500'
          }`}
          aria-label="Add to wishlist"
        >
          <Heart className={`h-4.5 w-4.5 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Instant Hover Overlay with Add to cart trigger - Desktop */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#1A1A1A]/95 via-[#1A1A1A]/80 to-transparent p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 hidden md:block">
          <p className="text-white text-[10px] uppercase tracking-widest mb-1.5 font-medium">Select Size:</p>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {product.sizes.map((sz) => (
              <button
                key={sz}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedSize(sz);
                }}
                className={`text-[10px] font-bold h-7 px-2.5 border transition-all rounded-none ${
                  selectedSize === sz
                    ? 'bg-white text-stone-950 border-white font-extrabold shadow-md scale-105'
                    : 'bg-stone-900/40 text-stone-200 border-stone-600/50 hover:bg-stone-800'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleAdd();
            }}
            className="w-full py-2.5 bg-white text-stone-950 text-[10px] font-bold uppercase tracking-widest hover:bg-stone-100 transition-colors flex items-center justify-center gap-1.5 cursor-pointer rounded-none"
          >
            {added ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600" />
                Added to Bag
              </>
            ) : (
              <>
                <ShoppingCart className="h-3.5 w-3.5" />
                Add to Bag
              </>
            )}
          </button>
        </div>
      </div>

      {/* Product Information Card Body */}
      <div className="flex flex-col p-4 flex-grow justify-between bg-white text-left">
        <div className="space-y-1">
          <h3 className="text-[10px] uppercase tracking-widest text-[#1A1A1A]/50 font-bold">
            {product.category === 'men' ? "Men's Streetwear" : "Women's Streetwear"}
          </h3>
          <h2 className="text-xs font-semibold uppercase tracking-wider text-stone-950 line-clamp-1 group-hover:text-[#1A1A1A] transition-colors">
            {product.name}
          </h2>
          <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Pricing & Mobile sizing */}
        <div className="pt-3 border-t border-stone-100 mt-3 space-y-3">
          
          {/* Mobile Product Size Quick Pick (Direct interactive feedback) */}
          <div className="block md:hidden">
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#1A1A1A]/50 block mb-1">Pick Size:</span>
            <div className="flex flex-wrap gap-1">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  onClick={() => setSelectedSize(sz)}
                  className={`text-[10px] h-6 px-1.5 border rounded-none transition-all ${
                    selectedSize === sz
                      ? 'bg-stone-950 text-white border-stone-950 font-bold'
                      : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-baseline space-x-1.5">
              <span className="text-sm font-bold font-display italic text-stone-950">₹{product.price.toLocaleString('en-IN')}</span>
              {product.originalPrice && (
                <span className="text-xs text-stone-400 line-through">₹{product.originalPrice.toLocaleString('en-IN')}</span>
              )}
            </div>
            
            {/* Direct Add to Cart Button for mobile and quick buy */}
            <button
              onClick={handleAdd}
              className={`md:hidden px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-widest rounded-none transition-all cursor-pointer ${
                added 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-stone-900 text-stone-100 hover:bg-stone-950'
              }`}
            >
              {added ? 'Added' : 'Add'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
