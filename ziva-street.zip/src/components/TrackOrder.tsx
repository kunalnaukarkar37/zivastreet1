import React, { useState } from 'react';
import { Search, MapPin, Calendar, Clock, AlertTriangle, CheckCircle, Package, Truck, ArrowRight } from 'lucide-react';

interface ScanItem {
  time: string;
  status: string;
  location: string;
  instructions: string;
}

interface TrackData {
  success: boolean;
  waybill: string;
  orderId: string;
  status: 'ordered' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered';
  statusDetails: string;
  estimatedDelivery: string;
  origin: string;
  destination: string;
  scans: ScanItem[];
  isSimulated: boolean;
}

export default function TrackOrder() {
  const [waybill, setWaybill] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [trackingData, setTrackingData] = useState<TrackData | null>(null);

  // Email invoice states
  const [emailInput, setEmailInput] = useState('');
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailStatus, setEmailStatus] = useState<{ success: boolean; message: string } | null>(null);

  const handleSendEmail = async () => {
    if (!emailInput.trim() || !emailInput.includes('@')) {
      setEmailStatus({ success: false, message: 'Please provide a valid email address.' });
      return;
    }
    if (!trackingData) return;

    setSendingEmail(true);
    setEmailStatus(null);
    try {
      const response = await fetch('/api/invoice/email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          orderId: trackingData.orderId,
          email: emailInput.trim(),
        }),
      });

      const data = await response.json();
      if (response.ok && data.success) {
        setEmailStatus({ success: true, message: `Success! Digital Invoice sent to ${emailInput}.` });
      } else {
        setEmailStatus({ success: false, message: data.error || 'Failed to dispatch email.' });
      }
    } catch (err: any) {
      setEmailStatus({ success: false, message: err.message || 'SMTP Network transmission failure.' });
    } finally {
      setSendingEmail(false);
    }
  };

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!waybill.trim()) {
      setError('Please provide a valid waybill number or Ziva Order ID.');
      return;
    }

    setLoading(true);
    setError('');
    setTrackingData(null);

    try {
      // Format input to standard waybill
      let cleanInput = waybill.trim().toUpperCase();
      
      const response = await fetch('/api/shipping/track', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ waybill: cleanInput, orderDate: new Date(Date.now() - 3600000).toISOString() }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Server responded with an error');
      }

      const data = await response.json();
      if (data.success) {
        setTrackingData(data);
      } else {
        setError(data.message || 'No tracking information could be retrieved for this waybill.');
      }
    } catch (err: any) {
      console.error('Tracking query error:', err);
      setError(err.message || 'Logistics network lookup failed. Please check network connection.');
    } finally {
      setLoading(false);
    }
  };

  const getStepProgress = (status: string) => {
    switch (status) {
      case 'ordered': return 1;
      case 'packed': return 2;
      case 'shipped': return 3;
      case 'out_for_delivery': return 4;
      case 'delivered': return 5;
      default: return 1;
    }
  };

  return (
    <div id="delhivery-order-tracker" className="w-full bg-white border border-stone-200 p-6 md:p-8 space-y-6">
      <div className="border-b border-stone-100 pb-4">
        <h3 className="text-sm font-extrabold uppercase tracking-widest text-stone-900 flex items-center gap-2">
          <Truck className="h-5 w-5 text-stone-900" />
          Delhivery Express Tracking Engine
        </h3>
        <p className="text-2xs text-stone-500 uppercase tracking-wider font-semibold mt-1">
          Direct API link to dispatch logistics and active scans network
        </p>
      </div>

      {/* Query Form */}
      <form onSubmit={handleTrack} className="space-y-4">
        <div className="flex flex-col space-y-1.5">
          <label className="text-[10px] font-extrabold uppercase tracking-widest text-stone-500 block">
            Enter Waybill or Tracking Code
          </label>
          <div className="flex shadow-2xs rounded-none">
            <input
              type="text"
              value={waybill}
              onChange={(e) => setWaybill(e.target.value)}
              placeholder="e.g. 190412852 or ZS-TRK-741285"
              className="flex-grow text-xs px-3.5 py-3 border border-stone-250 focus:outline-none bg-stone-50 text-stone-900 font-mono tracking-wider font-bold uppercase"
            />
            <button
              type="submit"
              disabled={loading}
              className="bg-stone-900 hover:bg-black text-white px-6 font-extrabold text-[10px] uppercase tracking-widest transition-colors cursor-pointer disabled:bg-stone-400 inline-flex items-center gap-2"
            >
              {loading ? (
                <span>Searching...</span>
              ) : (
                <>
                  <span>Track</span>
                  <Search className="h-3.5 w-3.5" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Error Message */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200/55 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-rose-800 uppercase tracking-wide">Tracking Link Issue</p>
            <p className="text-2xs text-rose-700 font-medium leading-relaxed mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {/* Tracking Output Result UI */}
      {trackingData && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Main State Card */}
          <div className="p-4 bg-stone-50 border border-stone-200 flex flex-wrap gap-4 items-center justify-between">
            <div className="space-y-1">
              <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest">Courier Manifest Status</span>
              <div className="flex items-center gap-2">
                <div className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <h4 className="text-xs font-black uppercase tracking-wider text-stone-950 font-mono">
                  {trackingData.status.replace('_', ' ')}
                </h4>
              </div>
              <p className="text-2xs text-stone-600 font-semibold">{trackingData.statusDetails}</p>
            </div>

            <div className="text-left py-1 md:text-right space-y-1">
              <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest block">Delhivery Waybill</span>
              <span className="font-mono text-xs font-black text-stone-900 block select-all bg-white px-2 py-1 border border-stone-150 inline-block">
                {trackingData.waybill}
              </span>
            </div>
          </div>

          {/* Delivery estimate Banner */}
          <div className="p-4 border border-emerald-100 bg-emerald-50/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-emerald-700 shrink-0" />
              <div>
                <p className="text-[9px] font-bold text-emerald-800 uppercase tracking-widest leading-none">EXPECTED ARRIVAL</p>
                <p className="text-xs font-extrabold text-stone-900 mt-1">{trackingData.estimatedDelivery}</p>
              </div>
            </div>
            {trackingData.isSimulated && (
              <span className="px-2 py-0.5 bg-amber-100 border border-amber-200/60 text-amber-800 text-[8px] uppercase tracking-wider font-extrabold">
                Live Simulation
              </span>
            )}
          </div>

          {/* Email Invoice Segment */}
          <div className="p-4 border border-stone-200 bg-stone-50/50 space-y-3">
            <div>
              <p className="text-[9px] font-bold text-stone-505 uppercase tracking-widest leading-none">Email Digital Tax Invoice</p>
              <p className="text-[10px] text-stone-500 uppercase tracking-wider font-semibold mt-1">
                Receive the secure, custom-styled HTML & ASCII receipt directly in your inbox.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                placeholder="Enter recipient email address"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                className="flex-grow text-xs px-3 py-2 border border-stone-250 focus:outline-none bg-white text-stone-900 font-medium"
              />
              <button
                type="button"
                onClick={handleSendEmail}
                disabled={sendingEmail || !emailInput}
                className="bg-stone-900 hover:bg-black text-white px-4 py-2 font-bold text-[10px] uppercase tracking-widest transition-colors cursor-pointer disabled:bg-stone-300"
              >
                {sendingEmail ? "Sending..." : "Email Invoice"}
              </button>
            </div>
            {emailStatus && (
              <p className={`text-[9px] font-bold uppercase tracking-wider ${
                emailStatus.success ? 'text-emerald-700' : 'text-rose-600'
              }`}>
                {emailStatus.message}
              </p>
            )}
          </div>

          {/* Transit Stages Status */}
          <div>
            <p className="text-[9px] font-bold text-stone-400 uppercase tracking-widest block mb-3">Live Stages Progression</p>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5 text-center text-xs">
              {[
                { label: 'Booking Confirmed', statusKey: 'ordered', icon: CheckCircle },
                { label: 'Manifest Packed', statusKey: 'packed', icon: Package },
                { label: 'In Transit', statusKey: 'shipped', icon: Truck },
                { label: 'Out For Delivery', statusKey: 'out_for_delivery', icon: Truck },
                { label: 'Package Handed', statusKey: 'delivered', icon: CheckCircle },
              ].map((stage, idx) => {
                const currentStep = getStepProgress(trackingData.status);
                const stepIndex = idx + 1;
                const isDone = stepIndex <= currentStep;
                const isCurrent = stepIndex === currentStep;

                const StageIcon = stage.icon;

                return (
                  <div 
                    key={stage.statusKey} 
                    className={`p-3 border text-center transition-all ${
                      isCurrent 
                        ? 'border-amber-400 bg-amber-50/60 ring-2 ring-amber-100'
                        : isDone 
                        ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                        : 'border-stone-200 bg-stone-50/50 text-stone-400'
                    }`}
                  >
                    <div className="flex justify-center mb-1.5">
                      <StageIcon className="h-4.5 w-4.5" />
                    </div>
                    <p className={`text-[9px] font-bold uppercase tracking-wider leading-tight ${isDone ? 'opacity-100' : 'opacity-60'}`}>
                      {stage.label}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detailed Audit Timelines */}
          <div className="space-y-3">
            <p className="text-[9px] font-bold text-stone-400 uppercase tracking-widest block">Logistics Route Audited Scans ({trackingData.scans.length})</p>
            <div className="border border-stone-200 divide-y divide-stone-150">
              {trackingData.scans.map((scan, sIdx) => (
                <div key={sIdx} className="p-3.5 bg-stone-50 hover:bg-white flex gap-4 items-start text-xs transition-colors">
                  <div className="p-1.5 bg-stone-100 text-stone-600 rounded-none shrink-0 mt-0.5 border border-stone-200">
                    <MapPin className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex-grow space-y-1">
                    <div className="flex flex-wrap justify-between items-center gap-1.5">
                      <h5 className="font-extrabold text-stone-900 text-2xs uppercase tracking-wide">
                        {scan.status}
                      </h5>
                      <span className="text-[9px] text-stone-400 font-mono flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(scan.time).toLocaleString('en-IN', {
                          day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true
                        })}
                      </span>
                    </div>
                    <p className="text-2xs text-stone-600 font-medium">Located at: <strong className="text-stone-950 font-bold uppercase">{scan.location}</strong></p>
                    {scan.instructions && (
                      <p className="text-[10px] text-stone-500 italic font-mono pt-0.5">Note: {scan.instructions}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
