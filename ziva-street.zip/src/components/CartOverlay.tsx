/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Trash2, Ticket, Check, Landmark, ShieldCheck, MapPin } from 'lucide-react';
import { CartItem, SavedAddress, Product } from '../types';
import CheckoutShipping from './CheckoutShipping';

interface CartOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQty: (productId: string, size: string, qty: number) => void;
  onRemoveItem: (productId: string, size: string) => void;
  userAddress: SavedAddress | null;
  onCheckout: (
    shippingAddress: SavedAddress, 
    couponUsed: string, 
    stats: { subtotal: number; discount: number; shipping: number; total: number },
    whatsappConsent: boolean
  ) => void;
}

export default function CartOverlay({
  isOpen,
  onClose,
  cartItems,
  onUpdateQty,
  onRemoveItem,
  userAddress,
  onCheckout
}: CartOverlayProps) {
  const [coupon, setCoupon] = useState<string>('');
  const [couponApplied, setCouponApplied] = useState<boolean>(false);
  const [couponError, setCouponError] = useState<string>('');
  const [whatsappConsent, setWhatsappConsent] = useState<boolean>(true);
  
  // Checkout phase: 'review' | 'address' | 'payment'
  const [checkoutStep, setCheckoutStep] = useState<'review' | 'address' | 'payment'>('review');

  // Address form fields
  const [addressName, setAddressName] = useState<string>('');
  const [addressPhone, setAddressPhone] = useState<string>('');
  const [addressEmail, setAddressEmail] = useState<string>('');
  const [addressStreet, setAddressStreet] = useState<string>('');
  const [addressCity, setAddressCity] = useState<string>('');
  const [addressState, setAddressState] = useState<string>('');
  const [addressPin, setAddressPin] = useState<string>('');
  const [formError, setFormError] = useState<string>('');
  const [shippingOption, setShippingOption] = useState<'surface' | 'express'>('surface');

  // Sync address fields when user details arrive
  useEffect(() => {
    if (userAddress) {
      setAddressName(userAddress.fullName);
      setAddressPhone(userAddress.phone);
      if (userAddress.email) {
        setAddressEmail(userAddress.email);
      }
      setAddressStreet(userAddress.streetAddress);
      setAddressCity(userAddress.city);
      setAddressState(userAddress.state);
      setAddressPin(userAddress.pinCode);
    }
    const cachedUserRaw = localStorage.getItem('ziva_user');
    if (cachedUserRaw) {
      try {
        const cachedUser = JSON.parse(cachedUserRaw);
        if (cachedUser && cachedUser.email) {
          setAddressEmail(cachedUser.email);
        }
      } catch (e) {}
    }
  }, [userAddress]);

  if (!isOpen) return null;

  // Totals calculations
  const subtotal = cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const discountRate = couponApplied ? 0.20 : 0.0;
  const discountAmount = Math.round(subtotal * discountRate);
  
  const shippingThreshold = 699;
  const isFreeShipping = subtotal > shippingThreshold;
  const baseShippingFee = subtotal === 0 ? 0 : (isFreeShipping ? 0 : 99);
  const shippingFee = subtotal === 0 ? 0 : (shippingOption === 'express' ? 149 : baseShippingFee);
  
  const finalTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const applyCouponHandler = () => {
    const code = coupon.trim().toUpperCase();
    if (code === 'DADU') {
      setCouponApplied(true);
      setCouponError('');
    } else if (code === '') {
      setCouponError('Please enter a coupon code.');
    } else {
      setCouponError('Invalid Coupon Code. Try using DADU!');
      setCouponApplied(false);
    }
  };

  const handleQuickApply = () => {
    setCoupon('DADU');
    setCouponApplied(true);
    setCouponError('');
  };

  const handleNextStep = () => {
    if (checkoutStep === 'review') {
      if (cartItems.length === 0) return;
      setCheckoutStep('address');
    } else if (checkoutStep === 'address') {
      if (!addressName || !addressPhone || !addressEmail || !addressStreet || !addressCity || !addressState || !addressPin) {
        setFormError('Please fill out all details including email for instant receipt delivery.');
        return;
      }
      if (!addressEmail.includes("@")) {
        setFormError('Please provide a valid email address.');
        return;
      }
      setFormError('');
      setCheckoutStep('payment');
    }
  };

  const submitPayment = () => {
    if (!whatsappConsent) {
      setFormError('You must agree to receive order updates on WhatsApp from Ziva Street.');
      return;
    }

    const finalAddress: SavedAddress = {
      fullName: addressName,
      phone: addressPhone,
      email: addressEmail,
      streetAddress: addressStreet,
      city: addressCity,
      state: addressState,
      pinCode: addressPin
    };

    onCheckout(finalAddress, couponApplied ? 'DADU' : '', {
      subtotal,
      discount: discountAmount,
      shipping: shippingFee,
      total: finalTotal
    }, whatsappConsent);

    // Reset step
    setCheckoutStep('review');
    setCoupon('');
    setCouponApplied(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
      <div className="absolute inset-0 overflow-hidden">
        {/* Background dark blur panel */}
        <div onClick={onClose} className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity cursor-pointer animate-fade-in" />

        <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
          <div className="pointer-events-auto w-screen max-w-md">
            <div className="flex h-full flex-col bg-white shadow-2xl border-l border-stone-200">
              
              {/* Header */}
              <div className="px-6 py-5 border-b border-stone-100 flex items-center justify-between bg-stone-50">
                <h2 id="slide-over-title" className="text-base font-bold uppercase tracking-wider text-stone-950 font-display flex items-center gap-2">
                  Shopping Bag
                  <span className="text-xs px-2 py-0.5 bg-stone-900 text-white rounded-none font-mono">{cartItems.length}</span>
                </h2>
                <button
                  id="close-cart-btn"
                  onClick={onClose}
                  className="p-1.5 text-stone-400 hover:text-black hover:bg-stone-100 cursor-pointer transition-colors rounded-none"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Progress Stepper for Checkout Wizard */}
              {cartItems.length > 0 && (
                <div id="checkout-stepper" className="bg-stone-100 px-6 py-3.5 flex items-center justify-between text-2xs uppercase tracking-widest font-bold border-b border-stone-150">
                  <span className={`${checkoutStep === 'review' ? 'text-stone-950 underline decoration-2' : 'text-stone-400'}`}>1. Review</span>
                  <span className="text-stone-300">/</span>
                  <span className={`${checkoutStep === 'address' ? 'text-stone-950 underline decoration-2' : 'text-stone-400'}`}>2. Shipping</span>
                  <span className="text-stone-300">/</span>
                  <span className={`${checkoutStep === 'payment' ? 'text-stone-950 underline decoration-2' : 'text-stone-400'}`}>3. Checkout</span>
                </div>
              )}

              {/* Editable Body panel */}
              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">

                {cartItems.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
                    <div className="h-16 w-16 bg-stone-100 rounded-full flex items-center justify-center text-stone-400">
                      <Trash2 className="h-8 w-8" />
                    </div>
                    <h3 className="text-sm font-bold uppercase tracking-wider text-stone-900 font-display">Your Bag is Empty</h3>
                    <p className="text-xs text-stone-500 max-w-xs">Streetwear waits for no one! Browse our collections and add items to your cart, beta.</p>
                    <button
                      id="cart-continue-shopping"
                      onClick={onClose}
                      className="px-6 py-3 bg-stone-950 text-white text-xs font-bold uppercase tracking-widest hover:bg-stone-900 transition-colors cursor-pointer"
                    >
                      Browse Boutique
                    </button>
                  </div>
                ) : (
                  <>
                    {/* STEP 1: REVIEW CART ITEMS */}
                    {checkoutStep === 'review' && (
                      <div className="space-y-4">
                        {/* Free Shipping Tracker Banner */}
                        <div className="p-3 bg-stone-50 border border-stone-150 rounded-none text-center">
                          {isFreeShipping ? (
                            <span className="text-xs font-semibold text-emerald-700 block">✨ Congratulations! You unlocked **FREE express shipping**</span>
                          ) : (
                            <div className="space-y-1.5">
                              <span className="text-xs text-stone-600 block">
                                Add <strong className="text-black font-semibold">₹{(699 - subtotal).toLocaleString('en-IN')}</strong> more to unlock <strong>FREE DELIVERY</strong>!
                              </span>
                              <div className="w-full bg-stone-200 h-1 rounded-none overflow-hidden">
                                <div 
                                  className="bg-stone-950 h-full transition-all duration-500 rounded-none" 
                                  style={{ width: `${Math.min(100, (subtotal / 699) * 100)}%` }} 
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Cart Items List */}
                        <div className="flow-root">
                          <ul role="list" className="divide-y divide-stone-150">
                            {cartItems.map((item) => (
                              <li key={`${item.product.id}-${item.selectedSize}`} className="flex py-4">
                                <div className="h-20 w-16 flex-shrink-0 border border-stone-200 overflow-hidden bg-stone-100 rounded-none">
                                  <img
                                    src={item.product.image}
                                    alt={item.product.name}
                                    className="h-full w-full object-cover object-center"
                                    referrerPolicy="no-referrer"
                                  />
                                </div>

                                <div className="ml-4 flex flex-1 flex-col justify-between">
                                  <div>
                                    <div className="flex justify-between text-xs font-bold text-stone-950 tracking-wide font-display">
                                      <h3 className="line-clamp-1">{item.product.name}</h3>
                                      <p className="ml-4">₹{(item.product.price * item.quantity).toLocaleString('en-IN')}</p>
                                    </div>
                                    <p className="mt-0.5 text-3xs font-semibold uppercase tracking-widest text-stone-400">Size: {item.selectedSize}</p>
                                  </div>

                                  <div className="flex items-center justify-between text-xs">
                                    <div className="flex items-center border border-stone-250 rounded-none">
                                      <button
                                        onClick={() => onUpdateQty(item.product.id, item.selectedSize, item.quantity - 1)}
                                        className="p-1 px-2.5 text-stone-500 hover:text-black cursor-pointer bg-stone-50 hover:bg-stone-100 text-xs font-extrabold rounded-none"
                                      >
                                        <Minus className="h-2.5 w-2.5" />
                                      </button>
                                      <span className="px-3 font-mono text-stone-900 font-bold text-2xs">{item.quantity}</span>
                                      <button
                                        onClick={() => onUpdateQty(item.product.id, item.selectedSize, item.quantity + 1)}
                                        className="p-1 px-2.5 text-stone-500 hover:text-black cursor-pointer bg-stone-50 hover:bg-stone-100 text-xs font-extrabold rounded-none"
                                      >
                                        <Plus className="h-2.5 w-2.5" />
                                      </button>
                                    </div>

                                    <button
                                      onClick={() => onRemoveItem(item.product.id, item.selectedSize)}
                                      type="button"
                                      className="font-medium text-[#1A1A1A]/60 hover:text-black cursor-pointer flex items-center gap-1 text-[10px] tracking-wider uppercase p-1.5 hover:bg-stone-100 rounded-none"
                                    >
                                      <Trash2 className="h-3 w-3" />
                                      Remove
                                    </button>
                                  </div>
                                </div>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}

                    {/* STEP 2: SHIPPING ADDRESS ENTRY */}
                    {checkoutStep === 'address' && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-extrabold uppercase tracking-widest text-stone-900">Shipping coordinates</h3>
                          <button 
                            onClick={() => setCheckoutStep('review')}
                            className="text-stone-500 hover:text-black underline text-2xs uppercase tracking-wider cursor-pointer"
                          >
                            Back To Review
                          </button>
                        </div>

                        {userAddress && (
                          <div className="bg-stone-100 text-stone-800 p-2.5 rounded-none border border-stone-200 text-2xs flex items-start gap-1.5">
                            <MapPin className="h-4 w-4 shrink-0 mt-0.5 text-[#1A1A1A]" />
                            <span>Address prefilled from your registered account details, beta! You can customize below if needed.</span>
                          </div>
                        )}

                        <div className="space-y-3.5">
                          <CheckoutShipping
                            fullName={addressName}
                            setFullName={setAddressName}
                            phone={addressPhone}
                            setPhone={setAddressPhone}
                            email={addressEmail}
                            setEmail={setAddressEmail}
                            streetAddress={addressStreet}
                            setStreetAddress={setAddressStreet}
                            city={addressCity}
                            setCity={setAddressCity}
                            state={addressState}
                            setState={setAddressState}
                            pinCode={addressPin}
                            setPinCode={setAddressPin}
                            shippingOption={shippingOption}
                            setShippingOption={setShippingOption}
                            subtotal={subtotal}
                          />

                          {formError && (
                            <p className="text-rose-500 font-semibold text-2xs text-center">{formError}</p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* STEP 3: DEMO PAYMENT INSTANT GATEWAY */}
                    {checkoutStep === 'payment' && (
                      <div className="space-y-5">
                        <div className="flex items-center justify-between">
                          <h3 className="text-xs font-extrabold uppercase tracking-widest text-stone-900">Demostration payment gateway</h3>
                          <button 
                            onClick={() => setCheckoutStep('address')}
                            className="text-stone-500 hover:text-black underline text-2xs uppercase tracking-wider cursor-pointer"
                          >
                            Edit Coordinates
                          </button>
                        </div>

                        <div className="bg-stone-50 border border-stone-200 p-4 font-normal text-left space-y-3.5 text-xs text-stone-700">
                          <div className="flex items-center gap-1.5 text-stone-900 font-bold uppercase text-[10px] tracking-wider leading-none">
                            <Landmark className="h-4 w-4 text-stone-700" />
                            Secure Sandbox Checkout Mode
                          </div>
                          
                          <p>We have integrated our test/demo payment process as specified. You do not need to punch in actual credit card numbers or UPI handles.</p>
                          
                          <div className="border-t border-stone-200 pt-3 text-2xs space-y-1">
                            <p className="text-stone-500 uppercase tracking-widest font-semibold">Consignee:</p>
                            <p className="font-bold text-stone-900">{addressName} | Contact: {addressPhone}</p>
                            <p>{addressStreet}, {addressCity}, {addressState} - {addressPin}</p>
                          </div>
                        </div>

                        <div className="p-3 bg-stone-100 text-[#1A1A1A]/80 border border-stone-200 rounded-none text-2xs flex items-start gap-2">
                          <ShieldCheck className="h-4.5 w-4.5 shrink-0 text-stone-950 mt-0.5" />
                          <span>Tap the <strong>Payment Done</strong> trigger below to safely complete this fashion checkout simulation. Ziva Street server will generate your tracking and order ID instantly.</span>
                        </div>

                        {/* WhatsApp Explicit Consent Agreement Checkbox */}
                        <div className="pt-2">
                          <label className="flex items-start gap-2 text-xs text-stone-800 font-medium cursor-pointer leading-relaxed select-none">
                            <input 
                              type="checkbox" 
                              required 
                              checked={whatsappConsent}
                              onChange={(e) => {
                                setWhatsappConsent(e.target.checked);
                                if (e.target.checked) setFormError('');
                              }}
                              className="mt-1 h-4 w-4 bg-stone-100 accent-stone-950 cursor-pointer shrink-0 border border-stone-350" 
                            />
                            <span>I agree to receive order updates on WhatsApp from Ziva Street.</span>
                          </label>
                        </div>

                        {formError && (
                          <p className="text-rose-500 font-bold text-2xs text-center pt-1 animate-pulse">
                            ⚠ {formError}
                          </p>
                        )}
                      </div>
                    )}
                  </>
                )}

              </div>

              {/* Price audit footer breakdown - ALWAYS VISIBLE if basket has content */}
              {cartItems.length > 0 && (
                <div className="border-t border-stone-150 px-6 py-5 bg-stone-50 space-y-4">
                  
                  {/* Coupon Field - Only on review slide */}
                  {checkoutStep === 'review' && (
                    <div className="space-y-2">
                      <div className="flex shadow-sm rounded-none">
                        <div className="relative flex-grow">
                          <Ticket className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
                          <input
                            type="text"
                            value={coupon}
                            onChange={(e) => setCoupon(e.target.value)}
                            disabled={couponApplied}
                            className="w-full text-xs pl-10 pr-3 py-2.5 border border-stone-250 focus:outline-none bg-white text-stone-900 uppercase font-semibold font-mono tracking-widest disabled:bg-stone-100 disabled:text-stone-400"
                            placeholder="Enter Code (e.g. DADU)"
                          />
                        </div>
                        <button
                          onClick={applyCouponHandler}
                          disabled={couponApplied}
                          className="px-5 py-2.5 bg-stone-900 text-white text-[10px] font-extrabold uppercase tracking-widest hover:bg-stone-950 transition-colors disabled:bg-emerald-600 disabled:text-white cursor-pointer inline-flex items-center gap-1"
                        >
                          {couponApplied ? <Check className="h-3 w-3" /> : 'Apply'}
                        </button>
                      </div>

                      {couponError && (
                        <p className="text-rose-500 font-bold text-[10px] tracking-wide">{couponError}</p>
                      )}

                      {couponApplied ? (
                        <p className="text-[#1A1A1A] font-semibold text-2xs bg-stone-100 py-1.5 px-2.5 rounded-none border border-stone-200 flex justify-between items-center">
                          <span>🎉 Code <b>DADU</b> applied! Flat 20% savings.</span>
                          <button onClick={() => setCouponApplied(false)} className="text-[#1A1A1A] underline ml-2 hover:font-bold cursor-pointer font-sans leading-none text-[10px]">Remove</button>
                        </p>
                      ) : (
                        <div className="text-[10px] text-stone-500 text-left">
                          💡 Suggestion: Tap <button onClick={handleQuickApply} className="text-stone-950 font-bold hover:underline cursor-pointer">DADU</button> to apply an immediate 20% discount!
                        </div>
                      )}
                    </div>
                  )}

                  <div className="space-y-1.5 text-xs tracking-wide">
                    <div className="flex justify-between text-stone-500">
                      <span>Subtotal</span>
                      <span className="font-mono font-medium">₹{subtotal.toLocaleString('en-IN')}</span>
                    </div>
                    {couponApplied && (
                      <div className="flex justify-between text-emerald-600">
                        <span>Coupon Savings (20% Off)</span>
                        <span className="font-mono font-medium">- ₹{discountAmount.toLocaleString('en-IN')}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-stone-500">
                      <span>Shipping Delivery</span>
                      <span className="font-mono font-medium">
                        {shippingFee === 0 ? "FREE" : `₹${shippingFee}`}
                      </span>
                    </div>
                    <div className="flex justify-between font-extrabold text-stone-950 border-t border-stone-200 pt-2 text-sm font-display">
                      <span>Est. Total Due</span>
                      <span className="font-mono">₹{finalTotal.toLocaleString('en-IN')}</span>
                    </div>
                  </div>

                  {/* Progressive Actions based on checkout sequence */}
                  {checkoutStep === 'review' && (
                    <button
                      id="cart-review-next"
                      onClick={handleNextStep}
                      className="w-full py-4 bg-stone-950 text-white text-xs font-bold uppercase tracking-widest hover:bg-stone-900 transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5 rounded-none shadow-none"
                    >
                      Proceed to Address Coordinates
                    </button>
                  )}

                  {checkoutStep === 'address' && (
                    <button
                      id="cart-address-next"
                      onClick={handleNextStep}
                      className="w-full py-4 bg-stone-950 text-white text-xs font-bold uppercase tracking-widest hover:bg-stone-900 transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5 rounded-none shadow-none"
                    >
                      Continue to Payment options
                    </button>
                  )}

                  {checkoutStep === 'payment' && (
                    <button
                      id="cart-payment-complete"
                      onClick={submitPayment}
                      className="w-full py-4 bg-stone-950 text-white border border-stone-800 text-xs font-bold uppercase tracking-widest hover:bg-stone-900 transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5 rounded-none shadow-none"
                    >
                      Payment Done (Place Order)
                    </button>
                  )}

                  <p className="text-[10px] text-center text-stone-400">
                    Complimentary courier dispatch on cart purchases over ₹699.
                  </p>
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
