/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Sparkles, User, HelpCircle, CornerDownLeft } from 'lucide-react';
import { ChatMessage, CartItem, Order, UserProfile } from '../types';

interface DaduChatbotProps {
  user: UserProfile | null;
  cartItems: CartItem[];
  onOpenProfile: (tab?: string) => void;
  onOpenCart: () => void;
}

export default function DaduChatbot({
  user,
  cartItems,
  onOpenProfile,
  onOpenCart
}: DaduChatbotProps) {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "initial",
      sender: "dadu",
      text: "Namaste beta! 🙏 I am DADU, your personal Ziva Street caretaker. Looking for a flat 20% discount coupon (hint: type DADU), tracking your stylish drapes, or need help around our boutique? Tell your dadu anything, what can I help you find today, beta?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll inside chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputText.trim();
    if (!textToSend) return;

    if (!customText) setInputText('');

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      // Coordinate session contextual parameters for DADU backend
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: messages,
          context: {
            userId: user?.id || null,
            currentCart: cartItems,
            orderHistory: user?.orders || []
          }
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        const daduMsg: ChatMessage = {
          id: `dadu-${Date.now()}`,
          sender: 'dadu',
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages((prev) => [...prev, daduMsg]);
      } else {
        throw new Error();
      }
    } catch (error) {
      const daduErrorMsg: ChatMessage = {
        id: `dadu-err-${Date.now()}`,
        sender: 'dadu',
        text: "My spectacles got misplaced momentarily, beta! 👓 Let me know if you want to use coupon 'DADU' for 20% off, track your orders on your profile, or if I can fetch fresh tea! What was that again?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, daduErrorMsg]);
    } finally {
      setLoading(false);
    }
  };

  // Quick reply prompt presets
  const presets = [
    { text: "Claim Active Coupons 🏷️", value: "Show me the discount coupons" },
    { text: "Free Delivery eligibility? 🚚", value: "What is the condition for free shipping?" },
    { text: "Track my package 📦", value: "How do I track my active order status?" },
    { text: "Access Address Book 🗺️", value: "Where can check my profile and addresses?" }
  ];

  return (
    <div id="dadu-chatbot-container" className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Expanded Chat Dialogue Window */}
      {isOpen && (
        <div 
          id="dadu-chat-window" 
          className="w-[90vw] sm:w-[380px] h-[500px] bg-white rounded-none shadow-2xl border border-stone-200/90 flex flex-col overflow-hidden mb-4 animate-fade-in origin-bottom-right"
        >
          {/* Header */}
          <div className="bg-stone-900 text-white px-4 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 bg-amber-400 text-stone-900 rounded-full flex items-center justify-center font-bold text-sm tracking-tighter" title="Dadu Avatar">
                👴
              </div>
              <div>
                <div className="flex items-center gap-1">
                  <h3 className="text-xs font-bold uppercase tracking-widest font-display text-white">Caretaker DADU</h3>
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <p className="text-[10px] text-stone-400">Ziva Street Concierge • Active</p>
              </div>
            </div>
            
            <button 
              id="close-dadu-btn"
              onClick={() => setIsOpen(false)}
              className="text-stone-400 hover:text-white p-1 hover:bg-stone-800 rounded transition-colors cursor-pointer"
            >
              <X className="h-4.5 w-4.5" />
            </button>
          </div>

          {/* Messages screen */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-stone-50/50">
            {messages.map((m) => {
              const isDadu = m.sender === 'dadu';
              return (
                <div 
                  key={m.id} 
                  className={`flex items-start gap-2.5 max-w-[85%] ${isDadu ? 'mr-auto text-left' : 'ml-auto flex-row-reverse text-right'}`}
                >
                  <div className={`h-6 w-6 rounded-full shrink-0 flex items-center justify-center text-[10px] font-bold ${
                    isDadu ? 'bg-amber-100 text-amber-800 border' : 'bg-stone-900 text-white'
                  }`}>
                    {isDadu ? '👴' : <User className="h-3 w-3" />}
                  </div>

                  <div className="space-y-1">
                    <div className={`p-3 rounded-none text-xs gap-1 shadow-xs leading-relaxed font-normal ${
                      isDadu 
                        ? 'bg-white border border-stone-150 text-stone-800 rounded-tl-none' 
                        : 'bg-stone-900 text-stone-100 rounded-tr-none'
                    }`}>
                      {/* Formats basic bold / lists nicely matching markdown guidelines */}
                      <p className="whitespace-pre-line">{m.text}</p>
                    </div>
                    <span className="text-[8px] text-stone-400 block px-1">{m.timestamp}</span>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex items-center gap-2 mr-auto text-stone-500 max-w-[85%]">
                <div className="h-6 w-6 rounded-full bg-amber-50 border flex items-center justify-center text-[10px]">👴</div>
                <div className="p-2.5 rounded bg-white border text-3xs font-mono tracking-widest text-stone-400 rounded-tl-none uppercase animate-pulse">
                  Dadu is thinking...
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Quick replies triggers list */}
          <div className="px-3.5 py-2 border-t border-b border-stone-100 bg-white/55 overflow-x-auto no-scrollbar flex gap-2 shrink-0">
            {presets.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(p.value)}
                className="shrink-0 px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 text-[10px] font-bold uppercase tracking-wider rounded-none border border-stone-200/50 cursor-pointer active:scale-95 transition-transform"
              >
                {p.text}
              </button>
            ))}
          </div>

          {/* Input control docks */}
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
            className="p-3 border-t border-stone-200 flex bg-white"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask Dadu beta..."
              className="flex-grow text-xs focus:outline-none bg-stone-50 text-stone-900 placeholder-stone-400 px-3 py-2 border border-stone-200"
            />
            <button
              type="submit"
              className="ml-2 w-9 h-9 shrink-0 rounded-none bg-stone-900 text-white flex items-center justify-center hover:bg-black transition-colors cursor-pointer"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}

      {/* Primary Sticky Circular Chat Switch Toggle Trigger BUTTON */}
      <button
        id="dadu-chatbot-toggle-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="h-14 w-14 rounded-full bg-stone-950 text-white flex items-center justify-center shadow-2xl hover:scale-105 active:scale-95 cursor-pointer border border-stone-800 transition-all z-50 group hover:bg-black"
        aria-label="Toggle DADU Assistant"
      >
        {isOpen ? (
          <X className="h-5.5 w-5.5 text-stone-300 group-hover:text-white" />
        ) : (
          <div className="relative flex items-center justify-center">
            {/* Sparkles effect behind */}
            <span className="absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-25 animate-ping" />
            <div className="text-xl group-hover:scale-110 transition-transform">👴</div>
            <div className="absolute -top-1.5 -right-2 bg-amber-400 text-stone-950 text-[8px] font-extrabold uppercase px-1 py-0.5 rounded-full scale-90 border border-stone-950 leading-none">
              DADU
            </div>
          </div>
        )}
      </button>

    </div>
  );
}
