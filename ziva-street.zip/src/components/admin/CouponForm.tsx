import React, { useState } from 'react';
import { Tag, Plus, Edit, Trash2, Calendar, ShoppingBag, Eye, ToggleLeft, ToggleRight, Info } from 'lucide-react';
import { Coupon } from '../../types';

interface CouponFormProps {
  coupons: Coupon[];
  onAddCoupon: (couponData: any) => void;
  onUpdateCoupon: (couponId: string, couponData: any) => void;
  onDeleteCoupon: (couponId: string) => void;
}

export default function CouponForm({ coupons, onAddCoupon, onUpdateCoupon, onDeleteCoupon }: CouponFormProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    discountPercent: 15,
    minCartValue: 500,
    usageLimit: 500,
    active: true
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.code || formData.discountPercent <= 0) {
      alert("Please provide a valid code and a positive discount percent.");
      return;
    }

    if (editingId) {
      onUpdateCoupon(editingId, formData);
      setEditingId(null);
    } else {
      onAddCoupon(formData);
    }
    setFormData({ code: '', discountPercent: 15, minCartValue: 500, usageLimit: 500, active: true });
  };

  const startEdit = (c: Coupon) => {
    setEditingId(c.id);
    setFormData({
      code: c.code,
      discountPercent: c.discountPercent,
      minCartValue: c.minCartValue || 0,
      usageLimit: c.usageLimit || 500,
      active: c.active !== false
    });
  };

  const toggleCouponStatus = (c: Coupon) => {
    onUpdateCoupon(c.id, { active: !c.active });
  };

  return (
    <div id="coupons-mgr-wrapper" className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Listing Block - col Span 2 */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
          <div className="p-4 bg-stone-50 border-b border-stone-150 flex items-center justify-between">
            <span className="text-xs uppercase font-bold tracking-widest text-stone-500 font-mono">
              Launched Coupon Codes Inventory
            </span>
            <span className="text-[10px] bg-amber-500/15 text-amber-800 font-mono font-bold px-2.5 py-0.5 rounded border border-amber-500/20">
              {coupons.length} CODES ACTIVE
            </span>
          </div>

          <div className="overflow-x-auto">
            <table id="admin-coupons-table" className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-stone-150 text-[10px] font-bold text-stone-400 uppercase tracking-widest bg-stone-50/50">
                  <th className="py-3 px-6">Promo Code</th>
                  <th className="py-3 px-6">Percentage Deducts</th>
                  <th className="py-3 px-6">Minimum Cart Threshold</th>
                  <th className="py-3 px-6 text-center">Usage Metrics (Used/Cap)</th>
                  <th className="py-3 px-6 text-center font-bold">State</th>
                  <th className="py-3 px-6 text-center">Trigger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-150">
                {coupons.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-stone-400 font-mono text-xs">
                      No active coupon promo schemas designed.
                    </td>
                  </tr>
                ) : (
                  coupons.map((c) => (
                    <tr key={c.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          <Tag className="h-3.5 w-3.5 text-amber-500" />
                          <span className="font-mono font-bold text-xs bg-stone-100 text-stone-800 px-2 py-0.5 border border-stone-200 rounded">
                            {c.code}
                          </span>
                        </div>
                      </td>
                      <td className="py-4 px-6 text-xs text-stone-900 font-bold font-mono">
                        {c.discountPercent}% OFF sitewide
                      </td>
                      <td className="py-4 px-6 text-xs text-stone-605 font-medium font-mono">
                        ₹{c.minCartValue || 0}
                      </td>
                      <td className="py-4 px-6 text-center text-xs font-mono text-stone-500">
                        <span className="text-stone-800 font-semibold">{c.usageCount || 0}</span> / {c.usageLimit || '∞'}
                      </td>
                      <td className="py-4 px-6 text-center">
                        <button
                          id={`coupon-toggle-${c.id}`}
                          onClick={() => toggleCouponStatus(c)}
                          className="hover:scale-105 transition cursor-pointer"
                          title="Toggle active status"
                        >
                          <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold border leading-tight ${
                            c.active !== false 
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-150' 
                              : 'bg-stone-50 text-stone-400 border-stone-250'
                          }`}>
                            {c.active !== false ? 'ACTIVE' : 'INACTIVE'}
                          </span>
                        </button>
                      </td>
                      <td className="py-4 px-6 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            id={`coupon-edit-btn-${c.id}`}
                            onClick={() => startEdit(c)}
                            className="p-1 hover:bg-stone-100 rounded text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
                          >
                            <Edit className="h-3.5 w-3.5" />
                          </button>
                          <button
                            id={`coupon-delete-btn-${c.id}`}
                            onClick={() => {
                              if (confirm(`Do you want to delete promo code ${c.code}?`)) {
                                onDeleteCoupon(c.id);
                              }
                            }}
                            className="p-1 hover:bg-rose-50 rounded text-stone-400 hover:text-rose-600 transition-colors cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Manager Creator Panel - col Span 1 */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-sm h-fit">
          <div className="border-b border-stone-150 pb-4 mb-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
              <Tag className="h-4 w-4 text-amber-600" />
              <span>{editingId ? 'Edit Promo Code' : 'Draft Coupon'}</span>
            </h3>
            <p className="text-[11px] text-stone-400 mt-1">
              Set live percent discounts tied to local checkout code lookups quickly.
            </p>
          </div>

          <form id="coupon-creator-form" onSubmit={handleSave} className="space-y-4">
            {/* Promo Code string */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                Promo Stamp Character (Capital Letters Only)
              </label>
              <input
                id="form-coupon-code"
                type="text"
                required
                placeholder="e.g. MONSOON25"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white font-mono uppercase"
              />
            </div>

            {/* Percent & minimum */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Discounts (% Deduction)
                </label>
                <input
                  id="form-coupon-percent"
                  type="number"
                  required
                  min={1}
                  max={100}
                  value={formData.discountPercent}
                  onChange={(e) => setFormData({ ...formData, discountPercent: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Minimum Cart Subtotal
                </label>
                <input
                  id="form-coupon-min"
                  type="number"
                  min={0}
                  value={formData.minCartValue}
                  onChange={(e) => setFormData({ ...formData, minCartValue: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                />
              </div>
            </div>

            {/* Cap usage limit and Active selection */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Usage Limit Capacity
                </label>
                <input
                  id="form-coupon-limit"
                  type="number"
                  min={1}
                  value={formData.usageLimit}
                  onChange={(e) => setFormData({ ...formData, usageLimit: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Coupon Status
                </label>
                <div className="flex items-center gap-2 h-8">
                  <input
                    id="form-coupon-active-toggle"
                    type="checkbox"
                    checked={formData.active}
                    onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                    className="cursor-pointer h-4 w-4 rounded text-amber-600 accent-amber-500"
                  />
                  <span className="text-xs text-stone-605">Instantly Live</span>
                </div>
              </div>
            </div>

            {/* Save Buttons */}
            <div className="flex gap-2 pb-1 pt-2">
              <button
                type="button"
                id="form-coupon-cancel"
                onClick={() => {
                  setEditingId(null);
                  setFormData({ code: '', discountPercent: 15, minCartValue: 500, usageLimit: 500, active: true });
                }}
                className="w-1/2 py-2 border border-stone-200 rounded text-stone-700 hover:bg-stone-50 text-xs font-semibold cursor-pointer"
              >
                Clear
              </button>
              <button
                type="submit"
                id="form-coupon-save"
                className="w-1/2 py-2 bg-stone-900 border border-transparent hover:bg-stone-850 text-stone-100 text-xs font-bold rounded transition-colors cursor-pointer"
              >
                {editingId ? 'Modify Coupon' : 'Launch Coupon'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
