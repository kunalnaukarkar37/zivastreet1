import React, { useState } from 'react';
import { Image, Plus, Trash2, Edit, Check, Eye, ToggleLeft, ToggleRight, ExternalLink } from 'lucide-react';
import { Banner } from '../../types';

interface BannerManagerProps {
  banners: Banner[];
  onAddBanner: (bannerData: any) => void;
  onUpdateBanner: (bannerId: string, bannerData: any) => void;
  onDeleteBanner: (bannerId: string) => void;
}

export default function BannerManager({ banners, onAddBanner, onUpdateBanner, onDeleteBanner }: BannerManagerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    image: '',
    title: '',
    subtitle: '',
    ctaText: 'Shop the Silhouette',
    active: true
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.image || !formData.title) {
      alert("Please provide at least a Title and an Image URL.");
      return;
    }
    onAddBanner(formData);
    setIsAdding(false);
    setFormData({ image: '', title: '', subtitle: '', ctaText: 'Shop the Silhouette', active: true });
  };

  const toggleStatus = (b: Banner) => {
    onUpdateBanner(b.id, { active: !b.active });
  };

  return (
    <div id="banners-main-wrapper" className="space-y-6">
      {/* Banner Action Header */}
      <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-stone-200 shadow-xs">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest text-stone-500 font-mono">
            Front-Page Visual Hero Banner Slides
          </h3>
          <p className="text-[11px] text-stone-400 mt-1 max-w-lg leading-tight">
            Configure immersive, high-resolution lifestyle images reflecting our seasonal Indo-Western drops.
          </p>
        </div>

        <button 
          id="banner-add-toggle-btn"
          onClick={() => setIsAdding(!isAdding)}
          className="bg-stone-900 text-stone-50 hover:bg-stone-800 px-4 py-2 rounded-lg text-xs font-bold font-sans tracking-wide transition flex items-center gap-1.5 cursor-pointer"
        >
          {isAdding ? 'Close Builder' : 'Deploy Hero Image'}
        </button>
      </div>

      {/* Deployment Form */}
      {isAdding && (
        <div className="bg-white p-5 rounded-xl border border-stone-250 shadow-md animate-in slide-in-from-top duration-200">
          <form id="banner-creator-form" onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="md:col-span-2 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Campaign Heading
                  </label>
                  <input
                    id="form-banner-title"
                    type="text"
                    required
                    placeholder="e.g. ATELIER CAPSULE 02"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Sub-Cowl / Tagline line
                  </label>
                  <input
                    id="form-banner-subtitle"
                    type="text"
                    placeholder="e.g. Traditional Drape-Styles Redefined"
                    value={formData.subtitle}
                    onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                  />
                </div>
              </div>

              {/* Second row: CTA and URL */}
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2 space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Image Asset URL
                  </label>
                  <input
                    id="form-banner-image"
                    type="text"
                    required
                    placeholder="https://images.unsplash.com/..."
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    CTA Action Text
                  </label>
                  <input
                    id="form-banner-cta"
                    type="text"
                    placeholder="Explore Collection"
                    value={formData.ctaText}
                    onChange={(e) => setFormData({ ...formData, ctaText: e.target.value })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 font-medium"
                  />
                </div>
              </div>
            </div>

            {/* Side column: preview & switch */}
            <div className="space-y-4 border-l border-stone-150 pl-5 flex flex-col justify-between">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Campaign Settings
                </label>
                <div className="flex items-center gap-2 h-8">
                  <input
                    id="form-banner-active-toggle"
                    type="checkbox"
                    checked={formData.active}
                    onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                    className="cursor-pointer h-4 w-4 rounded text-amber-500 accent-amber-500 border-stone-350"
                  />
                  <span className="text-xs text-stone-605">Instantly launch as active flyer</span>
                </div>
              </div>

              <button
                type="submit"
                id="form-banner-save-btn"
                className="w-full py-2 bg-stone-900 border border-transparent hover:bg-stone-850 text-stone-100 text-xs font-bold rounded transition cursor-pointer"
              >
                Assemble Flyer
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Grid of existing flyer slide banners */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {banners.map((b) => (
          <div key={b.id} className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden flex flex-col relative group">
            {/* Aspect image layer */}
            <div className="h-44 overflow-hidden relative border-b border-stone-205">
              <img 
                src={b.image} 
                alt="" 
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-350" 
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 to-transparent flex items-end p-5">
                <div>
                  <h4 className="text-sm font-serif font-bold text-white tracking-tight leading-none uppercase">
                    {b.title}
                  </h4>
                  <p className="text-[10px] text-stone-300 mt-1 font-sans">
                    {b.subtitle}
                  </p>
                </div>
              </div>
              
              {/* Abs delete button */}
              <button
                id={`banner-delete-${b.id}`}
                onClick={() => {
                  if (confirm("Permanently remove this campaign slide?")) {
                    onDeleteBanner(b.id);
                  }
                }}
                className="absolute top-3 right-3 p-1.5 bg-stone-900/80 backdrop-blur-xs text-stone-300 hover:text-rose-450 hover:bg-stone-950 rounded-md transition cursor-pointer"
                title="Deauthorise flyer slide"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            {/* Actions panel footer */}
            <div className="p-4 bg-stone-50/75 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="text-stone-400">Button:</span>
                <span className="font-semibold text-stone-900 bg-stone-200 px-2 py-0.5 rounded text-[10px]">
                  {b.ctaText}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-stone-400 text-[10px]">Campaign Mode:</span>
                <button
                  id={`banner-toggle-active-${b.id}`}
                  onClick={() => toggleStatus(b)}
                  className="font-bold flex items-center cursor-pointer"
                >
                  <span className={`px-2 py-0.5 rounded text-[9px] border leading-normal ${
                    b.active !== false 
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-150' 
                      : 'bg-stone-100 text-stone-450 border-stone-200'
                  }`}>
                    {b.active !== false ? 'ACTIVE FLYER' : 'STANDBY FLYER'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
