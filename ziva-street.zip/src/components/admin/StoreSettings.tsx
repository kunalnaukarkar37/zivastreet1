import React, { useState } from 'react';
import { Settings, Save, Sliders, Volume2, ShieldCheck, HelpCircle } from 'lucide-react';

interface StoreSettingsProps {
  settings: {
    taxRate: number;
    freeDeliveryThreshold: number;
    shopOpen: boolean;
    statusMessage: string;
  };
  onUpdateSettings: (settingsData: any) => void;
}

export default function StoreSettings({ settings, onUpdateSettings }: StoreSettingsProps) {
  const [formData, setFormData] = useState({
    taxRate: settings?.taxRate ?? 5,
    freeDeliveryThreshold: settings?.freeDeliveryThreshold ?? 699,
    shopOpen: settings?.shopOpen !== false,
    statusMessage: settings?.statusMessage ?? "Unlock 20% OFF sitewide with coupon: DADU • Free Delivery above ₹699"
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formData);
    alert("System configurations synced & saved successfully!");
  };

  return (
    <div id="settings-main-wrapper" className="max-w-2xl bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
      <div className="p-6 border-b border-stone-150 bg-stone-50">
        <h3 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
          <Settings className="h-4.5 w-4.5 text-stone-605 text-amber-500" />
          <span>General E-Commerce Platform Controls</span>
        </h3>
        <p className="text-[11px] text-stone-400 mt-1">
          Adjust taxation ratios, free express dispatch barriers, and live header announcement ticker messages instantly.
        </p>
      </div>

      <form id="settings-creator-form" onSubmit={handleSave} className="p-6 space-y-5">
        
        {/* Tax Ratios & Shipping Barriers */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
              Default GST Surtax Ratio (%)
            </label>
            <div className="relative">
              <input
                id="form-set-tax"
                type="number"
                required
                min={0}
                max={30}
                value={formData.taxRate}
                onChange={(e) => setFormData({ ...formData, taxRate: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white focus:outline-none"
              />
              <span className="absolute right-3.5 top-2 text-[10px] text-stone-400 font-mono font-bold">%</span>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
              Free Delivery Barrier (INR)
            </label>
            <div className="relative">
              <input
                id="form-set-delivery"
                type="number"
                required
                min={0}
                value={formData.freeDeliveryThreshold}
                onChange={(e) => setFormData({ ...formData, freeDeliveryThreshold: Number(e.target.value) })}
                className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white focus:outline-none"
              />
              <span className="absolute right-3 top-2 text-[10px] text-stone-400 font-mono font-bold">₹</span>
            </div>
          </div>
        </div>

        {/* Global Boutique Open check */}
        <div className="p-4 border border-stone-200 rounded-lg bg-stone-50/30 flex items-center justify-between">
          <div className="space-y-0.5">
            <h4 className="text-xs font-bold text-stone-850">
              Online Checkout Gate Open
            </h4>
            <p className="text-[10px] text-stone-400 leading-none">
              When standbys are active, guest checkout pathways process normally.
            </p>
          </div>

          <input
            id="form-set-open"
            type="checkbox"
            checked={formData.shopOpen}
            onChange={(e) => setFormData({ ...formData, shopOpen: e.target.checked })}
            className="cursor-pointer h-5 w-5 rounded text-amber-500 border-stone-300 pointer-events-auto select-none accent-amber-500"
          />
        </div>

        {/* Ticker news screen messages */}
        <div className="space-y-1.5">
          <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
            Top Headline Announcement Ticker Phrase
          </label>
          <div className="relative flex items-center">
            <Volume2 className="h-4 w-4 absolute left-3.5 text-stone-400 shrink-0" />
            <input
              id="form-set-ticker"
              type="text"
              required
              placeholder="e.g. Free Delivery Above ₹699 + Coupon DADU gives 20% off!"
              value={formData.statusMessage}
              onChange={(e) => setFormData({ ...formData, statusMessage: e.target.value })}
              className="w-full pl-9 pr-4 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white font-medium"
            />
          </div>
          <p className="text-[9px] text-stone-405 text-stone-400 leading-tight">
            *This announcement syncs across client front-ends instantly, displayed at the highest header position above navbar.
          </p>
        </div>

        {/* Sync actions buttons */}
        <div className="border-t border-stone-150 pt-5 flex justify-end">
          <button
            type="submit"
            id="settings-save-btn"
            className="px-5 py-2 bg-stone-900 border border-transparent hover:bg-stone-850 text-stone-50 text-xs font-bold rounded flex items-center gap-1.5 transition cursor-pointer"
          >
            <Save className="h-4 w-4" />
            <span>Sync Platform settings</span>
          </button>
        </div>
      </form>
    </div>
  );
}
