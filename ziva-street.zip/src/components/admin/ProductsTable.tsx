import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  Edit, 
  Trash2, 
  Image, 
  Check, 
  X, 
  Tag, 
  Package,
  Eye,
  SlidersHorizontal,
  FolderMinus,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { Product } from '../../types';

interface ProductsTableProps {
  products: Product[];
  onAddProduct: (productData: any) => void;
  onEditProduct: (productId: string, productData: any) => void;
  onDeleteProduct: (productId: string) => void;
}

export default function ProductsTable({ 
  products, 
  onAddProduct, 
  onEditProduct, 
  onDeleteProduct 
}: ProductsTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'men' | 'women'>('all');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 1500,
    category: 'men' as 'men' | 'women',
    image: '',
    sizes: ['M', 'L', 'XL'],
    tag: '',
    originalPrice: 2000,
    stock: 25,
    active: true
  });

  const availableSizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

  const filteredProducts = products.filter(p => {
    const textMatch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const catMatch = categoryFilter === 'all' || p.category === categoryFilter;
    return textMatch && catMatch;
  });

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: 1500,
      category: 'men',
      image: '',
      sizes: ['M', 'L', 'XL'],
      tag: '',
      originalPrice: 2000,
      stock: 25,
      active: true
    });
  };

  const handleSizeToggle = (size: string) => {
    if (formData.sizes.includes(size)) {
      setFormData({
        ...formData,
        sizes: formData.sizes.filter(s => s !== size)
      });
    } else {
      setFormData({
        ...formData,
        sizes: [...formData.sizes, size]
      });
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price || !formData.image) {
      alert("Name, Price, and Image URL are required fields!");
      return;
    }

    if (editingProduct) {
      onEditProduct(editingProduct.id, formData);
      setEditingProduct(null);
    } else {
      onAddProduct(formData);
      setIsAdding(false);
    }
    resetForm();
  };

  const startEdit = (p: Product) => {
    setEditingProduct(p);
    setFormData({
      name: p.name,
      description: p.description || '',
      price: p.price,
      category: p.category,
      image: p.image,
      sizes: p.sizes,
      tag: p.tag || '',
      originalPrice: p.originalPrice || p.price,
      stock: (p as any).stock !== undefined ? (p as any).stock : 15,
      active: (p as any).active !== false
    });
    setIsAdding(false);
  };

  const startAdd = () => {
    resetForm();
    setIsAdding(true);
    setEditingProduct(null);
  };

  return (
    <div id="product-mgr-main" className="space-y-4">
      {/* Control panel and Filters */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white p-4 rounded-xl border border-stone-200">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
          <input
            id="products-search-input"
            type="text"
            placeholder="Search items by name, ID or tags..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-stone-200 rounded-lg text-sm bg-stone-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/10 transition-colors"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            id="products-category-filter"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as any)}
            className="w-full md:w-40 py-2 px-3 border border-stone-200 rounded-lg text-sm bg-white focus:outline-none"
          >
            <option value="all">All Genders</option>
            <option value="men">Men's Wardrobe</option>
            <option value="women">Women's Wardrobe</option>
          </select>

          <button
            id="products-add-btn"
            onClick={startAdd}
            className="w-full md:w-auto bg-stone-900 text-stone-50 hover:bg-stone-850 px-4 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Launch Item</span>
          </button>
        </div>
      </div>

      {/* Main split display: lists + forms */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Product listing table - col Span 2 */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table id="admin-products-table" className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-stone-550/5 bg-stone-50 text-[11px] font-bold text-stone-405 text-stone-400 uppercase tracking-widest border-b border-stone-150">
                  <th className="py-4 px-6">Product Details</th>
                  <th className="py-4 px-6">Category</th>
                  <th className="py-4 px-6 text-right">Price (INR)</th>
                  <th className="py-4 px-6 text-center">In Stock</th>
                  <th className="py-4 px-6 text-center">Status</th>
                  <th className="py-4 px-6 text-center">Edit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-150">
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-12 text-stone-400 text-sm font-mono">
                      No matching products currently launched in this section.
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map((p) => {
                    const isProdActive = p.active !== false;
                    const prodStock = (p as any).stock !== undefined ? (p as any).stock : 15;
                    return (
                      <tr key={p.id} className="hover:bg-stone-50/25 transition-colors group">
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-3">
                            <img 
                              src={p.image} 
                              alt={p.name} 
                              className="h-11 w-11 object-cover rounded border border-stone-200"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <div className="text-xs font-bold text-stone-900 group-hover:text-amber-600 transition-colors">
                                {p.name}
                              </div>
                              <div className="text-[10px] text-stone-400 font-mono mt-0.5 max-w-[210px] truncate">
                                {p.id} • Sizes: {p.sizes.join(', ')}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-xs uppercase font-semibold text-stone-500">
                          {p.category}
                        </td>
                        <td className="py-4 px-6 text-right">
                          <div className="text-xs font-bold text-stone-900">
                            ₹{p.price}
                          </div>
                          {p.originalPrice && p.originalPrice > p.price && (
                            <div className="text-[10px] text-stone-450 line-through text-stone-400">
                              ₹{p.originalPrice}
                            </div>
                          )}
                        </td>
                        <td className="py-4 px-6 text-center font-mono text-xs text-stone-600">
                          <span className={`px-2 py-0.5 rounded leading-none text-[11px] ${
                            prodStock < 5 ? 'bg-amber-100 text-amber-700 font-bold border border-amber-200' : 'bg-stone-105'
                          }`}>
                            {prodStock}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-center">
                          <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold border leading-tight ${
                            p.active !== false 
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-150' 
                              : 'bg-stone-100 text-stone-500 border-stone-200'
                          }`}>
                            {p.active !== false ? 'ACTIVE' : 'INACTIVE'}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              id={`product-edit-btn-${p.id}`}
                              onClick={() => startEdit(p)}
                              className="p-1.5 hover:bg-stone-100 rounded text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
                              title="Edit product specs"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              id={`product-delete-btn-${p.id}`}
                              onClick={() => {
                                if (confirm(`Are you sure you want to permanently withdraw "${p.name}"?`)) {
                                  onDeleteProduct(p.id);
                                }
                              }}
                              className="p-1.5 hover:bg-rose-50 rounded text-stone-400 hover:text-rose-600 transition-colors cursor-pointer"
                              title="Delete product record"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Create / Edit Form Area - Col Span 1 */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-sm h-fit">
          <div className="border-b border-stone-150 pb-4 mb-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
              <Package className="h-4 w-4 text-amber-600" />
              <span>{editingProduct ? `Edit ${editingProduct.id}` : 'Launch Fresh Piece'}</span>
            </h3>
            <p className="text-[11px] text-stone-400 mt-1">
              Add details of new garment collections to launch inside our store catalog immediately.
            </p>
          </div>

          {(isAdding || editingProduct) ? (
            <form id="product-edit-form" onSubmit={handleSave} className="space-y-4">
              {/* Product name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-550 block">
                  Product Code / Collection Title
                </label>
                <input
                  id="form-product-name"
                  type="text"
                  required
                  placeholder="e.g., Indigo Splatter Oversized Kurta"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white focus:outline-none"
                />
              </div>

              {/* Price & original price */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-550 block">
                    Retail Price (INR)
                  </label>
                  <input
                    id="form-product-price"
                    type="number"
                    required
                    min={1}
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-550 block">
                    Original Strikeout
                  </label>
                  <input
                    id="form-product-orig"
                    type="number"
                    value={formData.originalPrice}
                    onChange={(e) => setFormData({ ...formData, originalPrice: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                  />
                </div>
              </div>

              {/* Category & Tag */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Category Gender
                  </label>
                  <select
                    id="form-product-cat"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full py-1.5 px-3 border border-stone-200 rounded text-xs bg-white focus:outline-none"
                  >
                    <option value="men">Men</option>
                    <option value="women">Women</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Ad Badge Tag
                  </label>
                  <input
                    id="form-product-tag"
                    type="text"
                    placeholder="e.g. Best Seller"
                    value={formData.tag}
                    onChange={(e) => setFormData({ ...formData, tag: e.target.value })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                  />
                </div>
              </div>

              {/* High precision stock & active selectors */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Stock Quantity
                  </label>
                  <input
                    id="form-product-stock"
                    type="number"
                    required
                    min={0}
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                    Store Visibility
                  </label>
                  <div className="flex items-center gap-2 h-8">
                    <input
                      id="form-product-active-toggle"
                      type="checkbox"
                      checked={formData.active}
                      onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                      className="cursor-pointer h-4 w-4 rounded border-stone-300 focus:ring-amber-500 accent-amber-550 text-amber-600"
                    />
                    <span className="text-xs text-stone-600">Active Listing</span>
                  </div>
                </div>
              </div>

              {/* Sizes Selector */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Available Sizes Config
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {availableSizes.map(sz => {
                    const isSelected = formData.sizes.includes(sz);
                    return (
                      <button
                        key={sz}
                        type="button"
                        id={`form-size-${sz}`}
                        onClick={() => handleSizeToggle(sz)}
                        className={`px-2.5 py-1 text-[10px] rounded font-mono font-bold border transition cursor-pointer ${
                          isSelected 
                            ? 'bg-amber-500 border-amber-500 text-stone-950 font-bold' 
                            : 'bg-stone-50 border-stone-200 text-stone-500 hover:bg-stone-100'
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Image URL path */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Unsplash Image Asset URL
                </label>
                <input
                  id="form-product-image"
                  type="text"
                  required
                  placeholder="e.g. https://images.unsplash.com/..."
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs font-mono bg-stone-50/50"
                />
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                  Garment Fabric & Design Description
                </label>
                <textarea
                  id="form-product-desc"
                  rows={3}
                  placeholder="Provide heavy double-breasted premium streetwear specifics..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white focus:outline-none"
                />
              </div>

              {/* Action operations buttons */}
              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  id="form-cancel-btn"
                  onClick={() => {
                    setEditingProduct(null);
                    setIsAdding(false);
                    resetForm();
                  }}
                  className="w-1/2 py-2 border border-stone-200 rounded text-stone-700 hover:bg-stone-100 text-xs font-semibold cursor-pointer"
                >
                  Clear Details
                </button>
                <button
                  type="submit"
                  id="form-save-btn"
                  className="w-1/2 py-2 bg-stone-900 hover:bg-stone-850 text-stone-50 font-bold rounded text-xs transition-colors cursor-pointer"
                >
                  Save Apparel
                </button>
              </div>
            </form>
          ) : (
            <div className="text-center py-12 bg-stone-50 rounded-lg p-6 border border-dashed border-stone-200 text-stone-400">
              <Package className="h-8 w-8 mx-auto text-stone-300 mb-2" />
              <p className="text-xs">No active clothing card edit currently chosen.</p>
              <button 
                id="form-toggle-add-btn"
                onClick={startAdd}
                className="mt-3 text-xs bg-stone-900 text-stone-100 px-3 py-1.5 rounded hover:bg-stone-800 transition cursor-pointer"
              >
                Create New Apparel Card
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
