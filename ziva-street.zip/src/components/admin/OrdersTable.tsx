import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  FileText, 
  Mail, 
  MessageSquare, 
  Truck, 
  Printer, 
  X, 
  CheckCircle,
  Eye,
  SlidersHorizontal,
  ChevronDown,
  ExternalLink
} from 'lucide-react';
import { Order } from '../../types';

interface OrdersTableProps {
  orders: Order[];
  onUpdateStatus: (orderId: string, status: any) => void;
  onAssignTracking: (orderId: string, trackingId: string) => void;
  onResendNotification: (orderId: string, channel: 'email' | 'whatsapp' | 'invoice') => void;
  onSelectOrderInvoice: (orderId: string) => void;
}

export default function OrdersTable({ 
  orders, 
  onUpdateStatus, 
  onAssignTracking, 
  onResendNotification,
  onSelectOrderInvoice
}: OrdersTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [newTrackingId, setNewTrackingId] = useState('');

  // Sorter / search filters
  const filteredOrders = orders.filter(o => {
    const textMatch = 
      o.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (o.trackingId && o.trackingId.toLowerCase().includes(searchTerm.toLowerCase())) ||
      o.address.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.address.phone.includes(searchTerm) ||
      (o.address.email && o.address.email.toLowerCase().includes(searchTerm.toLowerCase()));

    const statusMatch = statusFilter === 'all' || o.status === statusFilter;
    return textMatch && statusMatch;
  });

  const getStatusBadgeClass = (status: string) => {
    switch(status) {
      case 'ordered':
        return 'bg-blue-50 text-blue-700 border-blue-155';
      case 'packed':
        return 'bg-amber-50 text-amber-700 border-amber-155';
      case 'shipped':
        return 'bg-indigo-50 text-indigo-750 border-indigo-155';
      case 'out_for_delivery':
        return 'bg-cyan-50 text-cyan-700 border-cyan-155';
      case 'delivered':
        return 'bg-emerald-50 text-emerald-700 border-emerald-155';
      case 'cancelled':
      default:
        return 'bg-stone-50 text-stone-550 border-stone-155';
    }
  };

  const statusOptions = ['ordered', 'packed', 'shipped', 'out_for_delivery', 'delivered', 'cancelled'];

  return (
    <div id="orders-manager-panel" className="space-y-4">
      {/* Control Filter Toolbar */}
      <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white p-4 rounded-xl border border-stone-200">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
          <input
            id="orders-search"
            type="text"
            placeholder="Search Order ID, name, phone, tracking..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-stone-200 rounded-lg text-sm bg-stone-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/10 placeholder-stone-400 transition-colors"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <Filter className="h-4 w-4 text-stone-400 shrink-0" />
          <select
            id="orders-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full md:w-48 py-2 px-3 border border-stone-200 rounded-lg text-sm bg-white cursor-pointer focus:outline-none focus:ring-1 focus:ring-stone-400"
          >
            <option value="all">All Order Statuses</option>
            {statusOptions.map(opt => (
              <option key={opt} value={opt}>
                {opt.replace(/_/g, ' ').toUpperCase()}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Orders Grid/Table Container */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table id="admin-orders-table" className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-stone-50/75 text-[11px] font-bold text-stone-400 uppercase tracking-widest border-b border-stone-150">
                <th className="py-4 px-6">ID & Date</th>
                <th className="py-4 px-6">Customer Details</th>
                <th className="py-4 px-6 text-right">Cart Total</th>
                <th className="py-4 px-6">Delivery Hub Details</th>
                <th className="py-4 px-6 uppercase text-center">Status</th>
                <th className="py-4 px-6 text-center">Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-150">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-stone-400 text-sm font-mono">
                    No order shipments found matching your selection.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-stone-50/50 transition-colors group">
                    <td className="py-4 px-6">
                      <div className="font-mono text-xs font-semibold text-stone-950">
                        {ord.id}
                      </div>
                      <div className="text-[10px] text-stone-400 mt-1 font-mono">
                        {new Date(ord.date).toLocaleString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-xs font-bold text-stone-900">
                        {ord.address.fullName}
                      </div>
                      <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                        +91 {ord.address.phone} | {ord.address.email || "Guest"}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="text-xs font-bold text-stone-900">
                        ₹{ord.total.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[9px] text-stone-400 font-mono mt-0.5 uppercase">
                        {ord.items.length} items | {ord.couponCode || "None"}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-[11px] font-mono font-semibold text-stone-700 flex items-center gap-1.5 leading-none">
                        <Truck className="h-3 w-3 text-stone-400 shrink-0" />
                        <span>{ord.trackingId || "No tracking assigned"}</span>
                      </div>
                      <div className="text-[10px] text-stone-400 mt-1 truncate max-w-[190px]">
                        {ord.address.city}, {ord.address.state} - {ord.address.pinCode}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-center">
                      <span className={`inline-flex px-2.5 py-0.5 rounded text-[10px] font-bold uppercase border leading-normal tracking-wider ${getStatusBadgeClass(ord.status)}`}>
                        {ord.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          id={`order-view-details-${ord.id}`}
                          onClick={() => {
                            setSelectedOrder(ord);
                            setNewTrackingId(ord.trackingId || '');
                          }}
                          className="p-1.5 rounded hover:bg-stone-100 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
                          title="View complete shipment drawer"
                        >
                          <Eye className="h-4.5 w-4.5" />
                        </button>
                        <button
                          id={`order-invoice-${ord.id}`}
                          onClick={() => onSelectOrderInvoice(ord.id)}
                          className="p-1.5 rounded hover:bg-stone-100 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
                          title="Generate Tax Receipt"
                        >
                          <FileText className="h-4.5 w-4.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed Shipment Modal Drawer */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-stone-950/40 backdrop-blur-xs flex items-center justify-end z-50">
          <div id="order-drawer" className="bg-white w-full max-w-xl h-full flex flex-col shadow-2xl relative animate-in slide-in-from-right duration-250">
            {/* Header */}
            <div className="p-6 border-b border-stone-200 flex items-center justify-between bg-stone-50">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-600 font-mono">
                  Order Operations Drawer
                </span>
                <h3 className="text-base font-bold font-serif text-stone-900">
                  Manage Parcel {selectedOrder.id}
                </h3>
              </div>
              <button
                id="close-order-drawer"
                onClick={() => setSelectedOrder(null)}
                className="p-2 hover:bg-stone-200 rounded-full text-stone-500 hover:text-stone-700 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Sizing timeline */}
              <div>
                <h4 className="text-[11px] font-bold text-stone-400 uppercase tracking-widest mb-3">
                  Couriers Trackpoint Status Progress
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  <select
                    id="drawer-order-status-selector"
                    value={selectedOrder.status}
                    onChange={(e) => {
                      onUpdateStatus(selectedOrder.id, e.target.value);
                      setSelectedOrder({ ...selectedOrder, status: e.target.value as any });
                    }}
                    className="col-span-2 py-1.5 px-3 border border-stone-200 rounded text-sm bg-white cursor-pointer focus:outline-none"
                  >
                    {statusOptions.map(opt => (
                      <option key={opt} value={opt}>
                        {opt.replace(/_/g, ' ').toUpperCase()}
                      </option>
                    ))}
                  </select>
                  <button
                    id="drawer-cancel-btn"
                    disabled={selectedOrder.status === 'cancelled'}
                    onClick={() => {
                      if (confirm("Are you sure you want to cancel this order?")) {
                        onUpdateStatus(selectedOrder.id, 'cancelled');
                        setSelectedOrder({ ...selectedOrder, status: 'cancelled' });
                      }
                    }}
                    className="py-1.5 px-3 border border-stone-200 text-rose-600 rounded text-xs font-bold hover:bg-rose-50 hover:border-rose-100 transition-colors disabled:opacity-40 cursor-pointer"
                  >
                    Cancel Order
                  </button>
                </div>
              </div>

              {/* Courier Setup */}
              <div className="p-4 border border-stone-200 rounded-lg space-y-3 bg-stone-50/50">
                <h4 className="text-xs font-bold text-stone-850 flex items-center gap-1.5 font-sans">
                  <Truck className="h-4.5 w-4.5 text-stone-500" />
                  <span>Shipment Logistics Routing (Cargo Track)</span>
                </h4>
                
                <div className="flex gap-2.5">
                  <input
                    id="drawer-tracking-id-input"
                    type="text"
                    placeholder="Assign Custom Delhivery Tracking ID..."
                    value={newTrackingId}
                    onChange={(e) => setNewTrackingId(e.target.value)}
                    className="flex-1 py-1.5 px-3 border border-stone-200 rounded text-xs font-mono"
                  />
                  <button
                    id="drawer-assign-tracking-btn"
                    onClick={() => {
                      onAssignTracking(selectedOrder.id, newTrackingId);
                      setSelectedOrder({ ...selectedOrder, trackingId: newTrackingId });
                      alert("Successfully updated tracking information!");
                    }}
                    className="px-4 py-1.5 bg-stone-900 text-stone-100 hover:bg-stone-800 text-xs font-semibold rounded transition"
                  >
                    Assign
                  </button>
                </div>
                <p className="text-[10px] text-stone-400 font-mono leading-relaxed mt-1">
                  *This tracking code maps directly to Delhivery Air cargo and propagates active timelines immediately on the track-order lookup page.
                </p>
              </div>

              {/* Order items summary */}
              <div className="space-y-2">
                <h4 className="text-[11px] font-bold text-stone-400 uppercase tracking-widest pl-1">
                  Ordered Streetwear Apparel Details
                </h4>
                <div className="bg-stone-50 rounded-lg p-4 border border-stone-150 split-y divide-stone-150 divide-y space-y-2">
                  {selectedOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-xs py-2">
                      <div className="flex items-center gap-3">
                        <img 
                          src={item.product?.image} 
                          alt="" 
                          className="h-10 w-10 object-cover rounded border border-stone-200"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-bold text-stone-900">{item.product?.name}</div>
                          <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                            Size: <span className="font-semibold text-stone-700">{item.selectedSize}</span> • Qty: <span className="font-semibold text-stone-700">{item.quantity}</span>
                          </div>
                        </div>
                      </div>
                      <div className="font-bold text-stone-900">
                        ₹{(item.product?.price * item.quantity).toLocaleString('en-IN')}
                      </div>
                    </div>
                  ))}
                  
                  {/* Totals table */}
                  <div className="pt-3 text-[11px] space-y-1 bg-stone-30 bg-stone-50 pt-3">
                    <div className="flex justify-between text-stone-500 font-mono">
                      <span>Consolidated Subtotal:</span>
                      <span>₹{selectedOrder.subtotal?.toLocaleString('en-IN')}</span>
                    </div>
                    {selectedOrder.discount > 0 && (
                      <div className="flex justify-between text-rose-600 font-mono">
                        <span>Coupon Discount ({selectedOrder.couponCode || 'DADU'}):</span>
                        <span>-₹{selectedOrder.discount?.toLocaleString('en-IN')}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-stone-500 font-mono">
                      <span>Delhivery Cargo Shipping:</span>
                      <span>{selectedOrder.shipping === 0 ? 'FREE' : `₹${selectedOrder.shipping}`}</span>
                    </div>
                    <div className="flex justify-between text-stone-900 font-serif font-bold text-sm pt-2 border-t border-stone-200">
                      <span>Total Paid Amount:</span>
                      <span>₹{selectedOrder.total?.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Delivery Consignee details */}
              <div className="space-y-3">
                <h4 className="text-[11px] font-bold text-stone-400 uppercase tracking-widest pl-1">
                  Recipient Shipping Address
                </h4>
                <div className="p-4 border border-stone-250 bg-stone-50 rounded-lg text-xs space-y-1.5 font-mono">
                  <div><strong className="text-stone-850">Full Consignee:</strong> {selectedOrder.address.fullName}</div>
                  <div><strong className="text-stone-850">Phone Node:</strong> +91 {selectedOrder.address.phone}</div>
                  <div><strong className="text-stone-850">Address Line:</strong> {selectedOrder.address.streetAddress}</div>
                  <div><strong className="text-stone-850">Destination City:</strong> {selectedOrder.address.city}, {selectedOrder.address.state} - {selectedOrder.address.pinCode}</div>
                </div>
              </div>

              {/* System Alerts Dispatches */}
              <div className="space-y-2">
                <h4 className="text-[11px] font-bold text-stone-400 uppercase tracking-widest pl-1">
                  Manual Alert Notifications Resend Hub
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    id="drawer-resend-invoice-btn"
                    onClick={() => onResendNotification(selectedOrder.id, 'invoice')}
                    className="py-2.5 bg-stone-100 hover:bg-stone-200 font-semibold border border-stone-200 text-stone-800 rounded text-[11px] flex flex-col items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <FileText className="h-4 w-4" />
                    <span>Resend Invoice</span>
                  </button>

                  <button
                    id="drawer-resend-email-btn"
                    onClick={() => onResendNotification(selectedOrder.id, 'email')}
                    className="py-2.5 bg-stone-100 hover:bg-stone-200 font-semibold border border-stone-200 text-stone-800 rounded text-[11px] flex flex-col items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Mail className="h-4 w-4" />
                    <span>Resend Email</span>
                  </button>

                  <button
                    id="drawer-resend-whatsapp-btn"
                    onClick={() => onResendNotification(selectedOrder.id, 'whatsapp')}
                    className="py-2.5 bg-stone-100 hover:bg-stone-200 font-semibold border border-stone-200 text-stone-800 rounded text-[11px] flex flex-col items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <MessageSquare className="h-4 w-4" />
                    <span>WhatsApp PNs</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end gap-3 text-xs">
              <button
                id="drawer-print-btn"
                onClick={() => {
                  alert("Opening browser printable view context...");
                  window.print();
                }}
                className="px-4 py-2 border border-stone-300 rounded text-stone-700 hover:bg-stone-100 transition whitespace-nowrap cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="h-3.5 w-3.5" />
                <span>Print Document</span>
              </button>
              
              <button
                id="drawer-save-close-btn"
                onClick={() => setSelectedOrder(null)}
                className="px-5 py-2 bg-stone-900 border border-transparent text-stone-100 hover:bg-stone-855 rounded transition font-bold"
              >
                Save Details & Exit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
