import React, { useState, useEffect } from 'react';
import { Search, Bell, Shield, Clock, RefreshCw } from 'lucide-react';

interface TopbarProps {
  title: string;
  adminName: string;
  onRefresh?: () => void;
}

export default function Topbar({ title, adminName, onRefresh }: TopbarProps) {
  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header id="admin-topbar" className="h-16 bg-white border-b border-stone-200 flex items-center justify-between px-8 shrink-0">
      {/* Page Title & Breadcrumb */}
      <div className="flex items-center gap-4">
        <h1 id="topbar-title" className="text-xl font-serif font-bold text-stone-900 tracking-tight">
          {title}
        </h1>
        
        {onRefresh && (
          <button 
            id="topbar-refresh-btn"
            onClick={onRefresh}
            className="p-1 px-2.5 rounded hover:bg-stone-100 text-stone-500 hover:text-stone-700 text-xs flex items-center gap-1 transition-colors cursor-pointer"
            title="Refresh database collections"
          >
            <RefreshCw className="h-3 w-3" />
            <span>Sync DB</span>
          </button>
        )}
      </div>

      {/* Utilities Section */}
      <div className="flex items-center gap-6">
        {/* Real-time Clock indicator */}
        <div id="topbar-clock" className="hidden md:flex items-center gap-2 text-xs font-mono text-stone-500 bg-stone-100 px-3 py-1.5 rounded-md border border-stone-150">
          <Clock className="h-3.5 w-3.5 text-stone-400 animate-pulse" />
          <span>UTC {timeStr || "14:58:06"}</span>
        </div>

        {/* Admin Badge Panel */}
        <div id="topbar-badge" className="flex items-center gap-3">
          <div className="flex flex-col text-right">
            <span className="text-xs font-semibold text-stone-900 leading-tight">
              {adminName}
            </span>
            <span className="text-[10px] text-amber-600 font-medium tracking-wider uppercase font-mono">
              Systems Root Admin
            </span>
          </div>

          <div className="h-9 w-9 bg-stone-900 text-amber-500 rounded-full border border-stone-800 flex items-center justify-center font-serif font-bold text-sm shadow shadow-stone-800/10">
            {adminName.slice(0, 1).toUpperCase()}
          </div>
        </div>
      </div>
    </header>
  );
}
