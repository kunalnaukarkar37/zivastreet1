import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  KeyRound, 
  RotateCw, 
  Sliders, 
  Eye, 
  Sparkles, 
  X, 
  CheckCircle2, 
  ChevronRight, 
  AlertCircle
} from 'lucide-react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import DashboardView from './DashboardView';
import OrdersTable from './OrdersTable';
import ProductsTable from './ProductsTable';
import CustomersTable from './CustomersTable';
import CouponForm from './CouponForm';
import BannerManager from './BannerManager';
import InvoicePreview from './InvoicePreview';
import SupportManager from './SupportManager';
import StoreSettings from './StoreSettings';
import { Order, Product, Coupon, Banner, SupportMessage } from '../../types';

interface AdminPanelProps {
  onBackToStore: () => void;
}

export default function AdminPanel({ onBackToStore }: AdminPanelProps) {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  // Active Admin View Tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // API State Pools
  const [stats, setStats] = useState<any>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [supportMessages, setSupportMessages] = useState<SupportMessage[]>([]);
  const [settings, setSettings] = useState<any>(null);

  const [loading, setLoading] = useState<boolean>(true);
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  // Recover admin session on init
  useEffect(() => {
    const isSessionActive = sessionStorage.getItem('admin_token');
    if (isSessionActive === 'mock-ziva-token') {
      setIsLoggedIn(true);
    } else {
      setLoading(false);
    }
  }, []);

  // Fetch all collections on successful logins
  useEffect(() => {
    if (isLoggedIn) {
      loadAllCollections();
    }
  }, [isLoggedIn]);

  const loadAllCollections = async () => {
    setLoading(true);
    try {
      // Load standard dashboards statistics
      const statsRes = await fetch('/api/admin/dashboard-stats');
      const statsData = await statsRes.json();
      if (statsData.success) {
        setStats(statsData.stats);
        setOrders(statsData.recentOrders);
      }

      // Load products catalog directly from DB file (fresh admin CRUD)
      const productsRes = await fetch('/api/products');
      if (productsRes.ok) {
        const productsData = await productsRes.json();
        setProducts(productsData);
      }

      // Load all coupons
      const couponsRes = await fetch('/api/admin/coupons');
      const couponsData = await couponsRes.json();
      if (couponsData.success) {
        setCoupons(couponsData.coupons);
      }

      // Load all banners
      const bannersRes = await fetch('/api/admin/banners');
      const bannersData = await bannersRes.json();
      if (bannersData.success) {
        setBanners(bannersData.banners);
      }

      // Load support messages
      const msgsRes = await fetch('/api/admin/support-messages');
      const msgsData = await msgsRes.json();
      if (msgsData.success) {
        setSupportMessages(msgsData.messages);
      }

      // Load setting parameters
      const settingsRes = await fetch('/api/admin/settings');
      const settingsData = await settingsRes.json();
      if (settingsData.success) {
        setSettings(settingsData.settings);
      }

      // We pull full detailed orders checklist too
      const ordsRes = await fetch('/api/admin/orders');
      const ordsData = await ordsRes.json();
      if (ordsData.success) {
        setOrders(ordsData.orders);
      }

    } catch (err) {
      console.error("Unable to sync admin dashboard data from server", err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        sessionStorage.setItem('admin_token', data.user.token);
        setIsLoggedIn(true);
      } else {
        setAuthError(data.error || "Login verification failed.");
      }
    } catch (err) {
      setAuthError("Network server login offline.");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('admin_token');
    setIsLoggedIn(false);
  };

  // Operation Actions updates triggers
  const handleUpdateOrderStatus = async (orderId: string, status: any) => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAssignTrackingId = async (orderId: string, trackingId: string) => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trackingId })
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleResendNotification = async (orderId: string, channel: 'email' | 'whatsapp' | 'invoice') => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/resend-notifications`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channel })
      });
      if (res.ok) {
        const d = await res.json();
        alert(d.message);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Products CRUD dispatches
  const handleAddProduct = async (productData: any) => {
    try {
      const res = await fetch('/api/admin/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData)
      });
      if (res.ok) {
        loadAllCollections();
        alert("Garment successfully designed and synced!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleEditProduct = async (productId: string, productData: any) => {
    try {
      const res = await fetch(`/api/admin/products/${productId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData)
      });
      if (res.ok) {
        loadAllCollections();
        alert("Specification modification completed!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    try {
      const res = await fetch(`/api/admin/products/${productId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        loadAllCollections();
        alert("Apparel successfully withdrawn.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Coupon CRUD dispatches
  const handleAddCoupon = async (couponData: any) => {
    try {
      const res = await fetch('/api/admin/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(couponData)
      });
      if (res.ok) {
        loadAllCollections();
        alert("Promo Coupon loaded!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateCoupon = async (couponId: string, couponData: any) => {
    try {
      const res = await fetch(`/api/admin/coupons/${couponId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(couponData)
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteCoupon = async (couponId: string) => {
    try {
      const res = await fetch(`/api/admin/coupons/${couponId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Banner CRUD dispatches
  const handleAddBanner = async (bannerData: any) => {
    try {
      const res = await fetch('/api/admin/banners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bannerData)
      });
      if (res.ok) {
        loadAllCollections();
        alert("Front-page flyer loaded successfully!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateBanner = async (bannerId: string, bannerData: any) => {
    try {
      const res = await fetch(`/api/admin/banners/${bannerId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bannerData)
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteBanner = async (bannerId: string) => {
    try {
      const res = await fetch(`/api/admin/banners/${bannerId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Support dispatches
  const handleReplySupport = async (messageId: string, replyText: string) => {
    try {
      const res = await fetch(`/api/admin/support-messages/${messageId}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply: replyText })
      });
      if (res.ok) {
        loadAllCollections();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Settings dispatches
  const handleUpdateSettings = async (settingsData: any) => {
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsData)
      });
      if (res.ok) {
        const d = await res.json();
        setSettings(d.settings);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Select Invoice Preview
  const handleSelectInvoice = (orderId: string) => {
    const match = orders.find(o => o.id === orderId);
    if (match) {
      setSelectedInvoiceOrder(match);
    } else {
      alert("Selected cargo order details reside in archived listings.");
    }
  };

  // Render Login flow if session authorization is not logged in yet
  if (!isLoggedIn) {
    return (
      <div id="admin-login-screen" className="min-h-screen bg-stone-950 flex flex-col items-center justify-center p-6 selection:bg-amber-500 selection:text-stone-900">
        <div className="w-full max-w-md bg-stone-900 border border-stone-800 p-8 rounded-2xl shadow-2xl relative space-y-6">
          
          {/* Top Design aesthetics */}
          <div className="text-center space-y-2">
            <span className="text-xs font-semibold font-mono uppercase tracking-widest text-amber-500">
              Gateway Authority
            </span>
            <h2 className="text-2xl font-serif tracking-tight font-bold text-white uppercase">
              Ziva Systems Root
            </h2>
            <p className="text-stone-450 text-xs text-stone-400 font-mono">
              Use code <strong className="text-amber-500">admin</strong> / <strong className="text-amber-500">admin</strong> for direct terminal access
            </p>
          </div>

          {/* Form */}
          <form id="admin-login-form" onSubmit={handleLogin} className="space-y-4">
            {authError && (
              <div id="login-error" className="p-3 bg-rose-950/45 border border-rose-900/30 text-rose-300 rounded-lg text-xs flex items-center gap-2">
                <AlertCircle className="h-4.5 w-4.5 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase tracking-wider text-stone-500 font-mono block">
                Systems Username ID
              </label>
              <input
                id="login-username"
                type="text"
                required
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. admin"
                className="w-full bg-stone-950 text-white px-3.5 py-2 border border-stone-800 rounded-lg text-xs font-mono focus:border-amber-500 focus:outline-none transition-colors placeholder:text-stone-600"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase tracking-wider text-stone-500 font-mono block">
                Security Passkey
              </label>
              <input
                id="login-password"
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-stone-950 text-white px-3.5 py-2 border border-stone-800 rounded-lg text-xs font-mono focus:border-amber-500 focus:outline-none transition-colors placeholder:text-stone-600"
              />
            </div>

            <button
              id="login-submit-btn"
              type="submit"
              disabled={authLoading}
              className="w-full py-2.5 bg-amber-500 text-stone-950 font-bold hover:bg-amber-450 transition-colors rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
            >
              <KeyRound className="h-4 w-4" />
              <span>Verify credentials</span>
            </button>
          </form>

          {/* Escape pathway */}
          <div className="border-t border-stone-850 pt-4 text-center">
            <button
              id="login-escape-btn"
              onClick={onBackToStore}
              className="text-stone-500 hover:text-stone-300 transition text-xs font-mono"
            >
              ← Cancel & return to Boutique store
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Loaded views switch renderer
  const renderTabContent = () => {
    if (selectedInvoiceOrder) {
      return (
        <InvoicePreview 
          order={selectedInvoiceOrder} 
          onClose={() => setSelectedInvoiceOrder(null)} 
        />
      );
    }

    if (loading) {
      return (
        <div className="flex flex-col items-center justify-center py-24 space-y-4">
          <RotateCw className="h-8 w-8 text-amber-500 animate-spin" />
          <span className="text-xs font-mono text-stone-400">Syncing database registries...</span>
        </div>
      );
    }

    switch(activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            stats={stats || { 
              totalOrders: orders.length, 
              totalRevenue: orders.reduce((sum, o) => sum + o.total, 0), 
              totalCustomers: 12, 
              pendingOrders: 3, 
              shippedOrders: 1, 
              deliveredOrders: 8, 
              cancelledOrders: 0, 
              lowStockCount: 1,
              salesChart: [
                { name: 'Jan', sales: 12000, orders: 4 },
                { name: 'Feb', sales: 18000, orders: 6 },
                { name: 'Mar', sales: 25000, orders: 12 }
              ],
              couponStats: [],
              topProducts: []
            }}
            recentOrders={orders.slice(0, 5)}
            recentCustomers={[]}
            onNavigateTab={setActiveTab}
            onSelectOrderInvoice={handleSelectInvoice}
          />
        );
      case 'orders':
        return (
          <OrdersTable
            orders={orders}
            onUpdateStatus={handleUpdateOrderStatus}
            onAssignTracking={handleAssignTrackingId}
            onResendNotification={handleResendNotification}
            onSelectOrderInvoice={handleSelectInvoice}
          />
        );
      case 'products':
        return (
          <ProductsTable
            products={products}
            onAddProduct={handleAddProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        );
      case 'customers':
        // compute dynamic customers summary lists from database records
        const dynamicCusts = Object.values(orders.reduce((acc, currentO) => {
          const key = currentO.address.phone;
          if (!acc[key]) {
            acc[key] = {
              id: `cust-${key.slice(-4) || 'user'}`,
              fullName: currentO.address.fullName,
              phone: currentO.address.phone,
              email: currentO.address.email || "Guest User",
              totalSpent: 0,
              ordersCount: 0,
              lastOrderDate: currentO.date
            };
          }
          acc[key].totalSpent += currentO.status !== 'cancelled' ? currentO.total : 0;
          acc[key].ordersCount += 1;
          return acc;
        }, {} as Record<string, any>));

        return (
          <CustomersTable 
            customers={dynamicCusts as any[]}
          />
        );
      case 'coupons':
        return (
          <CouponForm
            coupons={coupons}
            onAddCoupon={handleAddCoupon}
            onUpdateCoupon={handleUpdateCoupon}
            onDeleteCoupon={handleDeleteCoupon}
          />
        );
      case 'banners':
        return (
          <BannerManager
            banners={banners}
            onAddBanner={handleAddBanner}
            onUpdateBanner={handleUpdateBanner}
            onDeleteBanner={handleDeleteBanner}
          />
        );
      case 'invoices':
        return (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-xl border border-stone-200">
              <span className="text-xs uppercase font-bold tracking-widest text-stone-500 font-mono">
                Invoice Lookup Registry reprep
              </span>
              <p className="text-[11px] text-stone-400 mt-1 max-w-xl">
                Select any processing order below to display and reprint the associated unified GST Tax Invoice:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {orders.map((ord) => (
                <div 
                  key={ord.id} 
                  onClick={() => handleSelectInvoice(ord.id)}
                  className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs hover:border-amber-500 cursor-pointer transition flex items-center justify-between"
                >
                  <div>
                    <div className="font-mono text-xs font-bold text-stone-900">{ord.id}</div>
                    <div className="text-[10px] text-stone-500 font-medium mt-1">{ord.address.fullName}</div>
                    <div className="text-[9px] text-stone-400 font-mono mt-0.5">{new Date(ord.date).toLocaleDateString()}</div>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-xs font-mono text-stone-900 block">₹{ord.total}</span>
                    <span className="text-[10px] text-amber-600 font-semibold block uppercase">Print →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'support':
        return (
          <SupportManager
            messages={supportMessages}
            onReply={handleReplySupport}
          />
        );
      case 'settings':
        return (
          <StoreSettings
            settings={settings || { taxRate: 5, freeDeliveryThreshold: 699, shopOpen: true, statusMessage: '' }}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      default:
        return (
          <div className="text-center py-12 text-xs font-mono text-stone-400">
            Feature in construction.
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-stone-100 flex h-screen text-stone-900 selection:bg-amber-500 selection:text-stone-900">
      
      {/* Dynamic Sidebar navigation layouts */}
      <Sidebar 
        activeTab={selectedInvoiceOrder ? 'invoices' : activeTab} 
        setActiveTab={(tab) => {
          setSelectedInvoiceOrder(null);
          setActiveTab(tab);
        }} 
        onLogout={handleLogout} 
      />

      {/* Main viewport */}
      <div className="flex-1 flex flex-col overflow-hidden h-full">
        {/* Dynamic top bar utilities */}
        <Topbar 
          title={selectedInvoiceOrder ? `Reprint / Export Tax Invoice` : activeTab.slice(0, 1).toUpperCase() + activeTab.slice(1).replace(/_/g, ' ') + " Registry"} 
          adminName="Boutique Root Admin" 
          onRefresh={loadAllCollections}
        />

        {/* Scaled Scrollable Area */}
        <main className="flex-grow p-8 overflow-y-auto bg-stone-50/50">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
}
