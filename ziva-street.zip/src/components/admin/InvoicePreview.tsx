import React from 'react';
import { FileText, Printer, ArrowLeft, Download, ShieldCheck, Mail, Phone, Calendar } from 'lucide-react';
import { Order } from '../../types';

interface InvoicePreviewProps {
  order: Order;
  onClose: () => void;
}

export default function InvoicePreview({ order, onClose }: InvoicePreviewProps) {
  const taxRate = 5; // 5% GST for garments in server.ts
  const taxAmount = Math.round((order.subtotal - (order.discount || 0)) * (taxRate / 100));
  const basePriceBeforeTax = Math.round((order.subtotal - (order.discount || 0)) - taxAmount);

  return (
    <div id="invoice-preview-panel" className="bg-white p-6 rounded-xl border border-stone-250 shadow-md space-y-6 max-w-3xl mx-auto">
      {/* Upper toolbar */}
      <div className="flex items-center justify-between border-b border-stone-150 pb-4 no-print flex-col sm:flex-row gap-3">
        <button
          id="invoice-back-btn"
          onClick={onClose}
          className="flex items-center gap-1.5 text-stone-500 hover:text-stone-900 font-medium text-xs cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Exit Invoice View</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            id="invoice-print-utility"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 text-stone-50 hover:bg-stone-800 text-xs font-bold rounded transition cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print tax receipt (PDF)</span>
          </button>
        </div>
      </div>

      {/* Actual Physical Invoice Layout */}
      <div id="physical-invoice-sheet" className="p-8 border border-stone-200 shadow-xs bg-white text-stone-900 font-sans text-xs space-y-6">
        {/* Header Block: Brand vs metadata */}
        <div className="flex justify-between items-start border-b border-stone-150 pb-6">
          <div className="space-y-1">
            <span className="text-xl font-serif font-bold tracking-tighter text-stone-950 uppercase">
              Ziva Street
            </span>
            <div className="text-[10px] text-stone-500 font-mono space-y-0.5 leading-relaxed">
              <div>ZIVA STREET COUTURE PVT. LTD.</div>
              <div>B-24, Ground Floor, Okhla Industrial Area, Phase-III</div>
              <div>New Delhi - 110020, India</div>
              <div>GSTIN ID: 07AAPCZ4501R1ZX</div>
              <div>Support: operations@zivastreet.com</div>
            </div>
          </div>

          <div className="text-right space-y-2">
            <span className="px-2.5 py-0.5 bg-stone-950 text-amber-500 text-[10px] font-mono font-bold tracking-wide uppercase rounded">
              Tax Invoice Receipts
            </span>
            <div className="text-[10px] text-stone-500 font-mono space-y-0.5 leading-normal">
              <div><strong className="text-stone-800">Invoice No:</strong> ZS-INV-{(order.id || "00").replace(/[^0-9]/g, "").slice(0, 6) || "42851"}</div>
              <div><strong className="text-stone-800">Date:</strong> {new Date(order.date).toLocaleDateString("en-IN")}</div>
              <div><strong className="text-stone-805">Gateway Ref:</strong> ORDER-{order.id}</div>
              <div><strong className="text-stone-805">Transit Code:</strong> Delhivery Priority Air</div>
            </div>
          </div>
        </div>

        {/* Consignee Billing & Shipping Block */}
        <div className="grid grid-cols-2 gap-8 border-b border-stone-150 pb-6 leading-relaxed">
          <div>
            <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">
              Buyer / Consignee Details:
            </h4>
            <div className="font-bold text-stone-900">{order.address.fullName}</div>
            <div className="text-stone-605 mt-1 font-mono">
              <div>+91 {order.address.phone}</div>
              <div>{order.address.email || "Guest Shopping Session"}</div>
            </div>
          </div>

          <div>
            <h4 className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-2">
              Shipping Destination:
            </h4>
            <div className="text-stone-701 font-mono">
              <div>{order.address.streetAddress}</div>
              <div>{order.address.city}, {order.address.state}</div>
              <div>India - {order.address.pinCode}</div>
              <div className="mt-1 font-sans text-stone-500"><strong className="text-stone-705">Logistics AWB:</strong> {order.trackingId || "Unassigned"}</div>
            </div>
          </div>
        </div>

        {/* Line Items Table */}
        <div className="space-y-4">
          <table className="w-full text-left font-mono border-collapse">
            <thead>
              <tr className="border-b border-stone-200 text-[10px] font-bold text-stone-400 uppercase tracking-wider">
                <th className="py-2.5">Item Description</th>
                <th className="py-2.5 text-center">Size</th>
                <th className="py-2.5 text-right">Unit Price</th>
                <th className="py-2.5 text-center">Qty</th>
                <th className="py-2.5 text-right">Amnt (INR)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {order.items.map((item, idx) => (
                <tr key={idx} className="text-stone-800">
                  <td className="py-3">
                    <div className="font-sans font-bold text-stone-905">{item.product?.name}</div>
                    <div className="text-[9px] text-stone-400 uppercase mt-0.5 mt-1">HSN Apparel Code: 61091000</div>
                  </td>
                  <td className="py-3 text-center text-xs font-bold">{item.selectedSize}</td>
                  <td className="py-3 text-right">₹{(item.product?.price ?? 0).toLocaleString('en-IN')}.00</td>
                  <td className="py-3 text-center">{item.quantity}</td>
                  <td className="py-3 text-right font-bold">₹{((item.product?.price ?? 0) * item.quantity).toLocaleString('en-IN')}.00</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Deductions, Taxes, Total block */}
        <div className="border-t border-stone-200 pt-4 flex justify-between items-start">
          <div className="w-1/2 p-4 border border-stone-150 rounded text-[10px] text-stone-500 leading-normal space-y-1 font-mono">
            <div><strong className="text-stone-800">GST Declaration:</strong> Includes 5% Combined IGST for luxury apparel fabrications.</div>
            <div><strong className="text-stone-800">Return Window:</strong> Handcrafted collections qualify for 7-day hassle-free reverse dispatches. Keep this copy intact.</div>
            <div className="flex items-center gap-1 text-emerald-700 font-semibold mt-1.5">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Ziva Authenticated System Receipt</span>
            </div>
          </div>

          <div className="w-5/12 text-right font-mono space-y-1.5 text-stone-605">
            <div className="flex justify-between">
              <span>Gross Total Subtotal:</span>
              <span>₹{order.subtotal.toLocaleString('en-IN')}.00</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-rose-600 font-bold">
                <span>Coupon ({order.couponCode || 'DADU'}):</span>
                <span>-₹{order.discount.toLocaleString('en-IN')}.00</span>
              </div>
            )}
            <div className="flex justify-between text-stone-450">
              <span>Tax Base Value:</span>
              <span>₹{basePriceBeforeTax.toLocaleString('en-IN')}.00</span>
            </div>
            <div className="flex justify-between text-stone-450">
              <span>Integrated IGST (5%):</span>
              <span>₹{taxAmount.toLocaleString('en-IN')}.00</span>
            </div>
            <div className="flex justify-between">
              <span>Express Delivery charges:</span>
              <span>{order.shipping === 0 ? "₹0.00 (FREE)" : `₹${order.shipping}.00`}</span>
            </div>
            <div className="flex justify-between text-stone-900 border-t border-stone-200 pt-2 font-sans font-bold text-sm">
              <span>Final Paid Total:</span>
              <span>₹{order.total.toLocaleString("en-IN")}.00</span>
            </div>
          </div>
        </div>

        {/* Closing Thank you footnote */}
        <div className="text-center pt-8 border-t border-stone-150 text-[10px] text-stone-400 italic">
          "This is a digital certified electronic tax invoice representing Ziva Street. Handloomed with absolute respect."
        </div>
      </div>
    </div>
  );
}
