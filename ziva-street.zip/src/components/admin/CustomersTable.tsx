import React, { useState } from 'react';
import { Search, Mail, Phone, Calendar, ShoppingBag, DollarSign, Award, Tag } from 'lucide-react';

interface CustomerSummary {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  totalSpent: number;
  ordersCount: number;
  lastOrderDate: string;
}

interface CustomersTableProps {
  customers: CustomerSummary[];
}

export default function CustomersTable({ customers }: CustomersTableProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCustomers = customers.filter(c => {
    return (
      c.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div id="customers-mgr-main" className="space-y-4">
      {/* Search Toolbar */}
      <div className="flex bg-white p-4 rounded-xl border border-stone-200 shadow-xs">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-stone-400" />
          <input
            id="customers-search-input"
            type="text"
            placeholder="Search CRM by customer name, phone prefix, mail..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-stone-200 rounded-lg text-sm bg-stone-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500/10 placeholder-stone-400 transition-colors"
          />
        </div>
      </div>

      {/* CRM Customer List Grid */}
      <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table id="admin-customers-table" className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-stone-50 text-[11px] font-bold text-stone-400 uppercase tracking-widest border-b border-stone-150">
                <th className="py-4 px-6">Customer Profile</th>
                <th className="py-4 px-6">Channels</th>
                <th className="py-4 px-6 text-center">Fulfillment Orders</th>
                <th className="py-4 px-6 text-right font-serif">Lifetime Spent</th>
                <th className="py-4 px-6 text-center">Status Badge</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-150">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-stone-400 text-sm font-mono">
                    No customers found mapping search criteria.
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => {
                  const spendGrade = cust.totalSpent > 10000 ? 'Luxe Core' : cust.totalSpent > 3000 ? 'Regular' : 'New';
                  return (
                    <tr key={cust.id} className="hover:bg-stone-50/50 transition-colors group">
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="h-9 w-9 bg-stone-100 border border-stone-200 text-stone-700 font-serif font-bold text-sm tracking-tight rounded-full flex items-center justify-center">
                            {cust.fullName.slice(0, 1).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-stone-900 group-hover:text-amber-600 transition-colors">
                              {cust.fullName}
                            </div>
                            <div className="text-[10px] text-stone-405 text-stone-400 font-mono mt-0.5">
                              ID: {cust.id} • Joined: {cust.lastOrderDate !== "N/A" ? new Date(cust.lastOrderDate).toLocaleDateString() : "N/A"}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6 font-mono text-[11px] text-stone-605">
                        <div className="flex items-center gap-1 text-stone-800 font-bold">
                          <Phone className="h-3 w-3 text-stone-400" />
                          <span>+91 {cust.phone}</span>
                        </div>
                        <div className="flex items-center gap-1 text-stone-500 mt-1">
                          <Mail className="h-3 w-3 text-stone-400" />
                          <span>{cust.email || "Guest checkout"}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6 text-center">
                        <div className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-stone-50 border border-stone-150 rounded-full text-xs font-bold text-stone-700">
                          <ShoppingBag className="h-3 w-3 text-stone-400" />
                          <span>{cust.ordersCount}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6 text-right font-serif text-sm font-bold text-stone-900">
                        ₹{cust.totalSpent.toLocaleString('en-IN')}
                      </td>
                      <td className="py-4 px-6 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 border rounded text-[9px] font-bold uppercase tracking-wider ${
                          spendGrade === 'Luxe Core'
                            ? 'bg-amber-50 border-amber-250 text-amber-700'
                            : spendGrade === 'Regular'
                              ? 'bg-stone-50 border-stone-250 text-stone-750'
                              : 'bg-stone-50 border-stone-150 text-stone-500'
                        }`}>
                          <Award className="h-3 w-3" />
                          <span>{spendGrade}</span>
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
