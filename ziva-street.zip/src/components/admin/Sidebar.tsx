import React from 'react';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Tag, 
  Users, 
  Image, 
  FileText, 
  MessageSquare, 
  Settings, 
  LogOut, 
  ArrowLeft,
  ChevronRight,
  TrendingUp,
  Sliders
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}

export default function Sidebar({ activeTab, setActiveTab, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'products', label: 'Products', icon: Sliders },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'coupons', label: 'Coupons', icon: Tag },
    { id: 'banners', label: 'Banners', icon: Image },
    { id: 'invoices', label: 'Invoices', icon: FileText },
    { id: 'support', label: 'Support Inquiries', icon: MessageSquare },
    { id: 'settings', label: 'Store Settings', icon: Settings },
  ];

  return (
    <aside id="admin-sidebar" className="w-64 bg-stone-900 border-r border-stone-800 text-stone-100 flex flex-col h-full shrink-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-stone-850 flex items-center justify-between">
        <div className="flex flex-col">
          <span className="text-xs uppercase tracking-widest text-stone-500 font-semibold">Atelier Admin</span>
          <span className="text-lg font-serif font-bold tracking-tight text-amber-500">ZIVA STREET</span>
        </div>
        <span className="bg-amber-500/10 text-amber-500 text-[10px] font-mono px-2 py-0.5 rounded border border-amber-500/20">
          PRO
        </span>
      </div>

      {/* Nav Link Items */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`sidebar-link-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                isActive 
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-md shadow-amber-500/10' 
                  : 'text-stone-400 hover:bg-stone-850 hover:text-stone-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className="h-4.5 w-4.5" />
                <span>{item.label}</span>
              </div>
              <ChevronRight className={`h-3.5 w-3.5 opacity-60 transition-transform duration-200 ${
                isActive ? 'translate-x-0.5 rotate-90 text-stone-950' : 'group-hover:translate-x-0.5'
              }`} />
            </button>
          );
        })}
      </nav>

      {/* Footer Area with Back to Store & Logout */}
      <div className="p-4 border-t border-stone-850 space-y-2">
        <button
          id="sidebar-back-to-store"
          onClick={() => {
            window.location.href = '/';
          }}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-stone-400 hover:bg-stone-850 hover:text-stone-250 transition-colors cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Exit to Main Boutique</span>
        </button>

        <button
          id="sidebar-logout"
          onClick={onLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-stone-500 hover:bg-rose-950/20 hover:text-rose-450 transition-colors cursor-pointer"
        >
          <LogOut className="h-4 w-4 text-stone-500" />
          <span>Log Out Session</span>
        </button>
      </div>
    </aside>
  );
}
