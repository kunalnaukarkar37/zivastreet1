import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  id: string;
  title: string;
  value: string | number;
  icon: LucideIcon;
  subtext?: string;
  trend?: {
    type: 'up' | 'down' | 'neutral';
    value: string;
  };
  colorClass?: string;
}

export default function StatCard({ id, title, value, icon: Icon, subtext, trend, colorClass = "text-stone-900" }: StatCardProps) {
  return (
    <div id={`stat-card-${id}`} className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm flex items-start justify-between transition-transform duration-200 hover:translate-y-[-2px]">
      <div className="space-y-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-stone-400">
          {title}
        </span>
        <div className="flex items-baseline gap-2">
          <span className={`text-2xl font-bold font-serif ${colorClass}`}>
            {value}
          </span>
          {trend && (
            <span className={`text-xs px-1.5 py-0.5 rounded font-mono font-medium ${
              trend.type === 'up' 
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                : trend.type === 'down' 
                  ? 'bg-rose-50 text-rose-700 border border-rose-100' 
                  : 'bg-stone-50 text-stone-600 border border-stone-150'
            }`}>
              {trend.value}
            </span>
          )}
        </div>
        {subtext && (
          <p className="text-[11px] text-stone-500 font-mono">
            {subtext}
          </p>
        )}
      </div>

      <div className="h-10 w-10 bg-stone-50 text-stone-700 rounded-lg flex items-center justify-center border border-stone-100 group-hover:bg-amber-100 transition-colors">
        <Icon className="h-5 w-5 opacity-80" />
      </div>
    </div>
  );
}
