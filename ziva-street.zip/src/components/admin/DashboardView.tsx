import React from 'react';
import { 
  Users, 
  ShoppingBag, 
  DollarSign, 
  AlertTriangle, 
  ArrowRight, 
  Clock, 
  ChevronRight,
  TrendingUp,
  PackageCheck,
  CheckCircle,
  TrendingDown,
  Percent
} from 'lucide-react';
import StatCard from './StatCard';
import { Order } from '../../types';

interface DashboardViewProps {
  stats: {
    totalOrders: number;
    totalRevenue: number;
    totalCustomers: number;
    pendingOrders: number;
    shippedOrders: number;
    deliveredOrders: number;
    cancelledOrders: number;
    lowStockCount: number;
    salesChart: any[];
    couponStats: any[];
    topProducts: any[];
  };
  recentOrders: Order[];
  recentCustomers: any[];
  onNavigateTab: (tab: string) => void;
  onSelectOrderInvoice: (orderId: string) => void;
}

export default function DashboardView({ 
  stats, 
  recentOrders, 
  recentCustomers, 
  onNavigateTab,
  onSelectOrderInvoice
}: DashboardViewProps) {
  
  // Custom interactive layout elements
  const chartMax = Math.max(...stats.salesChart.map(s => s.sales), 10000);
  const chartPoints = stats.salesChart.map((s, idx) => {
    const x = 50 + (idx * 160);
    // invert coordinate space for SVG container height (max 220, margins 20)
    const y = 200 - ((s.sales / chartMax) * 150);
    return { x, y, name: s.name, sales: s.sales, count: s.orders };
  });

  const svgPathStr = chartPoints.reduce((path, p, idx) => {
    return path + `${idx === 0 ? 'M' : 'L'} ${p.x} ${p.y}`;
  }, '');

  const svgAreaStr = svgPathStr + ` L ${chartPoints[chartPoints.length - 1].x} 220 L ${chartPoints[0].x} 220 Z`;

  return (
    <div id="dashboard-view-main" className="space-y-6">
      
      {/* Metrics Row Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          id="sales"
          title="Consolidated Net Revenue"
          value={`₹${stats.totalRevenue.toLocaleString('en-IN')}`}
          icon={DollarSign}
          subtext="Cleared & processing orders"
          trend={{ type: 'up', value: '+24.5%' }}
          colorClass="text-stone-905 text-stone-950 font-bold"
        />

        <StatCard
          id="orders"
          title="Fulfillment Shipments"
          value={stats.totalOrders}
          icon={ShoppingBag}
          subtext={`${stats.pendingOrders} pending dispatches`}
          trend={{ type: 'up', value: '+12%' }}
        />

        <StatCard
          id="customers"
          title="Consignee Master Profiles"
          value={stats.totalCustomers}
          icon={Users}
          subtext="Unique email/phone targets"
          trend={{ type: 'neutral', value: 'Steady' }}
        />

        <StatCard
          id="stock"
          title="Low Stock Warning Threshold"
          value={stats.lowStockCount}
          icon={AlertTriangle}
          subtext="Items below 5 stock counts"
          trend={{ type: stats.lowStockCount > 2 ? 'down' : 'neutral', value: `${stats.lowStockCount} alerts` }}
          colorClass={stats.lowStockCount > 2 ? "text-amber-600" : "text-stone-900"}
        />
      </div>

      {/* Main Charts & Analytics Block */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sales Chart Box - Span 2 */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-stone-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-stone-150 pb-4 mb-4">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-stone-500 font-mono">
                Atelier Revenue Flow Diagram
              </h3>
              <p className="text-[11px] text-stone-400 mt-1">
                Visualizing cumulative store receipts throughout current checkout cycles.
              </p>
            </div>
            
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded border border-emerald-110">
              <TrendingUp className="h-4 w-4" />
              <span>₹{stats.totalRevenue.toLocaleString('en-IN')} Cap</span>
            </div>
          </div>

          {/* SVG Line/Area chart drawing */}
          <div className="relative h-60 w-full pt-2">
            <svg viewBox="0 0 900 240" className="w-full h-full text-stone-700 overflow-visible font-mono">
              {/* Grid Horizontal Guidelines */}
              <line x1="40" y1="50" x2="880" y2="50" stroke="#f1f1eb" strokeWidth="1" strokeDasharray="3,3" />
              <line x1="40" y1="125" x2="880" y2="125" stroke="#f1f1eb" strokeWidth="1" strokeDasharray="3,3" />
              <line x1="40" y1="200" x2="880" y2="200" stroke="#ebebe6" strokeWidth="1" />

              {/* Shaded Area fill */}
              {chartPoints.length > 0 && (
                <>
                  <path d={svgAreaStr} fill="rgba(245, 158, 11, 0.08)" />
                  <path d={svgPathStr} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                </>
              )}

              {/* Circles & Labels */}
              {chartPoints.map((pt, i) => (
                <g key={i} className="group cursor-pointer">
                  <circle cx={pt.x} cy={pt.y} r="5" fill="#ffffff" stroke="#f59e0b" strokeWidth="2.5" />
                  <circle cx={pt.x} cy={pt.y} r="9" className="opacity-0 hover:opacity-15" fill="#f59e0b" />
                  
                  {/* Tooltip text showing sales */}
                  <text x={pt.x} y={pt.y - 12} textAnchor="middle" className="text-[9px] font-bold font-sans fill-stone-800 opacity-60 hover:opacity-100 transition-opacity">
                    ₹{Math.round(pt.sales/1000)}k
                  </text>

                  {/* Horizontal Axis label */}
                  <text x={pt.x} y="222" textAnchor="middle" className="text-[10px] font-semibold fill-stone-400">
                    {pt.name}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>

        {/* Coupon stats and Campaign summary - Span 1 */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-sm space-y-4">
          <div className="border-b border-stone-150 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-widest text-stone-500 font-mono">
              Campaign Coupon Redemptions
            </h3>
            <p className="text-[10px] text-stone-400 mt-1 leading-none">
              Inward tracking counts per active checkout promo voucher.
            </p>
          </div>

          <div className="space-y-3 pt-1">
            {stats.couponStats.map((c, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs border border-stone-100 p-2.5 rounded-lg bg-stone-50/50 hover:bg-stone-50 transition border-stone-150">
                <div className="flex items-center gap-2">
                  <Percent className="h-4 w-4 text-amber-500 shrink-0" />
                  <div>
                    <span className="font-mono font-bold text-xs bg-stone-200 text-stone-850 px-1.5 py-0.5 rounded leading-normal">
                      {c.code}
                    </span>
                    <span className="text-[10px] text-stone-400 ml-2 font-semibold">
                      ({c.discount}% DEDUCT)
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-bold text-stone-900 font-mono">
                    {c.useCount} times
                  </span>
                  <p className="text-[9px] text-stone-400 font-semibold uppercase leading-none">Used</p>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Stats breakdowns */}
          <div className="pt-2">
            <div className="p-3 border border-stone-200 rounded-lg text-xs leading-relaxed space-y-2.5 bg-stone-50/30">
              <strong className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block font-mono">
                Active Order pipeline ratio:
              </strong>
              <div className="grid grid-cols-2 gap-2 text-[10px] font-mono pl-1 text-stone-600">
                <div className="flex items-center gap-1.5"><div className="h-2 w-2 rounded-full bg-blue-500"></div><span>Ordered: {stats.pendingOrders}</span></div>
                <div className="flex items-center gap-1.5"><div className="h-2 w-2 rounded-full bg-indigo-500"></div><span>Carrier: {stats.shippedOrders}</span></div>
                <div className="flex items-center gap-1.5"><div className="h-2 w-2 rounded-full bg-emerald-500"></div><span>Completed: {stats.deliveredOrders}</span></div>
                <div className="flex items-center gap-1.5"><div className="h-2 w-2 rounded-full bg-stone-400"></div><span>Recalled: {stats.cancelledOrders}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Recent Orders vs Top Selling Apparel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Recent orders ledger - Span 2 */}
        <div className="xl:col-span-2 bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm flex flex-col justify-between">
          <div>
            <div className="p-4 bg-stone-50 border-b border-stone-150 flex items-center justify-between">
              <span className="text-xs uppercase font-bold tracking-widest text-stone-500 font-mono">
                Recent Outward Shipments
              </span>
              <button 
                id="dash-view-all-orders"
                onClick={() => onNavigateTab('orders')}
                className="text-[11px] font-semibold text-amber-600 hover:text-amber-800 flex items-center gap-0.5 cursor-pointer"
              >
                <span>Full Ledger</span>
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table id="dash-recent-orders-table" className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-stone-50/25 text-[10px] font-bold text-stone-400 uppercase tracking-widest border-b border-stone-150">
                    <th className="py-3 px-5">Order Reference</th>
                    <th className="py-3 px-5">Buyer</th>
                    <th className="py-3 px-5 text-right">Spent Total</th>
                    <th className="py-3 px-5 uppercase text-center">Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {recentOrders.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="text-center py-6 text-stone-400 font-mono text-xs">
                        No orders registered yet. Checkout some garments beta!
                      </td>
                    </tr>
                  ) : (
                    recentOrders.map((ord) => (
                      <tr key={ord.id} className="hover:bg-stone-50/50 transition">
                        <td className="py-3 px-5 font-mono text-[11px] font-semibold text-stone-900">
                          {ord.id}
                        </td>
                        <td className="py-3 px-5 font-bold text-stone-905">
                          {ord.address.fullName}
                        </td>
                        <td className="py-3 px-5 text-right font-serif font-bold text-stone-900">
                          ₹{ord.total.toLocaleString('en-IN')}
                        </td>
                        <td className="py-3 px-5 text-center">
                          <button
                            id={`dash-invoice-${ord.id}`}
                            onClick={() => onSelectOrderInvoice(ord.id)}
                            className="p-1 text-stone-600 hover:text-amber-600 hover:bg-stone-100 rounded cursor-pointer leading-none"
                            title="Print Tax invoice receipt"
                          >
                            Receipt
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Top Product Leaderboards - Span 1 */}
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
          <div className="p-4 bg-stone-50 border-b border-stone-150">
            <span className="text-xs uppercase font-bold tracking-widest text-stone-500 font-mono">
              Boutique Sales Leaders
            </span>
          </div>

          <div className="p-4 divide-y divide-stone-100 space-y-3.5">
            {stats.topProducts.map((prod, idx) => (
              <div key={idx} className="flex justify-between items-center pt-3.5 first:pt-0 gap-3">
                <div className="flex items-center gap-3">
                  <img 
                    src={prod.image} 
                    alt={prod.name} 
                    className="h-10 w-10 object-cover rounded border border-stone-200" 
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <span className="text-xs font-bold text-stone-900 leading-tight block truncate max-w-[130px]">
                      {prod.name}
                    </span>
                    <span className="text-[9px] text-stone-400 font-mono mt-0.5 uppercase leading-none block">
                      Category: {prod.category}
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className="font-bold text-stone-850 block text-[11px]">
                    ₹{prod.revenueGenerated.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[10px] text-stone-400 uppercase leading-none block font-semibold">
                    {prod.salesCount} sold
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
