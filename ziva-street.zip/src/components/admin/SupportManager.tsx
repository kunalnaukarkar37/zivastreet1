import React, { useState } from 'react';
import { MessageSquare, Mail, Phone, Calendar, Send, CheckCircle2, User, AlertCircle, Bookmark } from 'lucide-react';
import { SupportMessage } from '../../types';

interface SupportManagerProps {
  messages: SupportMessage[];
  onReply: (messageId: string, replyText: string) => void;
}

export default function SupportManager({ messages, onReply }: SupportManagerProps) {
  const [selectedMessage, setSelectedMessage] = useState<SupportMessage | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMessage || !replyText.trim()) return;

    onReply(selectedMessage.id, replyText);
    setSelectedMessage({
      ...selectedMessage,
      status: 'replied',
      reply: replyText
    });
    setReplyText('');
    alert("Reply sent successfully and email notification dispatched!");
  };

  return (
    <div id="support-mgr-wrapper" className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Support messages list - Span 2 */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-stone-200 overflow-hidden shadow-sm">
          <div className="p-4 bg-stone-50 border-b border-stone-150 flex items-center justify-between">
            <span className="text-xs uppercase font-bold tracking-widest text-stone-500 font-mono">
              Inbound Customer Support Queries
            </span>
            <span className="text-[10px] bg-sky-50 text-sky-700 font-mono font-bold px-2.5 py-0.5 rounded border border-sky-100">
              {messages.filter(m => m.status === 'new').length} UNANSWERED
            </span>
          </div>

          <div className="divide-y divide-stone-150">
            {messages.length === 0 ? (
              <div className="text-center py-12 text-stone-400 text-xs font-mono">
                No support queries currently registered.
              </div>
            ) : (
              messages.map((msg) => (
                <div 
                  key={msg.id} 
                  onClick={() => setSelectedMessage(msg)}
                  className={`p-4 hover:bg-stone-50/50 cursor-pointer transition-colors flex items-start gap-4 ${
                    selectedMessage?.id === msg.id ? 'bg-stone-50/75 border-l-3 border-amber-500 pl-3' : ''
                  }`}
                >
                  <div className={`p-2 rounded-full border shrink-0 ${
                    msg.status === 'new' 
                      ? 'bg-amber-50 border-amber-200 text-amber-600' 
                      : 'bg-stone-105 bg-stone-100 border-stone-200 text-stone-500'
                  }`}>
                    <MessageSquare className="h-4.5 w-4.5" />
                  </div>

                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-stone-900">{msg.name}</span>
                      <span className="text-[9px] font-mono text-stone-400">
                        {new Date(msg.date).toLocaleDateString()}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-stone-800">
                      {msg.subject}
                    </h4>

                    <p className="text-[11px] text-stone-500 max-w-xl line-clamp-2 leading-relaxed">
                      {msg.message}
                    </p>

                    <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-stone-400">
                      <span>+91 {msg.phone}</span>
                      <span className={`font-bold px-1.5 py-0.2 rounded text-[8px] uppercase tracking-wide border ${
                        msg.status === 'new' 
                          ? 'bg-amber-100/40 text-amber-700 border-amber-200' 
                          : 'bg-stone-100 text-stone-500 border-stone-200'
                      }`}>
                        {msg.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Selected message details & reply panel - Span 1 */}
        <div className="bg-white p-5 rounded-xl border border-stone-200 shadow-sm h-fit">
          {selectedMessage ? (
            <div className="space-y-4">
              <div className="border-b border-stone-150 pb-4 mb-2">
                <span className="text-[9px] font-bold tracking-widest text-stone-400 uppercase font-mono block mb-1">
                  Query ID: {selectedMessage.id}
                </span>
                <h3 className="text-sm font-bold text-stone-900">
                  {selectedMessage.subject}
                </h3>
              </div>

              {/* Sender summary */}
              <div className="p-3 bg-stone-50 rounded border border-stone-150 text-xs space-y-1.5 font-mono">
                <div className="flex items-center gap-1.5 font-sans font-bold text-stone-800">
                  <User className="h-3.5 w-3.5 text-stone-400" />
                  <span>{selectedMessage.name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-stone-400 shrink-0" />
                  <span>{selectedMessage.email}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Phone className="h-3.5 w-3.5 text-stone-400 shrink-0" />
                  <span>+91 {selectedMessage.phone}</span>
                </div>
              </div>

              {/* Message block */}
              <div className="space-y-1 bg-stone-50/50 p-3.5 border border-stone-100 rounded-lg">
                <span className="text-[9px] font-bold font-mono tracking-wider text-stone-405 text-stone-400 uppercase block">
                  Original Inbound message:
                </span>
                <p className="text-xs text-stone-700 leading-relaxed font-serif whitespace-pre-wrap">
                  "{selectedMessage.message}"
                </p>
              </div>

              {/* Reply block: finished or pending */}
              {selectedMessage.status === 'replied' ? (
                <div className="space-y-1 bg-emerald-50/40 p-3.5 border border-emerald-100 rounded-lg">
                  <div className="flex items-center gap-1 text-[9px] font-bold tracking-wider text-emerald-800 uppercase font-mono mb-1">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Dispatched System Reply:</span>
                  </div>
                  <p className="text-xs text-stone-700 leading-relaxed font-medium italic">
                    "{selectedMessage.reply}"
                  </p>
                </div>
              ) : (
                <form id="support-reply-form" onSubmit={handleSendReply} className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-stone-55 block">
                      Type Support response
                    </label>
                    <textarea
                      id="form-support-reply"
                      rows={4}
                      required
                      placeholder="e.g. Hello Rohan, we suggest order size XL based on your dimensions. Feel free to connect!"
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      className="w-full px-3 py-1.5 border border-stone-200 rounded text-xs bg-stone-50/50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-stone-400"
                    />
                  </div>

                  <button
                    type="submit"
                    id="support-submit-btn"
                    className="w-full py-2 bg-stone-900 border border-transparent hover:bg-stone-850 text-stone-100 text-xs font-bold rounded flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Send className="h-3 w-3" />
                    <span>Simulate SMTP Email Response</span>
                  </button>
                </form>
              )}
            </div>
          ) : (
            <div className="text-center py-12 bg-stone-50 rounded-lg border border-dashed border-stone-200 text-stone-400">
              <bookmark className="h-6 w-6 mx-auto text-stone-300 mb-2 block" />
              <p className="text-xs">Select any inbound inquiry from the left panel to review & answer.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
