/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, User, MapPin, Package, Search, Clipboard, Check, Clock, Box, Truck, CheckCircle2 } from 'lucide-react';
import { UserProfile, SavedAddress, Order } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateProfile: (updatedUser: UserProfile) => void;
  initialTab?: 'orders' | 'track' | 'address' | 'account';
  onLogout: () => void;
  onViewInvoice?: (orderId: string) => void;
}

export default function ProfileModal({
  isOpen,
  onClose,
  user,
  onUpdateProfile,
  initialTab = 'account',
  onLogout,
  onViewInvoice
}: ProfileModalProps) {
  const [activeTab, setActiveTab] = useState<'orders' | 'track' | 'address' | 'account'>(initialTab);
  
  // Track Order Input search state
  const [typedTrackingId, setTypedTrackingId] = useState<string>('');
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);
  const [trackError, setTrackError] = useState<string>('');
  const [trackLoading, setTrackLoading] = useState<boolean>(false);

  // Address modifier form
  const [addrName, setAddrName] = useState<string>('');
  const [addrPhone, setAddrPhone] = useState<string>('');
  const [addrStreet, setAddrStreet] = useState<string>('');
  const [addrCity, setAddrCity] = useState<string>('');
  const [addrState, setAddrState] = useState<string>('');
  const [addrPin, setAddrPin] = useState<string>('');
  const [addrSuccess, setAddrSuccess] = useState<string>('');

  // Account details modifier form
  const [userName, setUserName] = useState<string>(user.fullName);
  const [userEmail, setUserEmail] = useState<string>(user.email);
  const [userPhone, setUserPhone] = useState<string>(user.phone);
  const [profileSuccess, setProfileSuccess] = useState<string>('');

  // Clipboard copy helper state
  const [copiedId, setCopiedId] = useState<string>('');

  // Track the most recent order by default if available
  useEffect(() => {
    if (activeTab === 'track' && user.orders && user.orders.length > 0 && !trackedOrder) {
      setTypedTrackingId(user.orders[0].trackingId);
      performTrackOrder(user.orders[0].trackingId);
    }
  }, [activeTab, user.orders]);

  // Sync initial tab
  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  if (!isOpen) return null;

  const handleCopy = (txt: string) => {
    navigator.clipboard.writeText(txt);
    setCopiedId(txt);
    setTimeout(() => setCopiedId(''), 1500);
  };

  const performTrackOrder = async (trackingIdToQuery: string) => {
    const query = trackingIdToQuery.trim();
    if (!query) {
      setTrackError('Please enter a valid tracking or order ID.');
      return;
    }

    setTrackLoading(true);
    setTrackError('');
    setTrackedOrder(null);

    try {
      const res = await fetch('/api/orders/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trackingId: query })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setTrackedOrder(data.order);
      } else {
        setTrackError(data.error || 'No shipment record found for that ID.');
      }
    } catch (err) {
      setTrackError('Failed to communicate with courier database.');
    } finally {
      setTrackLoading(false);
    }
  };

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess('');

    try {
      const res = await fetch('/api/auth/profile/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          fullName: userName,
          email: userEmail,
          phone: userPhone
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        onUpdateProfile(data.user);
        setProfileSuccess('Account credentials updated successfully!');
      } else {
        setProfileSuccess('Failed to update account profiles.');
      }
    } catch (err) {
      setProfileSuccess('Network offline during request.');
    }
  };

  const handleAddressAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddrSuccess('');

    if (!addrName || !addrPhone || !addrStreet || !addrCity || !addrState || !addrPin) {
      setAddrSuccess('Please populate all address details beta.');
      return;
    }

    const newAddr: SavedAddress = {
      fullName: addrName,
      phone: addrPhone,
      streetAddress: addrStreet,
      city: addrCity,
      state: addrState,
      pinCode: addrPin
    };

    try {
      const res = await fetch('/api/auth/profile/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          savedAddress: newAddr
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        onUpdateProfile(data.user);
        setAddrSuccess('New address written into Address Book successfully!');
        // clear inputs
        setAddrName('');
        setAddrPhone('');
        setAddrStreet('');
        setAddrCity('');
        setAddrState('');
        setAddrPin('');
      } else {
        setAddrSuccess('Failed to save address.');
      }
    } catch (err) {
      setAddrSuccess('Network check failed.');
    }
  };

  // Helper render stages active styling indices
  // stages: ordered -> packed -> shipped -> out_for_delivery -> delivered
  const stages = [
    { key: 'ordered', title: 'Order Placed', desc: 'Awaiting supplier confirmation' },
    { key: 'packed', title: 'Prepped & Packed', desc: 'Atelier finished & sealed' },
    { key: 'shipped', title: 'Shipped', desc: 'Dispatched with Delhivery Express' },
    { key: 'out_for_delivery', title: 'Out For Delivery', desc: 'Nearing your post-station' },
    { key: 'delivered', title: 'Delivered', desc: 'Aura street drip acquired!' }
  ];

  const getActiveStageIndex = (status: string) => {
    const indicesByStatus: Record<string, number> = {
      ordered: 0,
      packed: 1,
      shipped: 2,
      out_for_delivery: 3,
      delivered: 4
    };
    return indicesByStatus[status] ?? 0;
  };

  return (
    <div id="profile-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8">
      {/* Dark background overlay */}
      <div onClick={onClose} className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity cursor-pointer animate-fade-in" />

      {/* Main Container */}
      <div className="relative w-full max-w-4xl bg-white rounded-none shadow-2xl overflow-hidden border border-stone-200 z-10 flex flex-col md:flex-row h-[90vh] md:h-[75vh]">
        
        {/* Left Side Tab Drawer (Sidebar navigaton) */}
        <div className="w-full md:w-1/4 bg-stone-50 border-b md:border-b-0 md:border-r border-stone-150 p-4 shrink-0 flex flex-col justify-between">
          <div className="space-y-6">
            <div className="px-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-stone-400 block mb-1">MEMBER GATEWAY</span>
              <h2 className="text-sm font-extrabold tracking-wider uppercase text-stone-900 font-display">Ziva Atelier</h2>
            </div>

            <nav className="space-y-1.5">
              <button
                id="tab-account"
                onClick={() => { setActiveTab('account'); setProfileSuccess(''); }}
                className={`w-full text-left px-3.5 py-2.5 text-xs font-semibold uppercase tracking-wider rounded-none flex items-center gap-2.5 cursor-pointer ${
                  activeTab === 'account' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:bg-stone-200/50 hover:text-black'
                }`}
              >
                <User className="h-4 w-4" />
                Account details
              </button>
              <button
                id="tab-address"
                onClick={() => { setActiveTab('address'); setAddrSuccess(''); }}
                className={`w-full text-left px-3.5 py-2.5 text-xs font-semibold uppercase tracking-wider rounded-none flex items-center gap-2.5 cursor-pointer ${
                  activeTab === 'address' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:bg-stone-200/50 hover:text-black'
                }`}
              >
                <MapPin className="h-4 w-4" />
                Address Book
              </button>
              <button
                id="tab-orders"
                onClick={() => setActiveTab('orders')}
                className={`w-full text-left px-3.5 py-2.5 text-xs font-semibold uppercase tracking-wider rounded-none flex items-center gap-2.5 cursor-pointer ${
                  activeTab === 'orders' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:bg-stone-200/50 hover:text-black'
                }`}
              >
                <Package className="h-4 w-4" />
                My Orders
                {user.orders.length > 0 && (
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-none ml-auto ${
                    activeTab === 'orders' ? 'bg-stone-800 text-white' : 'bg-stone-200 text-stone-700'
                  }`}>{user.orders.length}</span>
                )}
              </button>
              <button
                id="tab-track"
                onClick={() => { setActiveTab('track'); setTrackError(''); }}
                className={`w-full text-left px-3.5 py-2.5 text-xs font-semibold uppercase tracking-wider rounded-none flex items-center gap-2.5 cursor-pointer ${
                  activeTab === 'track' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:bg-stone-200/50 hover:text-black'
                }`}
              >
                <Search className="h-4 w-4" />
                Track Order
              </button>
            </nav>
          </div>

          <button
            onClick={onLogout}
            className="w-full text-left px-3.5 py-2.5 text-xs font-bold uppercase tracking-wider rounded-none text-rose-600 hover:bg-rose-50 flex items-center gap-2.5 mt-4 cursor-pointer"
          >
            <X className="h-4 w-4" />
            Logout Account
          </button>
        </div>

        {/* Right Side Panels (Scrollable and dynamic) */}
        <div className="flex-1 p-6 sm:p-8 overflow-y-auto flex flex-col justify-between relative bg-white">
          
          {/* Close trigger button */}
          <button
            id="close-profile-btn"
            onClick={onClose}
            className="absolute top-5 right-5 text-stone-400 hover:text-black hover:bg-stone-100 p-1.5 rounded-none cursor-pointer transition-colors"
          >
            <X className="h-5 w-5" />
          </button>

          {/* TAB 1: EDIT PROFILE ACCOUNT */}
          {activeTab === 'account' && (
            <div className="space-y-6 max-w-lg">
              <div>
                <h3 className="text-lg font-extrabold uppercase text-stone-900 font-display">Account Specifications</h3>
                <p className="text-xs text-stone-500">Edit or check your registration credential parameters stored securely at Ziva database.</p>
              </div>

              <form onSubmit={handleProfileSave} className="space-y-4">
                <div>
                  <label className="text-[10px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Registered Sign-in Core ID</label>
                  <input
                    type="text"
                    disabled
                    value={user.id}
                    className="w-full text-xs p-3 border border-stone-200 bg-stone-100 text-stone-500 select-all cursor-not-allowed font-mono"
                  />
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Full Representative Name</label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    required
                    className="w-full text-xs p-3 border border-stone-250 bg-stone-50 text-stone-900 font-semibold focus:outline-none focus:ring-1 focus:ring-stone-950"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Contact Phone</label>
                    <input
                      type="text"
                      value={userPhone}
                      onChange={(e) => setUserPhone(e.target.value)}
                      className="w-full text-xs p-3 border border-stone-250 bg-stone-50 text-stone-900 font-semibold focus:outline-none focus:ring-1 focus:ring-stone-950"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold tracking-widest text-stone-500 block mb-1">Email Coordinates</label>
                    <input
                      type="email"
                      value={userEmail}
                      onChange={(e) => setUserEmail(e.target.value)}
                      className="w-full text-xs p-3 border border-stone-250 bg-stone-50 text-stone-900 font-semibold focus:outline-none focus:ring-1 focus:ring-stone-950"
                    />
                  </div>
                </div>

                {profileSuccess && (
                  <p className="text-xs p-3 bg-stone-100 border border-stone-200 text-stone-800 font-semibold text-center">{profileSuccess}</p>
                )}

                <button
                  type="submit"
                  className="px-6 py-3 bg-stone-950 text-white hover:bg-stone-900 text-xs font-bold uppercase tracking-widest transition-colors cursor-pointer"
                >
                  Save Registration Changes
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: ADDRESS BOOK */}
          {activeTab === 'address' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-extrabold uppercase text-stone-900 font-display">Manage saved addresses</h3>
                <p className="text-xs text-stone-500">Provide shipping variables for expedited courier packaging and checkout verification.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Existing addresses container list */}
                <div className="space-y-4">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-stone-400">Address Book (Stored)</h4>
                  {user.addressBook.length === 0 ? (
                    <div className="p-6 border border-dashed border-stone-250 text-center rounded-none">
                      <p className="text-xs text-stone-500">No address variables saved yet, beta. Complete an order to save addresses dynamically or fill on the right.</p>
                    </div>
                  ) : (
                    <div className="space-y-3.5">
                      {user.addressBook.map((addr, idx) => (
                        <div key={idx} className="p-3.5 border border-stone-200 rounded-none relative group bg-stone-50">
                          <span className="absolute top-3.5 right-3.5 p-1 bg-stone-900 text-white rounded-none text-[8px] font-mono font-bold leading-none uppercase">Saved</span>
                          <p className="text-xs font-bold text-stone-950">{addr.fullName}</p>
                          <p className="text-2xs text-stone-500 font-semibold">Contact Phone: +91 {addr.phone}</p>
                          <p className="text-xs text-stone-700 mt-1">{addr.streetAddress}</p>
                          <p className="text-xs text-stone-700">{addr.city}, {addr.state} - <strong className="font-semibold">{addr.pinCode}</strong></p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* New address writing form */}
                <form onSubmit={handleAddressAdd} className="space-y-3.5 p-4 bg-stone-50 border border-stone-100 rounded-none text-left">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-stone-800">Add shipping variables</h4>
                  
                  <div>
                    <input
                      type="text"
                      placeholder="Receiver's Full Name"
                      value={addrName}
                      onChange={(e) => setAddrName(e.target.value)}
                      className="w-full text-xs p-2 border border-stone-200 bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Cell Contact no."
                      value={addrPhone}
                      onChange={(e) => setAddrPhone(e.target.value)}
                      className="w-full text-xs p-2 border border-stone-200 bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Street, Studio or Suite line"
                      value={addrStreet}
                      onChange={(e) => setAddrStreet(e.target.value)}
                      className="w-full text-xs p-2 border border-stone-200 bg-white focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="City"
                      value={addrCity}
                      onChange={(e) => setAddrCity(e.target.value)}
                      className="text-xs p-2 border border-stone-200 bg-white focus:outline-none"
                    />
                    <input
                      type="text"
                      placeholder="State"
                      value={addrState}
                      onChange={(e) => setAddrState(e.target.value)}
                      className="text-xs p-2 border border-stone-200 bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Pincode (e.g. 400050)"
                      value={addrPin}
                      onChange={(e) => setAddrPin(e.target.value)}
                      className="w-full text-xs p-2 border border-stone-200 bg-white focus:outline-none"
                    />
                  </div>

                  {addrSuccess && (
                    <p className="text-[10px] text-amber-700 font-bold bg-white p-2 text-center border">{addrSuccess}</p>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2 bg-stone-900 text-white font-bold text-2xs uppercase tracking-widest hover:bg-stone-950 transition-colors cursor-pointer"
                  >
                    Insert New Address
                  </button>
                </form>

              </div>
            </div>
          )}

          {/* TAB 3: DISPLAY ORDERS LIST */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-extrabold uppercase text-stone-900 font-display">Your order history</h3>
                <p className="text-xs text-stone-500">Monitor tracking milestones, invoices, and payment tags for your ongoing street couture acquisitions.</p>
              </div>

              {user.orders.length === 0 ? (
                <div className="p-10 border border-dashed border-stone-250 text-center rounded-none flex flex-col items-center justify-center space-y-3 bg-stone-50 py-16">
                  <div className="h-10 w-10 text-stone-400">
                    <Package className="h-full w-full" />
                  </div>
                  <p className="text-xs text-stone-500 max-w-xs">No active orders found. Click "Collection" to acquire items with our simulated demo payment!</p>
                </div>
              ) : (
                <div className="space-y-5">
                  {user.orders.map((ord) => (
                    <div key={ord.id} className="border border-stone-150 rounded-none overflow-hidden shadow-sm hover:shadow bg-stone-50">
                      
                      {/* Order head meta info */}
                      <div className="bg-stone-100 flex flex-wrap items-center justify-between px-4 py-3 border-b border-stone-200 text-2xs gap-3">
                        <div className="flex gap-4">
                          <div>
                            <span className="text-stone-400 uppercase tracking-wider font-semibold block">DATE REGISTERED</span>
                            <span className="font-bold text-stone-800">{new Date(ord.date).toLocaleDateString()}</span>
                          </div>
                          <div>
                            <span className="text-stone-400 uppercase tracking-wider font-semibold block">ORDER VALUE</span>
                            <span className="font-bold text-stone-900">₹{ord.total.toLocaleString('en-IN')}</span>
                          </div>
                          <div>
                            <span className="text-stone-400 uppercase tracking-wider font-semibold block">SHIPMENT STATUS</span>
                            <span className="px-2 py-0.5 rounded-none text-[9px] font-bold uppercase tracking-widest bg-emerald-600 text-white">
                              {ord.status === 'out_for_delivery' ? 'out for delivery' : ord.status}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="font-mono text-stone-600">ID: <strong>{ord.id}</strong></span>
                          <button
                            onClick={() => handleCopy(ord.id)}
                            className="bg-white hover:bg-stone-250 p-1 rounded-none text-stone-500 cursor-pointer"
                            title="Copy Order ID"
                          >
                            {copiedId === ord.id ? <Check className="h-3 w-3 text-emerald-600" /> : <Clipboard className="h-3 w-3" />}
                          </button>
                          {onViewInvoice && (
                            <button
                              onClick={() => {
                                onViewInvoice(ord.id);
                                onClose();
                              }}
                              className="bg-stone-900 hover:bg-stone-950 text-white font-extrabold text-[9px] uppercase tracking-widest px-2.5 py-1 shrink-0 rounded-none cursor-pointer flex items-center gap-1"
                              title="Generate & View Invoice"
                            >
                              <span>Tax Invoice</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Items & Address details body */}
                      <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                        <div className="md:col-span-2 space-y-3.5">
                          {ord.items.map((i, itIdx) => (
                            <div key={itIdx} className="flex items-center justify-between border-b pb-2.5 last:border-0 last:pb-0">
                              <div className="flex items-center gap-3">
                                <img src={i.product.image} className="w-10 h-12 object-cover rounded-none shrink-0" referrerPolicy="no-referrer" />
                                <div>
                                  <p className="font-bold text-stone-900">{i.product.name}</p>
                                  <p className="text-[10px] text-stone-400 uppercase font-semibold tracking-wider">Size: {i.selectedSize} | Qty: {i.quantity}</p>
                                </div>
                              </div>
                              <span className="font-bold text-stone-900">₹{(i.product.price * i.quantity).toLocaleString('en-IN')}</span>
                            </div>
                          ))}
                        </div>

                        <div className="bg-white p-3 border border-stone-200/60 rounded-none text-2xs space-y-1">
                          <p className="text-stone-400 font-bold uppercase tracking-wider block">DELIVERY TARGET</p>
                          <p className="font-bold text-stone-950 truncate">{ord.address.fullName}</p>
                          <p className="text-stone-600">{ord.address.streetAddress}</p>
                          <p className="text-stone-600">{ord.address.city}, {ord.address.state} - {ord.address.pinCode}</p>
                          <div className="pt-2 border-t mt-2 flex justify-between items-center bg-amber-50 p-1 border-amber-100">
                            <span className="text-amber-800 font-bold uppercase tracking-wider">Tracking ID:</span>
                            <span className="font-mono font-bold text-stone-850">{ord.trackingId}</span>
                            <button
                              onClick={() => {
                                setTypedTrackingId(ord.trackingId);
                                setActiveTab('track');
                                performTrackOrder(ord.trackingId);
                              }}
                              className="text-amber-900 underline font-extrabold hover:text-amber-950 ml-1.5 cursor-pointer leading-none text-[8px]"
                            >
                              Track Live
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: TRACK ORDER MILIEU */}
          {activeTab === 'track' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-extrabold uppercase text-stone-900 font-display">Live courier shipment tracking</h3>
                <p className="text-xs text-stone-500">Insert your Ziva Street order ID or tracking ID to locate delivery trace details in real-time.</p>
              </div>

              {/* Inquiry Search input block */}
              <div className="flex shadow-sm rounded-none max-w-md">
                <input
                  type="text"
                  placeholder="ZS-TRK-... or ZS-ORD-..."
                  value={typedTrackingId}
                  onChange={(e) => setTypedTrackingId(e.target.value)}
                  className="w-full text-xs px-3.5 py-3 border border-stone-250 focus:outline-none bg-stone-50 text-stone-900 uppercase font-semibold font-mono tracking-wider"
                />
                <button
                  onClick={() => performTrackOrder(typedTrackingId)}
                  disabled={trackLoading}
                  className="px-6 py-3 bg-stone-950 text-white font-extrabold uppercase tracking-widest hover:bg-stone-900 transition-colors cursor-pointer disabled:bg-stone-600 inline-flex items-center gap-1 text-[10px]"
                >
                  {trackLoading ? 'Searching...' : 'Locate'}
                </button>
              </div>

              {trackError && (
                <p className="text-rose-500 font-bold text-xs tracking-wide">{trackError}</p>
              )}

              {/* Live Tracking Trace Timeline Output */}
              {trackedOrder ? (
                <div className="p-4 border border-stone-200 bg-stone-50 rounded-none space-y-6">
                  
                  {/* Meta heading info */}
                  <div className="flex flex-wrap justify-between items-center border-b pb-3 gap-3">
                    <div className="text-2xs space-y-0.5">
                      <p className="text-stone-400 font-semibold uppercase tracking-wider">CONSIGNMENT FOUND</p>
                      <h4 className="font-extrabold text-stone-950 text-sm">Tracking ID: {trackedOrder.trackingId}</h4>
                      <p className="text-stone-500">Linked to Order <strong>{trackedOrder.id}</strong></p>
                    </div>

                    <div className="text-right text-2xs space-y-1">
                      <span className="px-2.5 py-1 bg-stone-900 text-white text-[9px] uppercase font-bold tracking-widest rounded-none">{trackedOrder.status.replace('_', ' ')}</span>
                      <p className="text-stone-400 pt-1">Date: {new Date(trackedOrder.date).toLocaleDateString()}</p>
                    </div>
                  </div>

                  {/* 5-Stage timeline flow */}
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
                    {stages.map((stage, idx) => {
                      const activeIndex = getActiveStageIndex(trackedOrder.status);
                      const isCompleted = idx <= activeIndex;
                      const isCurrent = idx === activeIndex;

                      return (
                        <div key={stage.key} className="flex md:flex-col items-start md:items-center relative gap-3.5 md:gap-2">
                          
                          {/* Circle bullet representation with appropriate icon */}
                          <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 border transition-all z-10 ${
                            isCurrent
                              ? 'bg-amber-500 text-white border-amber-600 shadow-md ring-4 ring-amber-100 scale-106 animate-pulse'
                              : isCompleted
                              ? 'bg-stone-950 text-white border-stone-950'
                              : 'bg-white text-stone-300 border-stone-200'
                          }`}>
                            {stage.key === 'ordered' && <Clock className="h-4 w-4" />}
                            {stage.key === 'packed' && <Box className="h-4 w-4" />}
                            {stage.key === 'shipped' && <Truck className="h-4 w-4" />}
                            {stage.key === 'out_for_delivery' && <Truck className="h-4 w-4" />}
                            {stage.key === 'delivered' && <CheckCircle2 className="h-4 w-4" />}
                          </div>

                          {/* Text labels descriptor block */}
                          <div className="text-left md:text-center text-xs">
                            <h5 className={`font-bold uppercase tracking-wider ${isCompleted ? 'text-stone-950' : 'text-stone-400'}`}>
                              {stage.title}
                            </h5>
                            <p className="text-[10px] text-stone-500 font-normal leading-tight max-w-[130px] mx-auto pt-0.5">{stage.desc}</p>
                          </div>

                        </div>
                      );
                    })}
                  </div>

                  {/* Shipment delivery ETA details block */}
                  <div className="border-t border-stone-200 pt-3 flex flex-col md:flex-row justify-between text-2xs gap-3">
                    <div className="flex gap-1 items-center">
                      <Truck className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span className="text-stone-600 font-medium">Shipment carrier: <strong className="text-stone-900 font-semibold uppercase">Delhivery Air Express</strong></span>
                    </div>
                    <span className="text-stone-500">
                      💡 Tip: Orders usually reach "shipped" within 4 minutes and "delivered" within 15 minutes of demo checkout.
                    </span>
                  </div>

                </div>
              ) : (
                !trackLoading && (
                  <div className="p-8 border border-stone-200 bg-stone-50/70 text-center rounded-none space-y-2">
                    <p className="text-stone-500 text-xs">No parcel queried yet or none searched. Select order copy trigger in <strong>My Orders</strong> to quick track trace.</p>
                  </div>
                )
              )}

            </div>
          )}

        </div>
      </div>
    </div>
  );
}
