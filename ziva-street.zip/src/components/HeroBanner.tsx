/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowRight, Compass, ShieldCheck } from 'lucide-react';
import heroImg from '../assets/images/hero_traditional_streetwear_1780490981656.png';

interface HeroBannerProps {
  onExploreClick: () => void;
}

export default function HeroBanner({ onExploreClick }: HeroBannerProps) {
  return (
    <div id="hero-banner-section" className="relative bg-stone-900 text-white overflow-hidden py-16 md:py-24 lg:py-32">
      {/* Background Graphic overlay with luxury high contrast images */}
      <div id="hero-bg" className="absolute inset-0 opacity-45">
        <img
          src={heroImg}
          alt="Premium traditional streetwear boys"
          className="w-full h-full object-cover object-center scaling-animation contrast-110 brightness-50"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-stone-900/50" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-end h-full">
        <div className="max-w-2xl text-left space-y-6">
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-black/40 backdrop-blur border border-white/10 rounded-none">
            <Compass className="h-3 w-3 text-white animate-spin-slow" />
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/80">Atelier Capsule 2026</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold uppercase tracking-wide text-white leading-tight font-display">
            Urban <span className="font-light italic text-[#F8F7F4]/90 lowercase">elegance</span><br />
            & Street <span className="font-light italic text-[#F8F7F4]/90 lowercase">soul</span>.
          </h1>

          <p className="text-stone-300 text-xs sm:text-sm leading-relaxed tracking-wider font-light max-w-lg">
            Presenting <strong className="text-white font-semibold uppercase tracking-wider">Ziva Street</strong>: A luxury experiment merging handloomed Indian textiles, Zardozi craftsmanship, and drop-shoulder streetwear drapes for the bold.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
            <button
              id="hero-explore-btn"
              onClick={onExploreClick}
              className="px-8 py-3.5 bg-white text-stone-950 text-xs font-bold uppercase tracking-widest rounded-none hover:bg-stone-150 transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
            >
              Explore Cuts
              <ArrowRight className="h-4 w-4" />
            </button>
            <div className="flex items-center gap-2 justify-center sm:justify-start px-2 py-1 text-stone-450 text-[10px] uppercase tracking-wider">
              <ShieldCheck className="h-4.5 w-4.5 text-white/50" />
              <span>Free Delivery above ₹699 + Coupon: <strong className="text-white font-semibold font-mono">DADU</strong> (20% OFF)</span>
            </div>
          </div>

        </div>
      </div>

      {/* Aesthetic Border Trim */}
      <div className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-stone-800 via-stone-500 to-stone-800" />
    </div>
  );
}
