/**
 * Delhivery Express Shipping API client library
 */

export interface DelhiveryAddress {
  fullName: string;
  phone: string;
  streetAddress: string;
  city: string;
  state: string;
  pinCode: string;
  country?: string;
}

export interface DelhiveryOrderPayload {
  orderId: string;
  amount: number;
  quantity: number;
  description: string;
  address: DelhiveryAddress;
}

export interface DelhiveryOrderResponse {
  success: boolean;
  waybill: string;
  orderId: string;
  message: string;
  isSimulated: boolean;
  rawResponse?: any;
}

export interface DelhiveryTrackResponse {
  success: boolean;
  waybill: string;
  orderId: string;
  status: 'ordered' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered';
  statusDetails: string;
  estimatedDelivery: string;
  origin: string;
  destination: string;
  scans: Array<{
    time: string;
    status: string;
    location: string;
    instructions: string;
  }>;
  isSimulated: boolean;
  rawResponse?: any;
}

// Environment variables
const DELHI_API_TOKEN = process.env.DELHIVERY_API_TOKEN || '';
const DELHI_BASE_URL = process.env.DELHIVERY_API_URL || 'https://staging-express.delhivery.com';

/**
 * Creates a shipping booking on Delhivery
 */
export async function createDelhiveryShipment(payload: DelhiveryOrderPayload): Promise<DelhiveryOrderResponse> {
  const isSimulated = !DELHI_API_TOKEN;

  if (isSimulated) {
    // Generate simulated Waybill
    const waybillNum = Math.floor(190000000 + Math.random() * 800000000).toString();
    console.log(`[DELHIVERY SIMULATION] Creating shipment for order ${payload.orderId}. Generated Waybill: ${waybillNum}`);
    return {
      success: true,
      waybill: waybillNum,
      orderId: payload.orderId,
      message: "Order booked successfully via Delhivery Simulation.",
      isSimulated: true
    };
  }

  try {
    // Prepare Delhivery standard payload (v1/packages/json/)
    const requestData = {
      pickup_location: {
        name: "Ziva Street Atelier",
        add: "Ziva Street Atelier, Bandra Colaba",
        phone: "9988776655",
        pin: "400050",
        city: "Mumbai",
        state: "Maharashtra",
        country: "India"
      },
      shipments: [
        {
          name: payload.address.fullName,
          add: payload.address.streetAddress,
          pin: payload.address.pinCode,
          phone: payload.address.phone,
          state: payload.address.state,
          city: payload.address.city,
          country: payload.address.country || "India",
          payment_mode: "Prepaid",
          order: payload.orderId,
          amount: payload.amount.toString(),
          total_amount: payload.amount.toString(),
          quantity: payload.quantity.toString(),
          weight: "0.55", // in kg, estimate
          products_desc: payload.description,
          cod_amount: "0"
        }
      ]
    };

    const formData = new URLSearchParams();
    formData.append('format', 'json');
    formData.append('data', JSON.stringify(requestData));

    const response = await fetch(`${DELHI_BASE_URL}/api/v1/packages/json/`, {
      method: "POST",
      headers: {
        "Authorization": `Token ${DELHI_API_TOKEN}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: formData.toString()
    });

    if (!response.ok) {
      throw new Error(`Delhivery booking responded with HTTP ${response.status}`);
    }

    const data = await response.json();
    console.log("[DELHIVERY LIVE] Create response data:", JSON.stringify(data));

    // Delhivery response normally lists packages inside an array
    const firstPackage = data?.packages?.[0] || {};
    const success = data?.success === true || firstPackage?.status === "Success";
    const waybill = firstPackage?.waybill || Math.floor(190000000 + Math.random() * 800000000).toString();

    return {
      success,
      waybill,
      orderId: payload.orderId,
      message: firstPackage?.remarks || "Delhivery logistics booked",
      isSimulated: false,
      rawResponse: data
    };
  } catch (error: any) {
    console.error("[DELHIVERY LIVE ERROR] Failed booking shipment, falling back to simulation:", error.message);
    const waybillNum = Math.floor(190000000 + Math.random() * 800000000).toString();
    return {
      success: true,
      waybill: waybillNum,
      orderId: payload.orderId,
      message: `Delhivery live request failed (${error.message}). Switched to offline backup simulation.`,
      isSimulated: true
    };
  }
}

/**
 * Tracks shipping coordinates on Delhivery by Waybill or Order ID
 */
export async function trackDelhiveryShipment(waybill: string, orderDateStr?: string, orderId?: string): Promise<DelhiveryTrackResponse> {
  const isSimulated = !DELHI_API_TOKEN;

  // Derive static times for status progression based on order creation
  const createdTime = orderDateStr ? new Date(orderDateStr).getTime() : Date.now() - 300000;
  const now = Date.now();
  const diffMins = Math.floor((now - createdTime) / (1000 * 60));

  let status: 'ordered' | 'packed' | 'shipped' | 'out_for_delivery' | 'delivered' = 'ordered';
  let statusDetails = 'Shipment details registered with Delhivery Courier';
  
  if (diffMins >= 15) {
    status = 'delivered';
    statusDetails = 'Package delivered successfully to recipient with visual confirmation.';
  } else if (diffMins >= 8) {
    status = 'out_for_delivery';
    statusDetails = 'Package is out for delivery with postman - Delhivery local hub.';
  } else if (diffMins >= 4) {
    status = 'shipped';
    statusDetails = 'Dispatched from Mumbai Central Sorting hub, in transit by air cargo.';
  } else if (diffMins >= 1) {
    status = 'packed';
    statusDetails = 'Shipment picked up, manifest generated, scales validated.';
  }

  if (isSimulated) {
    // Generate realistic scan details
    const scans = [
      {
        time: new Date(createdTime).toISOString(),
        status: "Manifest Created",
        location: "Mumbai Atelier Hub",
        instructions: "Shipment details entered onto Delhivery network"
      }
    ];

    if (diffMins >= 1) {
      scans.unshift({
        time: new Date(createdTime + 60000).toISOString(),
        status: "Package Picked Up",
        location: "Mumbai Sorting Facility",
        instructions: "Fitted with waybill, dimensions logged"
      });
    }
    if (diffMins >= 4) {
      scans.unshift({
        time: new Date(createdTime + 240000).toISOString(),
        status: "In Transit",
        location: "Delhivery Regional Gateway",
        instructions: "Dispatched towards destination airport cargo line"
      });
    }
    if (diffMins >= 8) {
      scans.unshift({
        time: new Date(createdTime + 480000).toISOString(),
        status: "Out For Delivery",
        location: "Local Courier Office",
        instructions: "Out with courier executive for doorstep drop"
      });
    }
    if (diffMins >= 15) {
      scans.unshift({
        time: new Date(createdTime + 900000).toISOString(),
        status: "Delivered",
        location: "Doorstep Destination",
        instructions: "Delivered to recipient, secure handshake confirmed"
      });
    }

    const estDeliveryDate = new Date(createdTime + 24 * 60 * 60 * 1000 * 3).toLocaleDateString('en-IN', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });

    return {
      success: true,
      waybill,
      orderId: orderId || `ZS-ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      status,
      statusDetails,
      estimatedDelivery: estDeliveryDate,
      origin: "Mumbai, Maharashtra",
      destination: "Delhi-NCR / Recipient Pin",
      scans,
      isSimulated: true
    };
  }

  try {
    // Fetch live Delhivery tracking info
    const response = await fetch(`${DELHI_BASE_URL}/api/v1/packages/json/?waybill=${waybill}`, {
      method: "GET",
      headers: {
        "Authorization": `Token ${DELHI_API_TOKEN}`,
      }
    });

    if (!response.ok) {
      throw new Error(`Delhivery track responded with HTTP ${response.status}`);
    }

    const data = await response.json();
    console.log("[DELHIVERY LIVE TRACK] Response payload:", JSON.stringify(data));

    // Compile scan data from api
    const scannedPackages = data?.ScanData || data?.packages || [];
    const firstScan = scannedPackages?.[0] || {};
    const liveScans = Array.isArray(firstScan?.scans) ? firstScan.scans.map((s: any) => ({
      time: s.ScanDateTime || s.time,
      status: s.ScanType || s.status || s.Activity,
      location: s.ScannedLocation || s.location || s.Location,
      instructions: s.Instructions || s.instructions || s.Remarks || ""
    })) : [];

    const liveStatusRaw = (firstScan?.Status?.Status || "").toLowerCase();
    let computedStatus = status;
    if (liveStatusRaw.includes("deliver")) {
      computedStatus = "delivered";
    } else if (liveStatusRaw.includes("out for delivery")) {
      computedStatus = "out_for_delivery";
    } else if (liveStatusRaw.includes("shipped") || liveStatusRaw.includes("transit")) {
      computedStatus = "shipped";
    } else if (liveStatusRaw.includes("packed")) {
      computedStatus = "packed";
    }

    return {
      success: true,
      waybill,
      orderId: firstScan?.Client || orderId || "ZS-ORD-LIVE",
      status: computedStatus,
      statusDetails: firstScan?.Status?.Instructions || statusDetails,
      estimatedDelivery: firstScan?.ExpectedDeliveryDate || new Date(createdTime + 2 * 24 * 60 * 60 * 1000).toDateString(),
      origin: firstScan?.Origin || "Mumbai Office",
      destination: firstScan?.Destination || "Recipient Pin",
      scans: liveScans.length > 0 ? liveScans : [{
        time: new Date().toISOString(),
        status: firstScan?.Status?.Status || "Order Placed",
        location: firstScan?.Status?.Location || "Atelier Distribution Centre",
        instructions: firstScan?.Status?.Instructions || "Dispatched on tracking networks"
      }],
      isSimulated: false,
      rawResponse: data
    };
  } catch (error: any) {
    console.error("[DELHIVERY LIVE TRACK ERROR] Failed, falling back to simulated progression helper:", error.message);
    
    // Failover to simulation tracking data so users still get dynamic progress
    const estDeliveryDate = new Date(createdTime + 24 * 60 * 60 * 1000 * 3).toLocaleDateString('en-IN', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });

    const scans = [
      {
        time: new Date(createdTime).toISOString(),
        status: "Manifest Live Network Link Error",
        location: "Backup Cloud Proxy",
        instructions: "Delhivery link offline. Dynamic order trace activated."
      }
    ];

    if (diffMins >= 1) {
      scans.unshift({
        time: new Date(createdTime + 60000).toISOString(),
        status: "Package Picked Up",
        location: "Mumbai Sorting Facility",
        instructions: "Fitted with simulated waybill, dimensions checked."
      });
    }
    if (diffMins >= 4) {
      scans.unshift({
        time: new Date(createdTime + 240000).toISOString(),
        status: "In Transit",
        location: "Delhivery Regional Gateway",
        instructions: "Dispatched flying towards local state cargo terminal."
      });
    }

    return {
      success: true,
      waybill,
      orderId: orderId || "ZS-ORD-BACKUP",
      status,
      statusDetails: `Simulated backup trace: ${statusDetails}`,
      estimatedDelivery: estDeliveryDate,
      origin: "Mumbai, MH",
      destination: "Delhi-NCR / Client Location",
      scans,
      isSimulated: true
    };
  }
}
